﻿Option Explicit On
Imports System.Data.SqlClient
Imports System.String

Public Class DentalClaims
    Inherits System.Windows.Forms.Form
    'Create ADO.NET objects.
    Public myConn As SqlConnection
    Public myCmd As SqlCommand
    Public myReader As SqlDataReader
    Public results As String

    'Declaring Session Object Variables
    Public UNET As Object
    Public StrSession As String

    'Declaring Form Variables
    Public Policy_Number As String
    Public Renewal_Date As String
    Public Employer_Name As String
    Public Proposal_Rating_Option As String
    Public Plan_Change_Effective_Date As String
    Public Coverage As String
    Public Action_On_Plan As String
    Public Dental_Plan1 As String
    Public Dental_Plan2 As String
    Public Transfer_Date As String
    Public Claim_Office_Code As String
    Public Corrected_Rates As String
    Public Calculated_Rates As String
    Public Created_By As String
    Public Created_On As Date
    Public Active As String
    Public EE_Calculate_Rates As String
    Public SP_Calculate_Rates As String
    Public CH_Calculate_Rates As String
    Public FAM_Calculate_Rates As String
    Public EE_Correct_Rates As String
    Public SP_Correct_Rates As String
    Public CH_Correct_Rates As String
    Public FAM_Correct_Rates As String
    Public Health_Office_Code As String
    Public Dental_Office_Code As String
    Public STD_Office_Code As String
    Public Vision_Office_Code As String
    Public Health_Transfer_Date As String
    Public Dental_Transfer_Date As String
    Public STD_Transfer_Date As String
    Public LTD_Transfer_Date As String
    Public Vision_Transfer_Date As String
    Public Eff_Date As String
    Public AddorRemove As Char
    Public CountLines As Integer
    Public DualDentalPlan As String
    Public Eligible_Employees As String

    'Declaring Login Variables
    Public UserID As String
    Public Password As String

    'Public Sub DentalClaims_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    'Create a Connection object.
    '    myConn = New SqlConnection("Initial Catalog=SEAL;")
    '    "Data Source=DBSED1138;Integrated Security=SSPI;")
    'End Sub

    Public Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Policy_Number = Me.TextBox1.Text
        Renewal_Date = Me.TextBox2.Text
        Employer_Name = Me.TextBox3.Text
        Proposal_Rating_Option = Me.TextBox4.Text
        Plan_Change_Effective_Date = Me.TextBox5.Text
        Coverage = Me.TextBox6.Text
        Action_On_Plan = Me.TextBox7.Text
        Dental_Plan1 = Me.TextBox8.Text
        Dental_Plan2 = Me.TextBox9.Text
        Transfer_Date = Me.TextBox10.Text
        Claim_Office_Code = Me.TextBox11.Text
        Corrected_Rates = Me.TextBox12.Text
        Calculated_Rates = Me.TextBox13.Text
        Created_By = Me.TextBox14.Text
        Created_On = Me.TextBox15.Text
        Active = Me.TextBox16.Text
        EE_Calculate_Rates = Me.TextBox17.Text
        SP_Calculate_Rates = Me.TextBox18.Text
        CH_Calculate_Rates = Me.TextBox19.Text
        FAM_Calculate_Rates = Me.TextBox20.Text
        EE_Correct_Rates = Me.TextBox21.Text
        SP_Correct_Rates = Me.TextBox22.Text
        CH_Correct_Rates = Me.TextBox23.Text
        FAM_Correct_Rates = Me.TextBox24.Text
        Health_Office_Code = Me.TextBox25.Text
        Dental_Office_Code = Me.TextBox26.Text
        STD_Office_Code = Me.TextBox27.Text
        Vision_Office_Code = Me.TextBox28.Text
        Health_Transfer_Date = Me.TextBox29.Text
        Dental_Transfer_Date = Me.TextBox30.Text
        STD_Transfer_Date = Me.TextBox31.Text
        LTD_Transfer_Date = Me.TextBox32.Text
        Vision_Transfer_Date = Me.TextBox33.Text

        'MessageBox.Show("Policy Number :" + Policy_Number)
        'MessageBox.Show("Renewal_Date :" + Renewal_Date)
        'MessageBox.Show("Employer_Name :" + Employer_Name)
        'MessageBox.Show("Proposal_Rating_Option :" + Proposal_Rating_Option)
        'MessageBox.Show("Plan_Change_Effective_Date :" + Plan_Change_Effective_Date)
        'MessageBox.Show("Coverage :" + Coverage)
        'MessageBox.Show("Action_On_Plan :" + Action_On_Plan)
        'MessageBox.Show("Dental_Plan1 :" + Dental_Plan1)
        'MessageBox.Show("Dental_Plan2 :" + Dental_Plan2)
        'MessageBox.Show("Transfer_Date :" + Transfer_Date)
        'MessageBox.Show("Claim_Office_Code :" + Claim_Office_Code)
        'MessageBox.Show("Corrected_Rates :" + Corrected_Rates)
        'MessageBox.Show("Calculated_Rates :" + Calculated_Rates)
        'MessageBox.Show("Created_By :" + Created_By)
        'MessageBox.Show("Created_On :" + Created_On)
        'MessageBox.Show("Active :" + Active)
        'MessageBox.Show("EE_Calculate_Rates :" + EE_Calculate_Rates)
        'MessageBox.Show("SP_Calculate_Rates :" + SP_Calculate_Rates)
        'MessageBox.Show("CH_Calculate_Rates :" + CH_Calculate_Rates)
        'MessageBox.Show("FAM_Calculate_Rates :" + FAM_Calculate_Rates)
        'MessageBox.Show("EE_Correct_Rates :" + EE_Correct_Rates)
        'MessageBox.Show("SP_Correct_Rates :" + SP_Correct_Rates)
        'MessageBox.Show("CH_Correct_Rates :" + CH_Correct_Rates)
        'MessageBox.Show("FAM_Correct_Rates :" + FAM_Correct_Rates)
        'MessageBox.Show("Health_Office_Code :" + Health_Office_Code)
        'MessageBox.Show("Dental_Office_Code :" + Dental_Office_Code)
        'MessageBox.Show("STD_Office_Code :" + STD_Office_Code)
        'MessageBox.Show("Vision_Office_Code :" + Vision_Office_Code)
        'MessageBox.Show("Health_Transfer_Date :" + Health_Transfer_Date)
        'MessageBox.Show("Dental_Transfer_Date :" + Dental_Transfer_Date)
        'MessageBox.Show("STD_Transfer_Date :" + STD_Transfer_Date)
        'MessageBox.Show("LTD_Transfer_Date :" + LTD_Transfer_Date)
        'MessageBox.Show("Vision_Transfer_Date :" + Vision_Transfer_Date)

        StrSession = InputBox("Enter Session Name", "Session Name")

        Call EmulatorConnection()

        Call Login()

        Call SGAMScreen()

        Call SGRMScreen()

        Call SGHDScreen()

        Call SGCLScreen()

    End Sub

    Sub EmulatorConnection()
        ' Get the main system object
        UNET = Nothing

        If StrSession = "" Then
            MessageBox.Show("Kindly login in session to process Dental Claims.")
            Application.Exit()
        Else
            UNET = CreateObject("Pcomm.auteclsession")
            UNET.SetConnectionByName(StrSession)
        End If

    End Sub

    Sub apiChk()
        Do While UNET.autECLOIA.InputInhibited <> 0
            UNET.autECLPS.Wait(10)
        Loop
        UNET.autECLPS.Wait(10)
        'Application.Wait (Now + TimeValue("00:00:01")
    End Sub

    Sub Login()

        If UNET.autECLPS.GetText(2, 1, 8) <> "UHC0010:" Then
            MessageBox.Show("Please open emulator session to process Dental Claims.")
            Application.Exit()
        Else
            UNET.autECLPS.SendKeys("TIC", 3, 1)
            apiChk()
            UNET.autECLPS.SendKeys("[enter]")
            apiChk()
        End If

        If UNET.autECLPS.GetText(12, 10, 9) <> "PASSWORD:" Then
            MessageBox.Show("Emulator Session is not on login screen. Please open emulator session again.")
            Application.Exit()
        Else
            UserID = InputBox("Enter UserID", "UserID Box")
            Password = InputBox("Enter Password", "Password Box")
            UNET.autECLPS.SendKeys(UserID, 10, 21)
            apiChk()
            UNET.autECLPS.SendKeys(Password, 12, 21)
            apiChk()
            UNET.autECLPS.SendKeys("[enter]")
            apiChk()
        End If

        If UNET.autECLPS.GetText(3, 29, 23) <> "A P P L I C A T I O N S" Then
            MessageBox.Show("Emulator session not on Applications Screen. Please open session again.")
            Application.Exit()
        Else
            UNET.autECLPS.SendKeys("2", 16, 15)
            apiChk()
            UNET.autECLPS.SendKeys("[enter]")
            apiChk()
        End If

        If UNET.autECLPS.GetText(4, 3, 27) <> "SGUB-PRIME CASE MAINTENANCE" Then
            MessageBox.Show("Emulator session not on Applications Menu Screen. Please open session again.")
            Application.Exit()
        Else
            UNET.autECLPS.SendKeys("SGUB", 21, 22)
            apiChk()
            UNET.autECLPS.SendKeys("SGAM", 22, 22)
            apiChk()
            UNET.autECLPS.SendKeys("[enter]")
            apiChk()
        End If

    End Sub

    Sub SGAMScreen()

        If UNET.autECLPS.GetText(2, 77, 4) <> "SGAM" Then
            MessageBox.Show("Not on SGAM Screen. Kindly login again.")
            Application.Exit()
        Else
            UNET.autECLPS.SendKeys(Policy_Number, 3, 16)
            apiChk()
            UNET.autECLPS.SendKeys("[enter]")
            apiChk()
            UNET.autECLPS.SendKeys("A", 4, 8)
            apiChk()
            Eff_Date = Mid(Plan_Change_Effective_Date, 1, 2) & "/" & Mid(Plan_Change_Effective_Date, 3, 2) & "/" & Mid(Plan_Change_Effective_Date, 5, 4)
            UNET.autECLPS.SendKeys(Eff_Date, 4, 44)
            apiChk()
            UNET.autECLPS.SendKeys("P", 6, 26)
            apiChk()
            UNET.autECLPS.SendKeys("Y", 10, 4)
            apiChk()
            UNET.autECLPS.SendKeys("Y", 10, 4)
            apiChk()
            UNET.autECLPS.SendKeys("[enter]")
            apiChk()
        End If
    End Sub

    Sub SGRMScreen()

        If UNET.autECLPS.GetText(2, 77, 4) <> "SGRM" Then
            MessageBox.Show("Not on SGRM Screen. Kindly login again.")
            Application.Exit()
        Else
            UNET.autECLPS.SendKeys("C", 4, 8)
            apiChk()
            UNET.autECLPS.SendKeys("[enter]")
            apiChk()
            Do
                If UNET.autECLPS.GetText(1, 76, 3) = "END" Then
                    For CountLines = 7 To 20
                        If UNET.autECLPS.GetText(CountLines, 2, 1) = "" Then
                            UNET.autECLPS.SendKeys("** pc eff " & Eff_Date & "group to add dental " & Dental_Plan1 & "& install rates per rate exhibit/", CountLines, 2)
                            apiChk()
                            UNET.autECLPS.SendKeys("N", CountLines, 78)
                            apiChk()
                            UNET.autECLPS.SendKeys("email from xxxxx/pcu ran " & Today, CountLines + 1, 2)
                            apiChk()
                            UNET.autECLPS.SendKeys("N", CountLines + 1, 78)
                            apiChk()
                            UNET.autECLPS.SendKeys("[enter]")
                            apiChk()
                            Exit Do
                        End If
                    Next CountLines
                End If
                UNET.autECLPS.SendKeys("Y", 21, 79)
                apiChk()
                UNET.autECLPS.SendKeys("[enter]")
                apiChk()
            Loop

            UNET.autECLPS.SendKeys("[enter]")
            apiChk()

            If UNET.autECLPS.GetText(2, 77, 4) <> "SGPI" Then
                MessageBox.Show("Not on SGPI Screen. Kindly login again.")
                Application.Exit()
            Else
                UNET.autECLPS.SendKeys("C", 4, 8)
                apiChk()
                UNET.autECLPS.SendKeys("[enter]")
                apiChk()
            End If
        End If
    End Sub

    Sub SGHDScreen()

        If UNET.autECLPS.GetText(2, 77, 4) <> "SGHD" Then
            MessageBox.Show("Not on SGHD Screen. Kindly login again.")
            Application.Exit()
        Else
            UNET.autECLPS.SendKeys("C", 4, 8)
            apiChk()
            AddorRemove = InputBox("Do you want to Add or Remove Dental Claims?", "Add or Remove Dental Claims", "Please enter A to Add or R to Remove")
            DualDentalPlan = InputBox("Do you want to Add Dual Dental Plan?", "Add Dual Dental Plan", "Please enter value of Dual Dental Plan")
            If AddorRemove = "A" Then
                UNET.autECLPS.SendKeys(Dental_Plan1, 15, 15)
                apiChk()
                If DualDentalPlan <> "" Then
                    UNET.autECLPS.SendKeys(Dental_Plan2, 15, 54)
                    apiChk()
                End If
                UNET.autECLPS.SendKeys("[enter]")
                apiChk()
            Else
                UNET.autECLPS.SendKeys("00000", 15, 15)
                apiChk()
                UNET.autECLPS.SendKeys("[enter]")
                apiChk()
                MessageBox.Show("The Dental Plan is being removed.")
            End If

            If UNET.autECLPS.GetText(23, 7, 19) <> "SGPI SUCCESSFUL CHG" Then
                MessageBox.Show("The Dental Plan is being installed.")
            End If

            If UNET.autECLPS.GetText(23, 2, 45) <> "7620R – DENT PLN NOT AVAIL FOR SIZE/STATE/ZIP" Then
                MessageBox.Show("The Dental Plan is not being installed as it is not being available in the market.")
                UNET.autECLPS.SendKeys("I", 4, 8)
                apiChk()
                UNET.autECLPS.SendKeys("SGPI", 22, 13)
                apiChk()
                UNET.autECLPS.SendKeys("[enter]")
                apiChk()
                Eligible_Employees = Strings.Trim(UNET.autECLPS.GetText(18, 32, 3))
                If Strings.Right(Eligible_Employees, 2) < "10" Then
                    UNET.autECLPS.SendKeys("10", 18, 33)
                    apiChk()
                    UNET.autECLPS.SendKeys("SGCL", 22, 13)
                    apiChk()
                End If
            End If

            If UNET.autECLPS.GetText(23, 7, 19) <> "SGPI SUCCESSFUL CHG" Then
                MessageBox.Show("The Dental Plan is being added.")
                UNET.autECLPS.SendKeys("[enter]")
            Else
                MessageBox.Show("The Dental Plan is not being added.")
                Application.Exit()
            End If
        End If

        UNET.autECLPS.SendKeys("[enter]")
        apiChk()
        UNET.autECLPS.SendKeys("[enter]")
        apiChk()

        If UNET.autECLPS.GetText(2, 77, 4) <> "SGOR" Then
            MessageBox.Show("Not on SGOR Screen. Kindly login again.")
            Application.Exit()
        Else
            UNET.autECLPS.SendKeys("C", 4, 8)
            apiChk()
            UNET.autECLPS.SendKeys("[enter]")
            apiChk()
        End If

        If UNET.autECLPS.GetText(2, 77, 4) <> "SGCI" Then
            MessageBox.Show("Not on SGCI Screen. Kindly login again.")
            Application.Exit()
        Else
            UNET.autECLPS.SendKeys("C", 4, 8)
            apiChk()
            UNET.autECLPS.SendKeys("[enter]")
            apiChk()
        End If
    End Sub

    Sub SGCLScreen()

        If UNET.autECLPS.GetText(2, 77, 4) <> "SGCL" Then
            MessageBox.Show("Not on SGCL Screen. Kindly login again.")
            Application.Exit()
        Else
            UNET.autECLPS.SendKeys("C", 4, 8)
            apiChk()
            UNET.autECLPS.SendKeys("[enter]")
            apiChk()
            UNET.autECLPS.SendKeys(Mid(Plan_Change_Effective_Date, 1, 2), 13, 65)
            apiChk()
            UNET.autECLPS.SendKeys(Mid(Plan_Change_Effective_Date, 3, 2), 13, 70)
            apiChk()
            UNET.autECLPS.SendKeys(Mid(Plan_Change_Effective_Date, 5, 4), 13, 75)
            apiChk()
            UNET.autECLPS.SendKeys("[enter]")
            apiChk()
        End If
    End Sub

End Class