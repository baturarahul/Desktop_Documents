﻿var Emulsessiona = "";
var MacroOutput = "";
var Ctr_row = "";
var MacroOutput = "";
var Adress_found = "";
var Err = "";
var dateITC = "";
var EFF = "";
var check = "";
var Limitation = "";
var paid = "";
var bd = "";
var screenDiv = "";
var DivScreen = "";
var Check_ITC = "";
var CapCode = "";
var CapCdEffDate = "";
var BSAR7MAID_Array = [];
var slcode = "";
var slno = false;
var chkfecode = false;
var pf8 = 0;
var state_BSAR = "";
var Main_SCREEN;
var LoadPLSV = false;
var orphan = false;
var addAddress = false;
var check_MPIN = false;

var TAX_ID_Tax = "";
var MPIN = "";
var Extn = "";
var Adr_Serch_With_Maid_1 = false;
var Adr_Serch_And_Add_1 = false;
var LOC_MEDICAID = "";
var MEDICAID = "";
var MedicaidState = "";
var FacilityCode = "";
var HOSPITAL_MPIN = "";
var PS_Hospital = "";
var AP = "";
var DIR = "";
var DIR_IND = "";
var RSN_CD = "";
var FEDERAL_DEA_NUMBER = "";
var EXPIRATION_DATE_IFC = "";
var ST = "";
var CERT_NUMBER_IFC = "";
var License = "";
var EFF_DATE_IFC = "";
var EXP_DATE_IFC = "";
var CURRENT_CREDENTIAL_TYPE = "";
var CURRENT_CYCLE_DATE = "";
var WrittenBy = "";



var Del_Nondel = "";
var PITmpin = "";
var CorpName = "";
var PTiName = "";
var LOBs = "";
var AgrmntIDs = "";
var B_C_AddType = "";
var NewAddSel_Counter = "";
var NewMA_ID = "";
var Ma_ID = "";
var NewSelection = "";
var ZIP_Addressc = "";
var ADRc = "";
var CITY_Addressc = "";
var STATE_Addressc = "";
var OfficeLimitation_Load = "";
var billA_id = "";
var selectionCode = "";
var CosmosExp1 = "";
var CosmosExp = "";
var ValueCNTC_TYPE = "";
var ValueNAME = "";
var ValueCOMM_TYPE = "";
var ValuePHONE_EXTN = "";
var ValueFAXNDBContact = "";
var ValueExtnNDBContact = "";
var ValueFAXExtnNDBContact = "";
var ValCOMM = "";
var ValTYPE_Comm = "";
var ValPROV_ADDR = "";
var ValACTCODEComm = "";
var ValuesLANG_CODE = "";
var ValuesSPOKEN_BY = "";
//'below variables are replication of few above incase there are multiple entries for a single address which will be delimited with a comma
var SameValueCNTC_TYPE = "";
var SameValueNAME = "";
var SameValueCOMM_TYPE = "";
var SameValuePHONE_EXTN = "";
var SameValueFAXNDBContact = "";
var SameValueExtnNDBContact = "";
var SameValueFAXExtnNDBContact = "";
var SameValCOMM = "";
var SameValTYPE_Comm = "";
var SameValPROV_ADDR = "";
var SameValACTCODEComm = "";
var SameValuesLANG_CODE = "";
var SameValuesSPOKEN_BY = "";
var SameValuesWrittenBy = "";
//'//'//'//'//'//'//'
//'Variables for CLN Fill incase of Provider is PCP
var FNameCLN
var LNameCLN
var MNameCLN
var NSFXCLN
var DegreeCLN
var CLN; 
//'variable declaration end for CLN Fill
var cnt
var cnt2
var x
var commL
var GroupMPIN
var ADRt
var Gender_LOB = "";
var DivData 
var LOBData
var EnrollData
var CommData 
var LangData 
var ContactData 
var Load7
var Load4
var ADRi
var Cityi
var Statei
var Scrn4_B
var Scrn4_E
var Scrn4_Loop
var Loop4
var cnt4L
var ID1
var ID2
var linelooper
var DivS

var addressSno = "";
var AddressLine1 = "";
var AddressLine2 = "";
var StateC = "";
var CityC = "";
var ZipC = "";
var AddressTypeC = "";
var AddressIdC = "";
var phoneC = "";
var phoneTypeC = "";
var AddMA_ID = "";
var AddBillA_ID = "";
var AddressSNO_new = "";
var AddressLine1_new = "";
var AddressLine2_new = "";
var StateC_new = "";
var CityC_new = "";
var ZipC_new = "";
var AddressTypeC_new = "";
var AddressIdC_new = "";
var phoneC_new = "";
var phoneTypeC_new = "";
var AddMA_ID_new = "";
var BA_ID_DB = "";
var AddBillA_ID_new = "";
var ctrwait = 0;
//wait function
function apiChka() { 

    while (Emulsessiona.autECLOIA.inputinhibited != 0) {
        Emulsessiona.autECLPS.Wait(500);        
    }        
    Emulsessiona.autECLOIA.WaitForInputReady(1000);   
    
}

//time tracking function
function macroStart(gdnum, mainid) {
    var runtime = "StartMacro";
    var msg = "";
    $.ajax({
        type: "POST",
        url: "AddInformation.aspx/MacroTime",
        data: '{gdnum:"' + gdnum + '",mainid:"' + mainid + '",runtime:"' + runtime + '",msg:"' + msg + '"}',
        async: false,
        contentType: "application/json; charset=utf-8",
        success: function (data) { }
    })
}

function macroEnd(gdnum, mainid, msg) {
    var runtime = "EndMacro";
    $.ajax({
        type: "POST",
        url: "AddInformation.aspx/MacroTime",
        data: '{gdnum:"' + gdnum + '",mainid:"' + mainid + '",runtime:"' + runtime + '",msg:"' + msg + '"}',
        async: false,
        contentType: "application/json; charset=utf-8",
        success: function (data) { }
    })
}
//time tracking end







//////// MAIN FUNCTION//////////

function NDB_Address_Add(gd_num) {
    gd_num = $('#txtGDNumber').val()
    //GDnum = document.getElementById("HF_NDBPF_GDNumber").innerText
    var GDnum = gd_num;
    var Team = "ndb";

    $.ajax({
        type: "POST",
        url: "AddInformation.aspx/Address_Add",
        data: '{GDnum:"' + GDnum + '",Team:"' + Team + '"}',
        async: false,
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            //alert(data.d);
            var json = JSON.parse(data.d)
            for (i = 0; i < json.length; i++) {

                Gender_LOB = json[i].Member_Gender;
                GDNumber = json[i].GD_Number;
                TAX_ID_Tax = json[i].Tax_ID_Tax;
                Del_Nondel = json[i].tean;
                ADR = json[i].ADR;
                COUNTY = json[i].COUNTY;
                CITY_Address = json[i].CITY_Address;
                STATE_Address = json[i].STATE_Address;
                ZIP_Address = json[i].ZIP_Address;
                ADDRESS_TYPE = json[i].ADDRESS_TYPE;
                PS1 = json[i].PS1;
                CORRESPONDANCE = json[i].CORRESPONDANCE;
                DBA_NAME = json[i].DBA_NAME;
                EFF_DATE_Address = json[i].EFF_DATE_Address;
                TELEPHONE_EXTN = json[i].TELEPHONE_EXTN;
                PS2 = json[i].PS2;
                ADDR_TYPE = json[i].ADDR_TYPE;
                TELEPHONE_EXTN_FAX = json[i].TELEPHONE_EXTN_FAX;
                PS3 = json[i].PS3;
                TYPE_Address = json[i].TYPE_Address;
                Ma_ID = json[i].MA_ID;
                MPIN = json[i].MPIN;
                Extn = json[i].Extension_ndb;

                DIR_IND = json[i].DIR_IND;
                RSN_CD = json[i].RSN_CD;
                Div = json[i].Div;
                PROV_NBR1 = json[i].PROV_NBR1;
                EFF_IUZ = json[i].EFF_IUZ;
                CLN = json[i].CLN;
                MAIL = json[i].MAIL;
                PRAC_IUZ = json[i].PRAC_IUZ;
                CRED_DESIGN = json[i].CRED_DESIGN;
                ALL_PAYOR = json[i].ALL_PAYOR;
                UR_IND = json[i].UR_IND;
                RX_PRIV = json[i].RX_PRIV;
                RX_NBR = json[i].RX_NBR;
                DEA = json[i].DEA;
                LICN = json[i].LICN;
                EXT_HR_IND = json[i].EXT_HR_IND;
                AGE_LIMIT_IND = json[i].AGE_LIMIT_IND;
                MEDICAID = json[i].MEDICAID;
                MedicaidInd = json[i].MedicaidInd;
                EffDate_Medicaid = json[i].EffDate_Medicaid;
                OFFICE_HOURS = json[i].OFFICE_HOURS;
                MondayOpen1 = json[i].MondayOpen1;
                TuesdayOpen1 = json[i].TuesdayOpen1;
                WednesdayOpen1 = json[i].WednesdayOpen1;
                ThursdayOpen1 = json[i].ThursdayOpen1;
                FridayOpen1 = json[i].FridayOpen1;
                SaturdayOpen1 = json[i].SaturdayOpen1;
                SundayOpen1 = json[i].SundayOpen1;
                MondayClosed1 = json[i].MondayClosed1;
                TuesdayClosed1 = json[i].TuesdayClosed1;
                WednesdayClosed1 = json[i].WednesdayClosed1;
                ThursdayClosed1 = json[i].ThursdayClosed1;
                FridayClosed1 = json[i].FridayClosed1;
                SaturdayClosed1 = json[i].SaturdayClosed1;
                SundayClosed1 = json[i].SundayClosed1;
                MondayOpen2 = json[i].MondayOpen2;
                TuesdayOpen2 = json[i].TuesdayOpen2;
                WednesdayOpen2 = json[i].WednesdayOpen2;
                ThursdayOpen2 = json[i].ThursdayOpen2;
                FridayOpen2 = json[i].FridayOpen2;
                SaturdayOpen2 = json[i].SaturdayOpen2;
                SundayOpen2 = json[i].SundayOpen2;
                MondayClosed2 = json[i].MondayClosed2;
                TuesdayClosed2 = json[i].TuesdayClosed2;
                WednesdayClosed2 = json[i].WednesdayClosed2;
                ThursdayClosed2 = json[i].ThursdayClosed2;
                FridayClosed2 = json[i].FridayClosed2;
                SaturdayClosed2 = json[i].SaturdayClosed2;
                SundayClosed2 = json[i].SundayClosed2;
                LOC_MEDICAID = json[i].LOC_MEDICAID;
                LANG_CODE = json[i].LANG_CODE;
                SPOKEN_BY = json[i].SPOKEN_BY;
                ACT_CD_Lang = json[i].ACT_CD_Lang;
                COMMUNICATION = json[i].COMMUNICATION;
                TYPE_Comm = json[i].TYPE_Comm;
                PROV_ADDR = json[i].PROV_ADDR;
                ACT_CODE_Comm = json[i].ACT_CODE_Comm;
                CNTC_TYPE = json[i].CNTC_TYPE;
                NAME = json[i].NAME;
                COMM_TYPE = json[i].COMM_TYPE;
                PHONE_EXTN = json[i].PHONE_EXTN;
                ExtnNDBContact = json[i].ExtnNDBContact;
                FAXNDBContact = json[i].FAXNDBContact;
                FAXExtnNDBContact = json[i].FAXExtnNDBContact;
                ACT_CD_Conatact = json[i].ACT_CD_Conatact;
                CURRENT_CYCLE_DATE = json[i].CURRENT_CYCLE_DATE;
                CURRENT_CREDENTIAL_TYPE = json[i].CURRENT_CREDENTIAL_TYPE;
                DELEGATED_ENTITY_CODE = json[i].DELEGATED_ENTITY_CODE;
                ORIG_DEL_DT = json[i].ORIG_DEL_DT;
                CURRENT_DEL_DT = json[i].CURRENT_DEL_DT;
                TAX_ID_ITC = json[i].TAX_ID_ITC;
                GROUP_NAME = json[i].GROUP_NAME;
                CHECK_NAME_BSAR = json[i].CHECK_NAME_BSAR;
                INSTANCE = json[i].INSTANCE;
                ACTIVE_BSAR = json[i].ACTIVE_BSAR;
                LOB = json[i].LOB;
                IPA_ID = json[i].IPA_ID;
                AGREEMENT_ID_BSAR = json[i].AGREEMENT_ID_BSAR;
                PCP_AGREEMENT_NROW_ID_BSAR = json[i].PCP_AGREEMENT_NROW_ID_BSAR;
                EFF_DATE_BSAR = json[i].EFF_DATE_BSAR;
                PCP_BSAR = json[i].PCP_BSAR;
                FILE_LMTS = json[i].FILE_LMTS;
                ACCPT_PAT = json[i].ACCPT_PAT;
                ACCPT_GENDER_CD = json[i].ACCPT_GENDER_CD;
                ACCPT_MIN_AGE = json[i].ACCPT_MIN_AGE;
                ACCPT_MAX_AGE = json[i].ACCPT_MAX_AGE;
                ACCPT_EXISTING_PT = json[i].ACCPT_EXISTING_PT;
                ENROLLMENT_LIMITS = json[i].ENROLLMENT_LIMITS;
                main_id = json[i].main_id;
                BA_ID_DB = json[i].BA_ID;
                MedicaidState = json[i].MedicaidState;
                FacilityCode = json[i].FacilityCode;
                HOSPITAL_MPIN = json[i].HOSPITAL_MPIN_TO_AFFILIATE;
                PS_Hospital = json[i].PS_Hospital;
                AP = json[i].AP;
                DIR = json[i].DIR;
                FEDERAL_DEA_NUMBER = json[i].FEDERAL_DEA_NUMBER;
                EXPIRATION_DATE_IFC = json[i].EXPIRATION_DATE_IFC;
                ST = json[i].ST;
                CERT_NUMBER_IFC = json[i].CERT_NUMBER_IFC;
                License = json[i].License;
                EFF_DATE_IFC = json[i].EFF_DATE_IFC;
                EXP_DATE_IFC = json[i].EXP_DATE_IFC;
                CapCdEffDate = json[i].CapCdEffDate;
                CapCode = json[i].CapCode;
                PCP_IND = json[i].ProviderName;
                WrittenBy = json[i].WrittenBy;

                SessNameNDBa = prompt("Please enter session name for NDB", "A");//getting session name
                Emulsessiona = new ActiveXObject("Pcomm.auteclsession");//creating session object

                if (SessNameNDBa == null) {//error handalling 
                    MacroOutput = "Canceled";
                    macroEnd(GDNumber, main_id, MacroOutput);                   
                    return;
                }

                emulatordisplayadd(SessNameNDBa);// to connect session name and display 
                macroStart(GDNumber, main_id);// to capture macro start time 
                Connection_SettingAddNDB(); // error handalling if wrong session name selected

                if (StopMacro == false) {//error handalling 
                    macroEnd(GDNumber, main_id, MacroOutput);                   
                    return;
                }

                Emulsessiona.setconnectionbyname(SessNameNDBa.toUpperCase());//connection setting
                Emulsessiona.autECLOIA.WaitForInputReady;

                var findscreen = Emulsessiona.autECLPS.gettext(1, 1, 10).trim()

                if (findscreen == "PC0130") {
                    alert("Respective session is not for NDB");
                    macroEnd(GDNumber, main_id, MacroOutput);
                    //window.resizeTo(1280, 1024);
                    return;
                }

                findscreen = Emulsessiona.autECLPS.gettext(2, 1, 8).trim()

                if (findscreen == "UHC0010:") {
                    MacroOutput = "Please sign on to respective session first ";
                    macroEnd(GDNumber, main_id, MacroOutput);
                    //window.resizeTo(1280, 1024);
                    return;

                }
                
                Data_Enablementadd();

                check_MPIN_TAX();// checking MPIN TAX id is correct

                if (check_MPIN == true) { return;}                
                if (Ma_ID != "") {                    
                   Check_Address_LoadedOrNot();//checking address loaded or not using MAID                  
                } else {
                    Check_Address();//checking address loaded or not using Address
                }                
                if (addcheck == true) {return;}                
                if (Del_Nondel.indexOf("Delegated,NDB and NICE") >= 0) { Check_del();}// Delegated or non deligated check              
                if (Del_Nondel.indexOf("Non Delegated") >= 0) { Check_Nondel();}// Delegated or non deligated check              
                if (Check_ITC_IDC_Screen == true) {
                    if (Del_Nondel.indexOf("Delegated,NDB and NICE") >= 0) {
                        chkITC();
                    }
                } else {return;}                
                if (Check_ITC == true) {return;}                
                chkdate();
                if (check == true) {return;}                
                if (Check_ITC == false) {
                    Get_PTI_MPIN();
                    if (PITmpin != "") {
                        if (ADR != "") {
                            Get_PTI_MAID();
                        }
                        else {
                            Get_PTI_MAIDbyMAID();

                            if (ptiMAID != "") {
                                if (ptiMAID != Ma_ID) {
                                    MacroOutput = MacroOutput + "\n" + "Provided Maid address " + Ma_ID + " has not matched with PTI-MAID " + ptiMAID;
                                    return;
                                }
                            }
                        }
                    } else if (Emulsessiona.autECLPS.GetText(24, 2, 60).trim().indexOf("NO DATA FOUND") >= 0) {apiChka(); return;}                        
                    if (MacroOutput.indexOf("NO MATCH")>=0) {return;}                    
                    chAddrtyp();
                    if (ptiMAID != "") {                              
                        Adr_Serch_With_Maid();                            
                    } else {
                        Adr_Serch_And_Add();
                    }

                    if (Main_SCREEN == false) {return;}                   
                    Address_Store_Screen();                    
                    if (DIR_IND == "N") { Update_DIRIND();}
                    if (PCP_BSAR.trim() == "P") { InfoGrab_CLN(); }                    
                    UHCIID_Screen();
                    checkState();
                    if ((state_BSAR == "YES" && MEDICAID != "") || state_BSAR == "NO" || state_BSAR == "") { BSAR_UPDATION(); }                    
                    if (state_BSAR == "YES" && MEDICAID == "") {
                        if (CHECK_NAME_BSAR != "" || LOB != "") {
                            MacroOutput = MacroOutput + "\n" + StateC_new + " State - Medicaid id is mandatory to load BSAR screen";
                        }
                    }                    
                    OFFICE_LIMITATION_SCREENadd();                    
                    MEDICAID_IAM_Screenadd();                    
                    IDC_CREDENTIAL_CATEGORY();                   
                    ITC_CREDENTIAL_CATEGORY();                    
                    IHA_CREDENTIAL_CATEGORY();                   
                    IFC_CREDENTIAL_CATEGORY();                    
                }
                
                Emulsessiona.autECLPS.SendKeys("[PF2]");
                apiChka();

                macroEnd(GDNumber, main_id, MacroOutput);
                //var hf = document.getElementById("HF_NDBPF_RunStatus");
                //if (MacroOutput.indexOf("~X~") >= 0) { hf.value = "Not Added"; } else { hf.value = "Added"; }

                var RunSts;
                if (MacroOutput.indexOf("~X~") >= 0) { RunSts = 'Not Added'; } else { RunSts = 'Added'; }

                var hfGD = GDNumber;
                var MainID = main_id;

                //tstAJAXSetVal(RunSts + "|" + hfGD.value + "|" + hfMainID.value);  //============================================================================
                var myvall = RunSts + "|" + hfGD + "|" + MainID
                PageMethods.SetSession(myvall, OnSuccess);

                function OnSuccess() { }
                
            }
        }   
        
    });

    if (MacroOutput !== "") {

        if (Emulsessiona.autECLPS.GetText(3, 30, 20).trim().indexOf("-- AREA MENU") < 0) {
            Emulsessiona.autECLPS.Sendkeys("[pf2]");
            apiChka();
        }
        macroEnd(GDNumber, main_id, MacroOutput);
        alert(MacroOutput);
    } 
    
}

function Main_SCREEN(){
    Main_SCREEN = false;
    ////'******* Function for enter to Provider address information screen************
    
    Emulsessiona.autECLPS.SendKeys ("A", 21, 8);
    Emulsessiona.autECLPS.SendKeys ("A", 21, 15);
    Emulsessiona.autECLPS.SendKeys (MPIN, 21, 31);    
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    if (BA_ID_DB != "") {
        Emulsessiona.autECLPS.SendKeys(BA_ID_DB, 21, 47);
    }
    
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();    
    Emulsessiona.autECLPS.SendKeys ("1", 19, 13);
    Emulsessiona.autECLPS.SendKeys ("[enter]" );
    apiChka();
    apiChka();

    if (Emulsessiona.autECLPS.GetText(4, 2, 12).trim().indexOf("SEL ADDRESS") >= 0 ) {
        Main_SCREEN = true;
    }else{
        //alert( "Address Selection screen not found. Macro will stop.");
        MacroOutput = MacroOutput + "\n" + "Mpin-" + MPIN + " Billing address not found.";
        return;
    }
    
}

function Address_Multiple_Screen()
{
    Address_Multiple_Screen = false;
    //'******* Function for select an Address to Load to NDB screen***********
    if (ADR == "") {
        Adr_Serch_With_Maid();
        Address_Multiple_Screen = true;
        return;
    }
  
    Address_Multiple_Screen = false;
    piped = ADR.split("|");
    ADRc = ADR.split("|");
    ZIP_Addressc = ZIP_Address.split("|");
    STATE_Addressc = STATE_Address.split("|");
    CITY_Addressc = CITY_Address.split("|");
    TELEPHONE_EXTNc = TELEPHONE_EXTN.split("|");
    TELEPHONE_EXTN_FAXc = TELEPHONE_EXTN_FAX.split("|");
    
    //'===============================Address Macthing Screen=========================================
    //For x = 0 To UBound(piped)
    for (x = 0; x < piped.length; x++) {
        //'x = 0
        apiChka();

        Emulsessiona.autECLPS.SendKeys(ADRc[x], 6, 5);

        //'Error handling for ZIP Code length less than 5
        //if(Len(Trim(Left(ZIP_Addressc[x], 5))) < 5 ){
        if (ZIP_Addressc[x].slice(0, 5).trim().length < 5) {
            ZIP_Addressc[x] = "0" + ZIP_Addressc[x];
        }
        else if (ZIP_Addressc[x].slice(0, 5).trim().length < 4) {

            ZIP_Addressc[x] = "00" + ZIP_Addressc[x].slice(0, 5).trim();
        }
        //ElseIf Len(Trim(Left(ZIP_Addressc[x], 5))) < 3 ){
        else if (ZIP_Addressc[x].slice(0, 5).trim().length < 3) {
            ZIP_Addressc[x] = "000" + ZIP_Addressc.slice(0, 5).trim();
        }
        //ElseIf Len(Trim(Left(ZIP_Addressc[x], 5))) < 2 ){
        else if (ZIP_Addressc[x].slice(0, 5).trim().length < 2) {
            ZIP_Addressc[x] = "0000" + ZIP_Addressc[x].slice(0, 5).trim();
        }


        Emulsessiona.autECLPS.SendKeys(ZIP_Addressc[x].slice(0, 5), 6, 60);
        apiChka();

        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();

        //VerifyUSPS();

        if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("MASTER") > 0 ){
            VerifyUSPS();
        }
        
        Adress_Match(x);

        //'====================================(Updating vale on the screen)================

        if (Emulsessiona.autECLPS.GetText(2, 2, 5).trim() != "TAXID") {
            MacroOutput = MacroOutput + "ADDRESS ADD Screen not found. Macro stopped. ";
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            return;
        }
        
        //'if(ADDRESS_TYPE.split("|")[x].toUpperCase()) = "B" Or ADDRESS_TYPE.split("|")[x].toUpperCase()) = "C" ){
        if (ADDRESS_TYPE.split("|")[x].toUpperCase() == "B" || ADDRESS_TYPE.split("|")[x].toUpperCase() == "C") {
            if (DBA_NAME.split("|")[x] != "NA" && DBA_NAME.split("|")[x] != "") {
                Emulsessiona.autECLPS.SendKeys(DBA_NAME.split("|")[x], 12, 12);
            }
        }

        //if(ADDRESS_TYPE.split("|")[x].toUpperCase()) != "NA" ){
        
        Emulsessiona.autECLPS.SendKeys(ADDRESS_TYPE.split("|")[x], 11, 13);
        Emulsessiona.autECLPS.SendKeys(PS1.split("|")[x], 11, 52);

        EFF_DATE_Address = EFF_DATE_Address.replace(" ", ""); EFF_DATE_Address = EFF_DATE_Address.replace(" ", "");

        Emulsessiona.autECLPS.SendKeys(EFF_DATE_Address.slice(0, 2), 14, 7);
        Emulsessiona.autECLPS.SendKeys(EFF_DATE_Address.substring(4, 2), 14, 10);
        Emulsessiona.autECLPS.SendKeys(EFF_DATE_Address.substring(8, 4), 14, 13);
        
        for (var M in TELEPHONE_EXTNc) {

            TELEPHONE_EXTNc[M] = TELEPHONE_EXTNc[M].replace(" ", ""); TELEPHONE_EXTNc[M] = TELEPHONE_EXTNc[M].replace(" ", "");


            if (Emulsessiona.autECLPS.GetText(17, 2, 1).trim() == "") {

                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(0, 3), 17, 2);
                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(6, 3), 17, 6);
                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(10, 6), 17, 10);
                if (Extn.split("|")[M] != "") {
                    Emulsessiona.autECLPS.SendKeys(Extn.split("|")[M], 17, 16);
                } else {
                    Emulsessiona.autECLPS.SendKeys("0000", 17, 16);
                }
                
                Emulsessiona.autECLPS.SendKeys(PS2.split("|")[M], 17, 22);
                Emulsessiona.autECLPS.SendKeys(ADDR_TYPE.split("|")[M], 17, 25);
                continue;
            }
            if (Emulsessiona.autECLPS.GetText(17, 38, 1).trim() == "") {

                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(0, 3), 17, 38);
                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(6, 3), 17, 42);
                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(10, 6), 17, 46);
                if (Extn.split("|")[M] != "") {
                    Emulsessiona.autECLPS.SendKeys(Extn.split("|")[M], 17, 52);
                } else {
                    Emulsessiona.autECLPS.SendKeys("0000", 17, 52);
                }        
                Emulsessiona.autECLPS.SendKeys(PS2.split("|")[M], 17, 58);
                Emulsessiona.autECLPS.SendKeys(ADDR_TYPE.split("|")[M], 17, 61);
                continue;
            }
            
        }

        if (TELEPHONE_EXTN_FAX != "") {
            
            for (var N in TELEPHONE_EXTN_FAXc) {
                
                TELEPHONE_EXTN_FAXc[N] = TELEPHONE_EXTN_FAXc[N].replace(" ", ""); TELEPHONE_EXTN_FAXc[N] = TELEPHONE_EXTN_FAXc[N].replace(" ", "");

                if (Emulsessiona.autECLPS.GetText(17, 38, 1).trim() == "") {

                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(0, 3), 17, 38);//lest
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(6, 3), 17, 42);//mid
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(10, 6), 17, 46);//right
                    Emulsessiona.autECLPS.SendKeys("S", 17, 58);
                    Emulsessiona.autECLPS.SendKeys("F", 17, 61);
                    continue;
                }
                if (Emulsessiona.autECLPS.GetText(18, 2, 1).trim() == "") {

                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(0, 3), 18, 2);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(6, 3), 18, 6);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(10, 3), 18, 10);
                    Emulsessiona.autECLPS.SendKeys("S", 18, 22);
                    Emulsessiona.autECLPS.SendKeys("F", 18, 25);
                    continue;
                }

                if (Emulsessiona.autECLPS.GetText(18, 38, 1).trim() == "") {

                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(0, 3), 18, 38);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(6, 3), 18, 42);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(10, 6), 18, 46);
                    Emulsessiona.autECLPS.SendKeys("S", 18, 58);
                    Emulsessiona.autECLPS.SendKeys("F", 18, 61);
                    continue;
                }
            }
        }

        //(ADDRESS_TYPE.split("|")[x].toUpperCase())

        if ((CORRESPONDANCE.split("|")[x].toUpperCase()) != "NA") {
            Emulsessiona.autECLPS.SendKeys(CORRESPONDANCE.split("|")[x], 11, 80);
        }

        //'   if(UCase(Trim(PCP_BSAR)) = "P" ){
        //'    apiChka();
        //'    Call InfoGrab_CLN
        //'    apiChka();
        //'   }

        //'===========================I in function for the update======
        if (ADR.indexOf("|") > 0) {
            
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();


            //'***************NORMALIZED USPS MASTER ADDR ALERDY EXISTS******************

            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("NORMALIZED USPS MASTER ADDR")>=0) {
                if (MacroOutput = "") {
                    MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase() + " and bypassed. "
                } else {
                    MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase() + " and bypassed. ";
                }
                //'Emulsessiona.autECLPS.SendKeys ( "[PF4]");
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                return; //'remove
            }

            //'***************if(we have any Invalid TAX ID******************
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("INACTIVE TAXID")>=0) {
                if (MacroOutput = "") {
                    MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase() + ". ";
                } else {
                    MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase() + ". ";
                }
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return; //'remove
            }

            //'Effective Date is greater than or equal to TAXID Original Effective Date
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("EFF DATE MUST BE >= THE TAXID")>=0) {
                if (MacroOutput = "") {
                    MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase();
                } else {
                    MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase();
                }
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return; //'remove
            }

            //'Address not found in Code1 - as in the address input provided is incorrect
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("ADDR NOT FOUND IN CODE1")>=0) {
                if (MacroOutput = "") {
                    MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase();
                } else {
                    MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase();
                }
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return;//'remove
            }

            //'ENTER OVERRIDE = Y for ORIG ADDR
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("ENTER OVERRIDE = Y FOR ORIG ADDR:") >= 0) {
                if (MacroOutput = "") {
                    MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase();
                } else {
                    MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase();
                }
                Emulsessiona.autECLPS.SendKeys("[pf4]");
                apiChka();
                return;
            }

            //'Error handling for Invalid Value - Phone Type Values
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("INVALID VALUE - PHONE TYPE") >= 0) {
                Emulsessiona.autECLPS.SendKeys("PLSV", 17, 25);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }

            //'Address already loaded
            if (Emulsessiona.autECLPS.GetText(24, 2, 20).trim().toUpperCase().indexOf("ADDRESS")>= 0) {
                if (MacroOutput = "") {
                    MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 60).trim();
                } else {
                    MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 60).trim();
                }
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return; //'remove
            }

            //'STREET NOT IN ZIP, CANNOT BE VERIFIED
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("STREET NOT IN ZIP")>= 0) {
                if (MacroOutput = "") {
                    MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase()
                } else {
                    MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase()
                }
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return; //'remove
            }


            //ZIP CODE NOT FOUND IN CODE1 MASTER FILE
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("ZIP CODE NOT FOUND IN CODE1 MASTER FILE") >= 0) {
                if (MacroOutput = "") {
                    MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase();
                } else {
                    MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase();
                }
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return;//'remove
            }

            //'additional enter for error message DO YOU WANT TO ADD PHYSICIAN//'S ADDRESS
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("DO YOU WANT TO ADD")>=0) {
                //'Emulsessiona.autECLPS.SendKeys ( "[PF4]" );
                Emulsessiona.autECLPS.SendKeys("[Enter]");
                apiChka();
                apiChka();
            }

            //'additional enter for error message REMEMBER
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("REMEMBER")>=0) {
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }

            //'additional enter for error message GROUP RECORD WAS RE-ACTIVATED PER CANCEL DATE, ONLY
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("GROUP RECORD WAS RE-ACTIVATED")>=0) {
                if (MacroOutput = "") {
                    MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase() + " and bypassed. "
                } else {
                    MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase() + " and bypassed. "
                }
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }

            //'additional enter for error message DO YOU WANT TO ADD PHYSICIAN//'S ADDRESS
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("DO YOU WANT TO ADD")>=0) {
                //'Emulsessiona.autECLPS.SendKeys ( "[PF4]" );
                Emulsessiona.autECLPS.SendKeys("[Enter]");
                apiChka();
                apiChka();
            }

            //'additional enter for error message REMEMBER
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("REMEMBER")>=0) {
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }

            //if((Emulsessiona.autECLPS.GetText(2, 2, 15))) Like "*FUNCTIONS*" && x != UBound(piped) ){
            //if((Emulsessiona.autECLPS.GetText(2, 2, 15))) Like "*FUNCTIONS*" && x != UBound(piped) ){
            if ((Emulsessiona.autECLPS.GetText(2, 2, 15)).indexOf("FUNCTIONS")>= 0 ) {
                //if(ADDRESS_TYPE.split("|")[x].toUpperCase()) = "P" ){
                if (ADDRESS_TYPE.split("|")[x] = "P") {
                    //'Emulsessiona.autECLPS.SendKeys ( "[PF4]" );
                    //'apiChka();
                    Emulsessiona.autECLPS.SendKeys("A", 21, 8);
                    Emulsessiona.autECLPS.SendKeys("A", 21, 15);
                    Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
                    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
                    //'Emulsessiona.autECLPS.SendKeys ( Ma_ID, 21, 47
                   
                    if (ADDRESS_TYPE.trim().toUpperCase().indexOf("B") >= 0) {
                        Emulsessiona.autECLPS.SendKeys(NewMA_ID, 21, 47);
                    } else {
                        Emulsessiona.autECLPS.SendKeys(Ma_ID, 21, 47);
                    }
                    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
                    apiChka();
                    Emulsessiona.autECLPS.SendKeys("[enter]");
                    apiChka();
                }
            }

            //'NewMA_ID = ""
            //'NewSelection = ""
            //'adding additional function to pull the selection if(the Address type added is Bill || Combo
            //if (NewMA_ID = "") {
            //    if ((ADDRESS_TYPE.split("|")[x].toUpperCase() == "B" || ADDRESS_TYPE.split("|")[x].toUpperCase() == "C")) {
            //        apiChka();
            //        GetNewB_CAdd_Selection(x);
            //        apiChka();
            //        Emulsessiona.autECLPS.SendKeys("[pf4]");
            //        apiChka();
            //        //'Debug.Print NewMA_ID
            //        //'NewMA_ID = "000209325"
            //        Emulsessiona.autECLPS.SendKeys("A", 21, 8);
            //        Emulsessiona.autECLPS.SendKeys("A", 21, 15);
            //        Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
            //        Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
            //        Emulsessiona.autECLPS.SendKeys(NewMA_ID, 21, 47);
            //        Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
            //        apiChka();
            //        Emulsessiona.autECLPS.SendKeys("[enter]");
            //        apiChka();
            //    }
            //}

            if (NewMA_ID != "" && NewSelection == "") {
                Emulsessiona.autECLPS.SendKeys("A", 21, 8);
                Emulsessiona.autECLPS.SendKeys("A", 21, 15);
                Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
                Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
                //'Emulsessiona.autECLPS.SendKeys ( NewMA_ID, 21, 47
                Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }


            apiChka();
            apiChka();
            Emulsessiona.autECLPS.SendKeys("1", 19, 13);
            //'Emulsessiona.autECLPS.SendKeys ( NewSelection, 19, 13
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
            
        }

        //'if(last address is getting added - ){ last enter on address screen
        if (ADR.indexOf("|") <= 0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'NORMALIZED USPS MASTER ADDR ALERDY EXISTS
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("NORMALIZED USPS MASTER ADDR")>=0) {
            if (MacroOutput = "") {
                MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase() + " and bypassed. "
            } else {
                MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase() + " and bypassed. "
            }
            //'Emulsessiona.autECLPS.SendKeys ( "[PF4]"
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            //'return //'remove
        }

        //'Invalid TAX ID
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("INACTIVE TAXID")>=0) {
            if (MacroOutput = "") {
                MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase() + ". "
            } else {
                MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase() + ". "
            }
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return //'remove
        }

        //'Effective Date is greater than or equal to TAXID Original Effective Date
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("EFF DATE MUST BE >= THE TAXID")>=0) {
            if (MacroOutput = "") {
                MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase()
            } else {
                MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase()
            }
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return //'remove
        }

        //'Address not found in Code1 - as in the address input provided is incorrect
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("ADDR NOT FOUND IN CODE1")>=0) {
            if (MacroOutput = "") {
                MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase()
            } else {
                MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase()
            }
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return //'remove
        }

        //'STREET NOT IN ZIP, CANNOT BE VERIFIED
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("STREET NOT IN ZIP")>=0) {
            if (MacroOutput = "") {
                MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase()
            } else {
                MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase()
            }
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return //'remove
        }

        //ZIP CODE NOT FOUND IN CODE1 MASTER FILE
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("ZIP CODE NOT FOUND IN CODE1 MASTER FILE") >= 0) {
            if (MacroOutput = "") {
                MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase();
            } else {
                MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase();
            }
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return;//'remove
        }


        //'ENTER OVERRIDE = Y for ORIG ADDR
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("ENTER OVERRIDE = Y FOR ORIG ADDR:") >= 0) {
            if (MacroOutput = "") {
                MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase()
            } else {
                MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 65).trim().toUpperCase()
            }
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            apiChka();
            return;
        }

        //'Error handling for Invalid Value - Phone Type Values
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("INVALID VALUE - PHONE TYPE") >= 0) {
            Emulsessiona.autECLPS.SendKeys("PLSV", 17, 25);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'Address already loaded
        if (Emulsessiona.autECLPS.GetText(24, 2, 20).trim().toUpperCase().indexOf("ADDRESS")>=0) {
            if (MacroOutput = "") {
                MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 60).trim();
            } else {
                MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 60).trim();
            }
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return //'remove
        }
                //'additional enter for error message DO YOU WANT TO ADD PHYSICIAN//'S ADDRESS
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("DO YOU WANT TO ADD")>=0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'additional enter for error message REMEMBER
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("REMEMBER")>=0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'additional enter for error message GROUP RECORD WAS RE-ACTIVATED PER CANCEL DATE, ONLY
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("GROUP RECORD WAS RE-ACTIVATED")>=0) {
            if (MacroOutput == "") {
                MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase() + " and bypassed. ";
            }
            else {
                MacroOutput = MacroOutput + Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase() + " and bypassed. ";
            }
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'additional enter for error message DO YOU WANT TO ADD PHYSICIAN//'S ADDRESS
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("DO YOU WANT TO ADD")>=0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'additional enter for error message REMEMBER
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("REMEMBER")>=0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        if (Emulsessiona.autECLPS.GetText(2, 2, 15).trim().toUpperCase().indexOf("FUNCTIONS") >= 0 ) {
            Address_Multiple_Screen = true;
            MacroOutput = "Address has been loaded"; 
            apiChka();
            apiChka();
            //'Application.Wait (Now + TimeValue("00:00:01"))
            //Exit For
            //break
        }

        apiChka();
        apiChka();

        
    }
    //'adding additional function to pull the selection if(the Address type added is Bill || Combo
    //if(NewMA_ID = "" ){
    //    if((ADDRESS_TYPE.split("|")[x].toUpperCase()) == "B" || (ADDRESS_TYPE.split("|")[x].toUpperCase()) == "C") {
    //        GetNewB_CAdd_Selection(x);
    //        apiChka();
    //        apiChka();
    //        //'Application.Wait (Now + TimeValue("00:00:01"))
    //    }
    //}

    
    if(Emulsessiona.autECLPS.GetText(4, 13, 5).trim().toUpperCase().indexOf("NAME")>=0){
        //'Emulsessiona.autECLPS.SendKeys ( "[PF2]"
        Address_Multiple_Screen = true;
        apiChka();
        apiChka();
        //'Application.Wait (Now + TimeValue("00:00:01"))
        return
    }
    
}

function VerifyUSPS() {

    if (confirm('Have you verified this address with USPS ?')) {

        if (confirm('Has approval been given by team lead or designated person for a code 1 override ?')) {




        } else {
            alert('Please obtain approval for the code 1 override');
        }

       
    } else {
        alert('Please verify address with USPS');

    }


}



function GetNewB_CAdd_Selection(x) {

    GetNewB_CAdd_Selection = false;
    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");
    Emulsessiona.autECLPS.SendKeys(MPIN, 21,31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();

    do {


        for (i = 7; i < 17; i =+ 3) {
            
            if (Emulsessiona.autECLPS.GetText(i, 5, 30).trim() == ADRc[x]) {
                NewMA_ID = Emulsessiona.autECLPS.GetText(i + 1, 36, 9);
                NewSelection = Emulsessiona.autECLPS.GetText(i, 2, 1);
                apiChka();
                return;
            } else if (Emulsessiona.autECLPS.GetText(i + 1 , 36, 9).trim() == Ma_ID[x]){

                NewMA_ID = Emulsessiona.autECLPS.GetText(i + 1, 36, 9);
                NewSelection = Emulsessiona.autECLPS.GetText(i, 2, 1);
                apiChka();
                return;

            }

            
            //if (i >= 16 && Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("THIS IS THE LAST PAGE") < 0) {

            Emulsessiona.autECLPS.SendKeys("[pf8]");
            apiChka();
                //i = -2;
                //if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("THIS IS THE LAST PAGE") > 0) {
                //    break;
                //}
            
        }

    } while (Emulsessiona.autECLPS.GetText(24, 1, 60).indexOf("THIS IS THE LAST PAGE") < 0)

}

function Adress_Match(x) {

    Address_Match = false; 
    var locator;

    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("MASTER") >= 0) {
        Emulsessiona.autECLPS.SendKeys("S", 6, 3);
        Address_Match = true;
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();

    } else {
        
        do {

            for (cnt = 7; cnt <= 18; cnt++) {

                if (ADR.indexOf("|") > 0) {

                    if (Emulsessiona.autECLPS.GetText(cnt, 5, 33).trim() == ADRc[x].trim().toUpperCase() && Emulsessiona.autECLPS.GetText(cnt, 60, 5).trim() == ZIP_Addressc[x].trim().substring(0, 5)) {

                        if (Emulsessiona.autECLPS.GetText(cnt, 57, 2) == STATE_Addressc[x].trim().toUpperCase() && Emulsessiona.autECLPS.GetText(cnt, 38, 16).trim() == CITY_Addressc[x].trim().toUpperCase().substring(0, 16)) {

                            Emulsessiona.autECLPS.SendKeys("S", cnt, 3);
                            Address_Match = true;
                            Emulsessiona.autECLPS.SendKeys("[enter]");
                            apiChka();
                            return;
                        }
                    }

                } else {

                    if (Emulsessiona.autECLPS.GetText(cnt, 5, 33).trim() == ADR.trim().toUpperCase() && Emulsessiona.autECLPS.GetText(cnt, 60, 5) == ZIP_Address.trim().substring(0, 5)) {

                        if (Emulsessiona.autECLPS.GetText(cnt, 57, 2).trim() == STATE_Address.trim().toUpperCase() && Emulsessiona.autECLPS.GetText(cnt, 38, 16).trim() == CITY_Address.trim().toUpperCase()) {
                            Emulsessiona.autECLPS.SendKeys("S", cnt, 3);
                            Address_Match = true;
                            Emulsessiona.autECLPS.SendKeys("[enter]");
                            apiChka();
                            return;
                        }
                    }
                }
            }

            Emulsessiona.autECLPS.SendKeys("[PF8]");
            apiChka();

        } while (Emulsessiona.autECLPS.GetText(24, 1, 60).indexOf("NO MORE PAGES TO VIEW") < 0);

        if (Emulsessiona.autECLPS.GetText(24, 2, 30).indexOf("NO MORE PAGES TO VIEW") >= 0) {

            Emulsessiona.autECLPS.SendKeys("S", 6, 3);
            Address_Match = true;
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
        }
    }
}

function InfoGrab_CLN() {

    if (addAddress != true) {
        return;
    }
    
    apiChka();    
    Emulsessiona.autECLPS.SendKeys("[pf4]");
    apiChka(); 
    Emulsessiona.autECLPS.SendKeys ("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys ("M", 21, 15);
    Emulsessiona.autECLPS.SendKeys ("Z", 21, 23);

    Emulsessiona.autECLPS.SendKeys("[erase eof]", 21, 31);
    Emulsessiona.autECLPS.SendKeys (MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[erase eof]", 23, 37);
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("1", 19, 13);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
    //'checking whether screen is loaded or not
    if (Emulsessiona.autECLPS.GetText(2, 27, 20).trim().indexOf("CATEGORY: PHYS") < 0 ){

        MacroOutput = MacroOutput + "\n" + "Physician Main Screen not loaded in time to grab the CLN Data. "
        Emulsessiona.autECLPS.SendKeys("[PF4]");
        return;
    } else {

        FNameCLN = Emulsessiona.autECLPS.GetText(4, 10, 20).trim();
        LNameCLN = Emulsessiona.autECLPS.GetText(3, 10, 20).trim();
        MNameCLN = Emulsessiona.autECLPS.GetText(4, 41, 10).trim();
        NSFXCLN = Emulsessiona.autECLPS.GetText(4, 71, 5).trim();
        DegreeCLN = Emulsessiona.autECLPS.GetText(7, 10, 3).trim();

        CLN = FNameCLN + " " + MNameCLN + " " + LNameCLN + " " + NSFXCLN + " " + DegreeCLN;

        Emulsessiona.autECLPS.SendKeys("[PF4]");
        apiChka();
        
    }    
}



function Adr_Serch_With_Maid(){
    Adr_Serch_With_Maid_1 = false;

    
    //piped = Split(Ma_ID, "|");
    //P_Sxl = P_S.split(",");
    if (Ma_ID != "") {
        piped = Ma_ID.split(",");
    } else {
        piped = ptiMAID.split(",");
    }
    

    TELEPHONE_EXTNc = TELEPHONE_EXTN.split(",");
    TELEPHONE_EXTN_FAXc = TELEPHONE_EXTN_FAX.split(",");

    //'        if(Len(Ma_ID) = 8 ){
    //'            Ma_ID = "0" + Ma_ID
    //'        ElseIf Len(Ma_ID) = 7 ){
    //'            Ma_ID = "00" + Ma_ID
    //'        ElseIf Len(Ma_ID) = 6 ){
    //'            Ma_ID = "000" + Ma_ID
    //'        ElseIf Len(Ma_ID) = 5 ){
    //'            Ma_ID = "0000" + Ma_ID
    //'        ElseIf Len(Ma_ID) = 4 ){
    //'            Ma_ID = "00000" + Ma_ID
    //'        ElseIf Len(Ma_ID) = 3 ){
    //'            Ma_ID = "000000" + Ma_ID
    //'        }

    //For x = 0 To UBound(piped)
    for (var x in piped) {

        apiChka();
        Main_SCREEN();

        if (Main_SCREEN == false) {
            return;
        }
        
        if (piped[x].length == 8) {
            piped[x] = "0" + piped[x];
        }
        else if (piped[x].length == 7) {
            piped[x] = "00" + piped[x];
        }
        else if (piped[x].length == 6) {
            piped[x] = "000" + piped[x];
        }
        else if (piped[x].length == 5) {
            piped[x] = "0000" + piped[x];
        }
        else if (piped[x].length == 4) {
            piped[x] = "00000" + piped[x];
        }
        else if (piped[x].length == 3) {
            piped[x] = "000000" + piped[x];
        }

        Emulsessiona.autECLPS.SendKeys(piped[x], 6, 71);
        apiChka();
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();

        if (Emulsessiona.autECLPS.GetText(24, 2, 54).trim().indexOf("NO MATCH FOUND") >= 0) {
            MacroOutput = "NO MATCH FOUND ON MASTER ADDRESS FOR SEARCH CRITERIA in *ADDRESS SELECTION* Screen ."
            return;
        }

        Emulsessiona.autECLPS.SendKeys("S", 7, 3)
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();


        //'====================================(Updating value on the screen)================


        if (Emulsessiona.autECLPS.GetText(2, 2, 5).trim() != "TAXID") {
            MacroOutput = MacroOutput + "ADDRESS ADD Screen not found. Macro stopped. ";
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            return;
        }

        //'if(ADDRESS_TYPE.split("|")[x].toUpperCase()) = "B" Or ADDRESS_TYPE.split("|")[x].toUpperCase()) = "C" ){
        if (ADDRESS_TYPE.split(",")[x].toUpperCase() == "B" || ADDRESS_TYPE.split(",")[x].toUpperCase() == "C") {
            if (DBA_NAME.split(",")[x] != "NA" && DBA_NAME.split(",")[x] != "") {
                Emulsessiona.autECLPS.SendKeys(DBA_NAME.split(",")[x], 12, 12);
            }
        }

        //if(ADDRESS_TYPE.split("|")[x].toUpperCase()) != "NA" ){

        AddMA_ID_new = Emulsessiona.autECLPS.GetText(3, 58, 9).trim();
        Emulsessiona.autECLPS.SendKeys(ADDRESS_TYPE.split(",")[x], 11, 13);
        Emulsessiona.autECLPS.SendKeys(PS1.split(",")[x], 11, 52);
        
        EFF_DATE_Address = EFF_DATE_Address.replace(" ", ""); EFF_DATE_Address = EFF_DATE_Address.replace(" ", "");

        Emulsessiona.autECLPS.SendKeys(EFF_DATE_Address.slice(0, 2), 14, 7);
        Emulsessiona.autECLPS.SendKeys(EFF_DATE_Address.substring(4, 2), 14, 10);
        Emulsessiona.autECLPS.SendKeys(EFF_DATE_Address.substring(8, 4), 14, 13);

        for (var M in TELEPHONE_EXTNc) {

            TELEPHONE_EXTNc[M] = TELEPHONE_EXTNc[M].replace(" ", ""); TELEPHONE_EXTNc[M] = TELEPHONE_EXTNc[M].replace(" ", "");


            if (Emulsessiona.autECLPS.GetText(17, 2, 1).trim() == "") {

                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(0, 3), 17, 2);
                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(6, 3), 17, 6);
                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(10, 6), 17, 10);
                if (Extn.split(",")[M] != "") {
                    Emulsessiona.autECLPS.SendKeys(Extn.split(",")[M], 17, 16);
                } else {
                    Emulsessiona.autECLPS.SendKeys("0000", 17, 16);
                }
                
                Emulsessiona.autECLPS.SendKeys(PS2.split(",")[M], 17, 22);
                Emulsessiona.autECLPS.SendKeys(ADDR_TYPE.split(",")[M], 17, 25);
                continue;
            }
            if (Emulsessiona.autECLPS.GetText(17, 38, 1).trim() == "") {

                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(0, 3), 17, 38);
                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(6, 3), 17, 42);
                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(10, 6), 17, 46);
                if (Extn.split(",")[M] != "") {
                    Emulsessiona.autECLPS.SendKeys(Extn.split(",")[M], 17, 52);
                } else {
                    Emulsessiona.autECLPS.SendKeys("0000", 17, 52);
                }
                
                Emulsessiona.autECLPS.SendKeys(PS2.split(",")[M], 17, 58);
                Emulsessiona.autECLPS.SendKeys(ADDR_TYPE.split(",")[M], 17, 61);
                continue;
            }

        }

        if (TELEPHONE_EXTN_FAX != "") {

            for (var N in TELEPHONE_EXTN_FAXc) {

                TELEPHONE_EXTN_FAXc[N] = TELEPHONE_EXTN_FAXc[N].replace(" ", ""); TELEPHONE_EXTN_FAXc[N] = TELEPHONE_EXTN_FAXc[N].replace(" ", "");

                if (Emulsessiona.autECLPS.GetText(17, 38, 1).trim() == "") {

                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(0, 3), 17, 38);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(6, 3), 17, 42);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(10, 6), 17, 46);
                    Emulsessiona.autECLPS.SendKeys("0000", 17, 52);
                    Emulsessiona.autECLPS.SendKeys("S", 17, 58);
                    Emulsessiona.autECLPS.SendKeys("F", 17, 61);
                    continue;
                }
                if (Emulsessiona.autECLPS.GetText(18, 2, 1).trim() == "") {

                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(0, 3), 18, 2);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(6, 3), 18, 6);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(10, 3), 18, 10);
                    Emulsessiona.autECLPS.SendKeys("0000", 18, 16);
                    Emulsessiona.autECLPS.SendKeys("S", 18, 22);
                    Emulsessiona.autECLPS.SendKeys("F", 18, 25);
                    continue;
                }

                if (Emulsessiona.autECLPS.GetText(18, 38, 1).trim() == "") {

                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(0, 3), 18, 38);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(6, 3), 18, 42);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(10, 6), 18, 46);
                    Emulsessiona.autECLPS.SendKeys("0000", 18, 52);
                    Emulsessiona.autECLPS.SendKeys("S", 18, 58);
                    Emulsessiona.autECLPS.SendKeys("F", 18, 61);
                    continue;
                }
            }
        }

        //(ADDRESS_TYPE.split("|")[x].toUpperCase())

        if ((CORRESPONDANCE.split("|")[x].toUpperCase()) != "NA") {
            Emulsessiona.autECLPS.SendKeys(CORRESPONDANCE.split("|")[x], 11, 80);
        }

        //'   if(UCase(Trim(PCP_BSAR)) = "P" ){
        //'    apiChka();
        //'    Call InfoGrab_CLN
        //'    apiChka();
        //'   }

        //'===========================I in function for the update======
        if (Ma_ID.indexOf("|") > 0) {
            
            //Emulsessiona.autECLPS.SendKeys("I", 21, 8);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();


            //'***************NORMALIZED USPS MASTER ADDR ALERDY EXISTS******************

            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("NORMALIZED USPS MASTER ADDR") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                return //'remove
            }

            //'***************if(we have any Invalid TAX ID******************
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("INACTIVE TAXID") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return //'remove
            }

            //'Effective Date is greater than or equal to TAXID Original Effective Date
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("EFF DATE MUST BE >= THE TAXID") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return //'remove
            }

            //'Address not found in Code1 - as in the address input provided is incorrect
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("ADDR NOT FOUND IN CODE1") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return //'remove
            }

            //'ENTER OVERRIDE = Y for ORIG ADDR
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("ENTER OVERRIDE = Y FOR ORIG ADDR:") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[pf4]");
                apiChka();
                return
            }

            //'Error handling for Invalid Value - Phone Type Values
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("INVALID VALUE - PHONE TYPE") >= 0) {
                Emulsessiona.autECLPS.SendKeys("PLSV", 17, 25);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }

            //'Address already loaded
            if (Emulsessiona.autECLPS.GetText(24, 2, 20).trim().toUpperCase().indexOf("ADDRESS") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return //'remove
            }

            //'STREET NOT IN ZIP, CANNOT BE VERIFIED
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("STREET NOT IN ZIP") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return //'remove
            }

            //ZIP CODE NOT FOUND IN CODE1 MASTER FILE
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("ZIP CODE NOT FOUND IN CODE1 MASTER FILE") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return;//'remove
            }

            //'additional enter for error message DO YOU WANT TO ADD PHYSICIAN//'S ADDRESS
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("DO YOU WANT TO ADD") >= 0) {
                //'Emulsessiona.autECLPS.SendKeys ( "[PF4]" );
                Emulsessiona.autECLPS.SendKeys("[Enter]");
                apiChka();
                apiChka();
            }

            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("FQHC") >= 0) {
                Emulsessiona.autECLPS.SendKeys ("N",24,71);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("[Enter]");
                apiChka();
                apiChka();
            }
            
            //'additional enter for error message REMEMBER
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("REMEMBER") >= 0) {
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }

            //'additional enter for error message GROUP RECORD WAS RE-ACTIVATED PER CANCEL DATE, ONLY
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("GROUP RECORD WAS RE-ACTIVATED") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }

            //'additional enter for error message DO YOU WANT TO ADD PHYSICIAN//'S ADDRESS
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("DO YOU WANT TO ADD") >= 0) {
                //'Emulsessiona.autECLPS.SendKeys ( "[PF4]" );
                Emulsessiona.autECLPS.SendKeys("[Enter]");
                apiChka();
                apiChka();
            }

            //'additional enter for error message REMEMBER
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("REMEMBER") >= 0) {
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }

            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("VALUES ARE") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return; //'remove
            }

            if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("MUST ADD ONE PRIMARY PHONE NUMBER") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return; //'remove
            }

            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("INVALID VALUE") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return; //'remove
            }
            
            //if (Emulsessiona.autECLPS.GetText(2, 2, 15).trim().indexOf("FUNCTIONS") >= 0) {
            //    //if(ADDRESS_TYPE.split("|")[x].toUpperCase()) = "P" ){
            //    if (ADDRESS_TYPE.split("|")[x] == "P") {
            //        //'Emulsessiona.autECLPS.SendKeys ( "[PF4]" );
            //        //'apiChka();
            //        Emulsessiona.autECLPS.SendKeys("A", 21, 8);
            //        Emulsessiona.autECLPS.SendKeys("A", 21, 15);
            //        Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
            //        Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
            //        //'Emulsessiona.autECLPS.SendKeys ( Ma_ID, 21, 47
            //        if (ADDRESS_TYPE.split("|")[x].toUpperCase() == "B") {
            //            Emulsessiona.autECLPS.SendKeys(NewMA_ID, 21, 47);
            //        } else {
            //            Emulsessiona.autECLPS.SendKeys(Ma_ID, 21, 47);
            //        }
            //        Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
            //        apiChka();
            //        Emulsessiona.autECLPS.SendKeys("[enter]");
            //        apiChka();
            //    }
            //}

          
            ////'adding additional function to pull the selection if(the Address type added is Bill || Combo
            //if (NewMA_ID == "") {
            //    if ((ADDRESS_TYPE.split("|")[x].toUpperCase() == "B" || ADDRESS_TYPE.split("|")[x].toUpperCase() == "C")) {
            //        apiChka();
            //        GetNewB_CAdd_Selection(x);
            //        apiChka();
            //        Emulsessiona.autECLPS.SendKeys("[pf4]");
            //        apiChka();                   
            //        Emulsessiona.autECLPS.SendKeys("A", 21, 8);
            //        Emulsessiona.autECLPS.SendKeys("A", 21, 15);
            //        Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
            //        Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
            //        Emulsessiona.autECLPS.SendKeys(NewMA_ID, 21, 47);
            //        Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
            //        apiChka();
            //        Emulsessiona.autECLPS.SendKeys("[enter]");
            //        apiChka();
            //    }
            //}

            //if (NewMA_ID != "" && NewSelection == "") {
            //    Emulsessiona.autECLPS.SendKeys("A", 21, 8);
            //    Emulsessiona.autECLPS.SendKeys("A", 21, 15);
            //    Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
            //    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
            //    //'Emulsessiona.autECLPS.SendKeys ( NewMA_ID, 21, 47
            //    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
            //    apiChka();
            //    Emulsessiona.autECLPS.SendKeys("[enter]");
            //    apiChka();
            //}


            apiChka();
            apiChka();
            Emulsessiona.autECLPS.SendKeys("1", 19, 13);
            //'Emulsessiona.autECLPS.SendKeys ( NewSelection, 19, 13
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
            
        }
        
        //'if(last address is getting added - ){ last enter on address screen
        if (Ma_ID.indexOf("|") <= 0) {
            //Emulsessiona.autECLPS.SendKeys("I",21,8);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'NORMALIZED USPS MASTER ADDR ALERDY EXISTS
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("NORMALIZED USPS MASTER ADDR")>=0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            //'Emulsessiona.autECLPS.SendKeys ( "[PF4]"
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            //'return //'remove
        }

        //'Invalid TAX ID
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("INACTIVE TAXID") >= 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return //'remove
        }

        //'Effective Date is greater than or equal to TAXID Original Effective Date
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("EFF DATE MUST BE >= THE TAXID")>=0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return //'remove
        }

        //'Address not found in Code1 - as in the address input provided is incorrect
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("ADDR NOT FOUND IN CODE1")>=0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return //'remove
        }

        //'STREET NOT IN ZIP, CANNOT BE VERIFIED
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("STREET NOT IN ZIP")>=0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return //'remove
        }

        //ZIP CODE NOT FOUND IN CODE1 MASTER FILE
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("ZIP CODE NOT FOUND IN CODE1 MASTER FILE") >= 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return;//'remove
        }

        //'ENTER OVERRIDE = Y for ORIG ADDR
        if(Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("ENTER OVERRIDE = Y FOR ORIG ADDR:") >= 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            apiChka();
            return
        }

        //'Error handling for Invalid Value - Phone Type Values
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("INVALID VALUE - PHONE TYPE") >= 0) {
            Emulsessiona.autECLPS.SendKeys("PLSV", 17, 25);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'Address already loaded
        if (Emulsessiona.autECLPS.GetText(24, 2, 20).trim().toUpperCase().indexOf("ADDRESS")>=0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return //'remove
        }
        //'additional enter for error message DO YOU WANT TO ADD PHYSICIAN//'S ADDRESS
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("DO YOU WANT TO ADD")>=0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("FQHC") >= 0) {
            Emulsessiona.autECLPS.SendKeys("N", 24, 71);
            apiChka();
            Emulsessiona.autECLPS.SendKeys("[Enter]");
            apiChka();
            apiChka();
        }
        
        //'additional enter for error message REMEMBER
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("REMEMBER")>=0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'additional enter for error message GROUP RECORD WAS RE-ACTIVATED PER CANCEL DATE, ONLY
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("GROUP RECORD WAS RE-ACTIVATED")>=0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'additional enter for error message DO YOU WANT TO ADD PHYSICIAN//'S ADDRESS
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("DO YOU WANT TO ADD")>=0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'additional enter for error message REMEMBER
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("REMEMBER")>=0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("VALUES ARE") >= 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return; //'remove
        }

        if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("MUST ADD ONE PRIMARY PHONE NUMBER") >= 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return; //'remove
        }

        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("INVALID VALUE") >= 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return; //'remove
        }

        if (Emulsessiona.autECLPS.GetText(2, 2, 15).trim().toUpperCase().indexOf("FUNCTIONS")>=0) {
            Adr_Serch_With_Maid_1 = true;
            addAddress = true;
            MacroOutput = "Address has been Loaded";
            apiChka();
            apiChka();
            //'Application.Wait (Now + TimeValue("00:00:01"))
            //Exit For
            //break
        }

        apiChka();
        apiChka();

        //Next
    }

    //'adding additional function to pull the selection if(the Address type added is Bill or Combo
    //if (NewMA_ID = "") {
    //    if (ADDRESS_TYPE.split("|")[x].toUpperCase() == "B" || ADDRESS_TYPE.split("|")[x].toUpperCase() == "C") {
    //        GetNewB_CAdd_Selection(x);
    //        apiChka();
    //        apiChka();
    //        //'Application.Wait (Now + TimeValue("00:00:01"))

    //    }
    //}


    if (Emulsessiona.autECLPS.GetText(4, 13, 5).trim().toUpperCase().indexOf("NAME") >= 0) {
        //'Emulsessiona.autECLPS.SendKeys ( "[PF2]"
        Adr_Serch_With_Maid = true;
        apiChka();
        //'Application.Wait (Now + TimeValue("00:00:01"))
        //return
    }

}

var MAID = "";
var BAID = "";

function UHCIID_Screen(){
    UHCIID_Screen = false;

    if (addAddress != true) {
        return;
    }

    if (ADDRESS_TYPE == "P" && Div != "" && orphan == true) {// if this is an orphan BILL assredd

        GotoLoadPLSV();
        if (LoadPLSV == true) {
            return;
        }
        
    }

    if (ADDRESS_TYPE == "P" && PS1 == "P") {// if primary PLSV address
        UpdatePAID();
        return;
    }
    
    if (Div == "") {
        return;
    }
    
    if (ADDRESS_TYPE == "P") {// or it will update UHCID DIVs normally
        return;
    } else if (ADDRESS_TYPE == "CRED") {
        return;
    } else if (ADDRESS_TYPE == "MAIL") {
        return;
    }


    apiChka();
    apiChka();
    
    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    //to get MAID and BAID number of newlly added address
    var MABAID = GetBillingMABAID();
    MAID = MABAID.split("-")[0];
    BAID = MABAID.split("-")[1];

    //to get primary PLSV PAID number
    getPrimaryPLSV();
    
    Emulsessiona.autECLPS.SendKeys("A", 21, 8);
    Emulsessiona.autECLPS.SendKeys("U", 21, 15);
    Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
    Emulsessiona.autECLPS.SendKeys("[erase eof]", 21, 31);
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[erase eof]", 23, 37);
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("1", 19, 13);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();


    if (Emulsessiona.autECLPS.GetText(6, 2, 3) == "SEL") {
        Cosmos_Demographics();
        UHCIID_Screen = true;
    }
    else {

        if (MacroOutput == "") {
            MacroOutput = "UHCID Screen not found. Macro stopped! ";
        }
        else {
            MacroOutput = MacroOutput + "UHCID Screen not found. Macro stopped! ";
            return;
        }
    }
    

}
var ScreenOk;
var Address_Store_Screen;

function Address_Store_Screen(){

    if (addAddress != true) {
        return;
    }
    
    ScreenOk = false;
    Address_Store_Screen = false;

    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");
    Emulsessiona.autECLPS.SendKeys( MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();
    Emulsessiona.autECLPS.SendKeys( "[enter]");
    apiChka();
    
    
    adrpti = ADR.split("|");
    CITY_pti = CITY_Address.split("|");
    STATE_pti = STATE_Address.split("|");
    ZIP_pti = ZIP_Address.split("|");

    
 //osasco

    if (ADR != "") {

        for (x in adrpti) {

            if (ZIP_pti[x].indexOf("-") > 0) {
                ZIP_pti[x] = ZIP_pti[x].replace("-", " ");
            }
            
            do {
                for (var cnt = 7; cnt < 17; cnt += 3) {

                    if (Emulsessiona.autECLPS.GetText(cnt, 5, 33).trim() == adrpti[x]) {
                        if (Emulsessiona.autECLPS.GetText(cnt + 1, 5, 30).trim().split(",")[0] == CITY_pti[x]) {
                            if (Emulsessiona.autECLPS.GetText(cnt + 1, 5, 30).trim().split(",")[1].trim().split(" ")[0] == STATE_pti[x]) {
                                if (Emulsessiona.autECLPS.GetText(cnt + 1, 5, 30).trim().split(",")[1].trim().split(" ")[1].split("-")[0] == ZIP_pti[x].split(" ")[0]) {

                                    AddressSNO_new = Emulsessiona.autECLPS.GetText(cnt, 2, 1).trim();
                                    AddressLine1_new = Emulsessiona.autECLPS.GetText(cnt, 5, 30).trim();
                                    AddressLine2_new = Emulsessiona.autECLPS.GetText(cnt + 1, 5, 30).trim();                                    
                                    StateC_new = AddressLine2_new.split(",")[1].trim(); StateC_new = StateC_new.split(" ")[0].trim();
                                    CityC_new = Emulsessiona.autECLPS.GetText(cnt + 1, 5, 30).split(",")[0];
                                    ZipC_new = AddressLine2_new.split(",")[1].trim().split(" ")[1];
                                    AddressTypeC_new = Emulsessiona.autECLPS.GetText(cnt, 38, 4).trim();
                                    AddressIdC_new = Emulsessiona.autECLPS.GetText(cnt + 1, 36, 14).trim();
                                    phoneC_new = Emulsessiona.autECLPS.GetText(cnt, 52, 12).trim();
                                    phoneTypeC_new = Emulsessiona.autECLPS.GetText(cnt, 65, 1).trim();
                                    AddMA_ID_new = Emulsessiona.autECLPS.GetText(cnt + 1, 36, 9).trim();
                                    AddBillA_ID_new = Emulsessiona.autECLPS.GetText(cnt + 1, 46, 4).trim();

                                    Address_Store_Screen = true;
                                    return;

                                }
                            }
                        }
                    }
                    
                }

                Emulsessiona.autECLPS.Sendkeys("[pf8]");
                apiChka();

            } while (Emulsessiona.autECLPS.GetText(24, 2, 60).trim() != "THIS IS THE LAST PAGE");

        }

    } else {

        var maidpti;

        if (Ma_ID != "") {
            maidpti = Ma_ID.split("|");
        } else {
            maidpti = ptiMAID;
        }
        
        for (x in maidpti) {

            do {
                for (var cnt = 7; cnt < 17; cnt += 3) {

                    if (Emulsessiona.autECLPS.GetText(cnt + 1, 36, 9).trim() == maidpti[x]) {
                        //if (Emulsessiona.autECLPS.GetText(cnt + 1, 5, 30).trim().split(",")[0] == CITY_pti[x]) {
                        //    if (Emulsessiona.autECLPS.GetText(cnt + 1, 5, 30).trim().split(" ")[1] == STATE_pti[x]) {
                        //        if (Emulsessiona.autECLPS.GetText(cnt + 1, 5, 30).trim().split(" ")[2].replace("-", " ") == ZIP_pti[x]) {

                        AddressSNO_new = Emulsessiona.autECLPS.GetText(cnt, 2, 1).trim();
                        AddressLine1_new = Emulsessiona.autECLPS.GetText(cnt, 5, 30).trim();
                        AddressLine2_new = Emulsessiona.autECLPS.GetText(cnt + 1, 5, 30).trim();                        
                        StateC_new = AddressLine2_new.split(",")[1].trim(); StateC_new = StateC_new.split(" ")[0].trim();
                        CityC_new = Emulsessiona.autECLPS.GetText(cnt + 1, 5, 30).split(",")[0];
                        ZipC_new = AddressLine2_new.split(",")[1].trim().split(' ')[1];
                        AddressTypeC_new = Emulsessiona.autECLPS.GetText(cnt, 38, 4).trim();
                        AddressIdC_new = Emulsessiona.autECLPS.GetText(cnt + 1, 36, 14).trim();
                        phoneC_new = Emulsessiona.autECLPS.GetText(cnt, 52, 12).trim();
                        phoneTypeC_new = Emulsessiona.autECLPS.GetText(cnt, 65, 1).trim();
                        AddMA_ID_new = Emulsessiona.autECLPS.GetText(cnt + 1, 36, 9).trim();
                        AddBillA_ID_new = Emulsessiona.autECLPS.GetText(cnt + 1, 46, 4).trim();

                        Address_Store_Screen = true;
                        return;

                                //}
                            //}
                        //}
                    }
                    
                }

                Emulsessiona.autECLPS.Sendkeys("[pf8]");
                apiChka();

            } while (Emulsessiona.autECLPS.GetText(24, 2, 60).trim() != "THIS IS THE LAST PAGE");

        }
        
    }
    
}

var OFFICE_LIMITATION_SCREENadd = function () {
    OFFICE_LIMITATION_SCREENadd = false;

    if (addAddress != true) {
        return;
    }

    apiChka();
    
    Emulsessiona.autECLPS.SendKeys("[pf3]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M", 21, 15);
    Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
    Emulsessiona.autECLPS.SendKeys("[erase eof]", 21, 31);
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    Emulsessiona.autECLPS.SendKeys("[erase eof]", 23, 37);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    if (ptiMAID != "") {
        Emulsessiona.autECLPS.SendKeys("[erase eof]", 21, 47);
        apiChka();
        Emulsessiona.autECLPS.SendKeys(ptiMAID, 21, 47);
    } else if (MAID != "") {
        Emulsessiona.autECLPS.SendKeys("[erase eof]", 21, 47);
        apiChka();
        Emulsessiona.autECLPS.SendKeys(MAID, 21, 47);
    } else if (AddMA_ID_new != "") {
        Emulsessiona.autECLPS.SendKeys("[erase eof]", 21, 47);
        apiChka();
        Emulsessiona.autECLPS.SendKeys(AddMA_ID_new, 21, 47);
    } else if (Ma_ID != "") {
        Emulsessiona.autECLPS.SendKeys("[erase eof]", 21, 47);
        apiChka();
        Emulsessiona.autECLPS.SendKeys(Ma_ID, 21, 47);

    }

    apiChka();
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();

    if (Emulsessiona.autECLPS.gettext(24, 2, 20).trim().indexOf("NO DATA") >= 0) {
        MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.gettext(24, 2, 60).trim();
        return;

    }

    ILZ_Screen_Changeadd();

    if (LangData != true && ContactData != true && CommData != true && MondayOpen1 == "") {
        return;
    }


    Emulsessiona.autECLPS.SendKeys("1");
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[pf4]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[pf4]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("L", 21, 15);
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("1");
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();

    Emulsessiona.autECLPS.SendKeys("C", 21, 8);
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();
    
    Limitation_screen_Procesuresadd();

    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();

    if (Emulsessiona.autECLPS.gettext(24, 2, 1) != " ") {
        Err = (Emulsessiona.autECLPS.gettext(24, 2, 70)).trim();
        MacroOutput = MacroOutput + "\n" + Err;
        Emulsessiona.autECLPS.SendKeys("[PF5]");
        return;
    }

    if (Limitation = true) {
        MacroOutput = MacroOutput + "\n" + "Office limitation screen updated";
    } 


    //'doing F4 and using Fun: C again to enable change mode for updating the next entry
    Emulsessiona.autECLPS.SendKeys("[pf4]");
    apiChka();
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[pf4]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
    
    OFFICE_LIMITATION_SCREENadd = true;
    return OFFICE_LIMITATION_SCREENadd;

}



function Limitation_screen_Procesuresadd() {
    Limitation = false;

    LANGUAGE_SCREENadd();
    Contact_Informationadd();
    Electronic_Communicationadd();

    //'If AGE_LIMIT_IND <> "" Then
    if (EXT_HR_IND != "0") {
        Emulsessiona.autECLPS.SendKeys(EXT_HR_IND, 6, 14);
    }

    //'AGE_LIMIT_IND = "21 - 099"
    //'Emulsessiona.autECLPS.SendKeys AGE_LIMIT_IND, 7, 13
    if (AGE_LIMIT_IND != "") {
        var s1 = AGE_LIMIT_IND.split("-")
        Emulsessiona.autECLPS.SendKeys(s1[0], 7, 13);
        Emulsessiona.autECLPS.SendKeys(s1[1], 7, 19);
        apiChka();
    }

    Emulsessiona.autECLPS.SendKeys(Gender_LOB, 7, 33);
    Emulsessiona.autECLPS.SendKeys(MEDICAID, 9, 12);

    if (LOC_MEDICAID.trim() != "") {
        Emulsessiona.autECLPS.SendKeys(LOC_MEDICAID.toUpperCase(), 9, 32);
    }

    // New Changes for Office Hours - Sujit- 13/12/2017
    if (Emulsessiona.autECLPS.gettext(4, 45, 4).trim() != "" && MondayOpen1 != "") {
        Clear_Hours();
    }

    if (MondayOpen1 != "") {

        if (MondayOpen1 != "") {
            Emulsessiona.autECLPS.SendKeys(MondayOpen1, 4, 45);
        }
        if (TuesdayOpen1 != "") {
            Emulsessiona.autECLPS.SendKeys(TuesdayOpen1, 5, 45);
        }
        if (WednesdayOpen1 != "") {
            Emulsessiona.autECLPS.SendKeys(WednesdayOpen1, 6, 45);
        }
        if (ThursdayOpen1 != "") {
            Emulsessiona.autECLPS.SendKeys(ThursdayOpen1, 7, 45);
        }
        if (FridayOpen1 != "") {
            Emulsessiona.autECLPS.SendKeys(FridayOpen1, 8, 45);
        }
        if (SaturdayOpen1 != "") {
            Emulsessiona.autECLPS.SendKeys(SaturdayOpen1, 9, 45);
        }
        if (SundayOpen1 != "") {
            Emulsessiona.autECLPS.SendKeys(SundayOpen1, 10, 45);
        }

        //'Closed1 series
        if (MondayClosed1 != "") {
            Emulsessiona.autECLPS.SendKeys(MondayClosed1, 4, 55);
        }
        if (TuesdayClosed1 != "") {
            Emulsessiona.autECLPS.SendKeys(TuesdayClosed1, 5, 55);
        }
        if (WednesdayClosed1 != "") {
            Emulsessiona.autECLPS.SendKeys(WednesdayClosed1, 6, 55);
        }
        if (ThursdayClosed1 != "") {
            Emulsessiona.autECLPS.SendKeys(ThursdayClosed1, 7, 55);
        }
        if (FridayClosed1 != "") {
            Emulsessiona.autECLPS.SendKeys(FridayClosed1, 8, 55);
        }
        if (SaturdayClosed1 != "") {
            Emulsessiona.autECLPS.SendKeys(SaturdayClosed1, 9, 55);
        }
        if (SundayClosed1 != "") {
            Emulsessiona.autECLPS.SendKeys(SundayClosed1, 10, 55);
        }

        //'Open2 series
        if (MondayOpen2 != "") {
            Emulsessiona.autECLPS.SendKeys(MondayOpen2, 4, 64);
        }
        if (TuesdayOpen2 != "") {
            Emulsessiona.autECLPS.SendKeys(TuesdayOpen2, 5, 64);
        }
        if (WednesdayOpen2 != "") {
            Emulsessiona.autECLPS.SendKeys(WednesdayOpen2, 6, 64);
        }
        if (ThursdayOpen2 != "") {
            Emulsessiona.autECLPS.SendKeys(ThursdayOpen2, 7, 64);
        }
        if (FridayOpen2 != "") {
            Emulsessiona.autECLPS.SendKeys(FridayOpen2, 8, 64);
        }
        if (SaturdayOpen2 != "") {
            Emulsessiona.autECLPS.SendKeys(SaturdayOpen2, 9, 64);
        }
        if (SundayOpen2 != "") {
            Emulsessiona.autECLPS.SendKeys(SundayOpen2, 10, 64);
        }

        //'Closed2 series
        if (MondayClosed2 != "") {
            Emulsessiona.autECLPS.SendKeys(MondayClosed2, 4, 74);
        }
        if (TuesdayClosed2 != "") {
            Emulsessiona.autECLPS.SendKeys(TuesdayClosed2, 5, 74);
        }
        if (WednesdayClosed2 != "") {
            Emulsessiona.autECLPS.SendKeys(WednesdayClosed2, 6, 74);
        }
        if (ThursdayClosed2 != "") {
            Emulsessiona.autECLPS.SendKeys(ThursdayClosed2, 7, 74);
        }
        if (FridayClosed2 != "") {
            Emulsessiona.autECLPS.SendKeys(FridayClosed2, 8, 74);
        }
        if (SaturdayClosed2 != "") {
            Emulsessiona.autECLPS.SendKeys(SaturdayClosed2, 9, 74);
        }
        if (SundayClosed2 != "") {
            Emulsessiona.autECLPS.SendKeys(SundayClosed2, 10, 74);
        }
        Limitation = true;
    }
}

var ILZ_Screen_Changeadd = function () {
    ILZ_Screen_Changeadd = true;

    //'ILZ Screen enablement logic will depend upon few pre-identified Variables which are mandatory
    //'and if Data Exists under any of these variables then ILZ Screen will need to be updated
    if (EXT_HR_IND == "") {
        ILZ_Screen_Change = false;
    } else {
        ILZ_Screen_Change = true;
        return ILZ_Screen_Change;
    }

    if (AGE_LIMIT_IND == "") {
        ILZ_Screen_Change = false;
    }
    else {
        ILZ_Screen_Change = true;
        return ILZ_Screen_Change;
    }

    if (MEDICAID == "") {
        ILZ_Screen_Change = false;
    }
    else {
        ILZ_Screen_Change = true;
        return ILZ_Screen_Change;
    }

    if (LOC_MEDICAID == "") {
        ILZ_Screen_Change = false;
    }
    else {
        ILZ_Screen_Change = true;
        return ILZ_Screen_Change;
    }

    if (LANG_CODE == "") {
        ILZ_Screen_Change = false;
    }
    else {
        ILZ_Screen_Change = true;
        return ILZ_Screen_Change;
    }

    if (COMMUNICATION == "") {
        ILZ_Screen_Change = false;
    } else {
        ILZ_Screen_Change = true;
        return ILZ_Screen_Change;
    }

    if (CNTC_TYPE == "") {
        ILZ_Screen_Change = false;
    }
    else {
        ILZ_Screen_Change = true;
        return ILZ_Screen_Change;
    }
    return ILZ_Screen_Change;

}

var MEDICAID_IAM_Screenadd = function () {
    MEDICAID_IAM_Screenadd = false;
    apiChka();
    apiChka();

    if(addAddress != true) {
        return;
    }
    
    if ((MedicaidInd.trim().toUpperCase() == "NO") || (MEDICAID == "")) {
        MEDICAID_IAM_Screenadd = true;
        return MEDICAID_IAM_Screenadd;
    }
    
    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M", 21, 15);
    Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(AddMA_ID_new, 21, 47);
    apiChka();

    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();
    apiChka();

    if (((MedicaidInd.trim().toUpperCase()) == "NO") || (MEDICAID == "")) {
        MEDICAID_IAM_Screenadd = true;
        return MEDICAID_IAM_Screenadd;
    }
    else {
        if (MedicaidState == "NE") {
            medi2add();

        } else {
            mediadd();
        }

    }
    MEDICAID_IAM_Screenadd = true;
    return MEDICAID_IAM_Screenadd;
}

function medi2add() {

    Emulsessiona.autECLPS.SendKeys(1, 19, 13);
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("A", 21, 8);
    Emulsessiona.autECLPS.SendKeys("A", 21, 15);
    Emulsessiona.autECLPS.SendKeys("M", 21, 23);
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("1", 19, 13);
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();
    EffDate_Medicaid = EffDate_Medicaid.replace(" ", "");
    EffDate_Medicaid = EffDate_Medicaid.replace(" ", "");

    Emulsessiona.autECLPS.SendKeys((EffDate_Medicaid.trim().substring(0, 2)), 8, 10);
    Emulsessiona.autECLPS.SendKeys((EffDate_Medicaid.trim().substring(4, 2)), 8, 13);
    Emulsessiona.autECLPS.SendKeys((EffDate_Medicaid.trim().substring(8, 4)), 8, 16);

    Emulsessiona.autECLPS.SendKeys("IM", 10, 7);
    Emulsessiona.autECLPS.SendKeys(MEDICAID, 10, 30);
    //var ST = Emulsessiona.autECLPS.gettext(7, 42, 2)
    //apiChka();
    Emulsessiona.autECLPS.SendKeys(MedicaidState, 10, 53);
    //'Emulsessiona.autECLPS.SendKeys "[pf6]"
    Emulsessiona.autECLPS.SendKeys("A", 21, 8);

    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();

    if (Emulsessiona.autECLPS.gettext(24, 2, 70).trim().indexOf("PRESS ENTER") >= 0) {

        Emulsessiona.autECLPS.SendKeys("[Enter]");
        apiChka();
    }
    
    Emulsessiona.autECLPS.SendKeys("1", 19, 13);
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();
    EffDate_Medicaid = EffDate_Medicaid.replace(" ", "");
    EffDate_Medicaid = EffDate_Medicaid.replace(" ", "");

    Emulsessiona.autECLPS.SendKeys((EffDate_Medicaid.trim().substring(0, 2)), 8, 10);
    Emulsessiona.autECLPS.SendKeys((EffDate_Medicaid.trim().substring(4, 2)), 8, 13);
    Emulsessiona.autECLPS.SendKeys((EffDate_Medicaid.trim().substring(8, 4)), 8, 16);

    Emulsessiona.autECLPS.SendKeys("GM", 10, 7);
    Emulsessiona.autECLPS.SendKeys(MEDICAID, 10, 30);
    //var ST = Emulsessiona.autECLPS.gettext(7, 42, 2)
    //apiChka();
    Emulsessiona.autECLPS.SendKeys(MedicaidState, 10, 53);
    //'Emulsessiona.autECLPS.SendKeys "[pf6]"
    Emulsessiona.autECLPS.SendKeys("[pf6]");

    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();

    if (Emulsessiona.autECLPS.gettext(24, 2, 1) != " ") {
        if (Emulsessiona.autECLPS.gettext(24, 2, 70).trim().indexOf("PROVIDER") >= 0) {

            var Err = (Emulsessiona.autECLPS.gettext(24, 2, 70)).trim();
            MacroOutput = MacroOutput + "\n" + "MEDICAID IAM SCREEN - " + Err;

            apiChka();
            return;
        }
        else {
            var Err = (Emulsessiona.autECLPS.gettext(24, 2, 70)).trim();
            MacroOutput = MacroOutput + "\n" + "MEDICAID IAM SCREEN - " + Err ;
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            apiChka();
            return;
        }

    }

}

function mediadd() {
    // 'srLink = Trim(Emulsessiona.autECLPS.GetText(cnt, 2, 1))



    Emulsessiona.autECLPS.SendKeys(1, 19, 13);
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("A", 21, 8);
    Emulsessiona.autECLPS.SendKeys("A", 21, 15);
    Emulsessiona.autECLPS.SendKeys("M", 21, 23);
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("1", 19, 13);
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();
    EffDate_Medicaid = EffDate_Medicaid.replace(" ", "");
    EffDate_Medicaid = EffDate_Medicaid.replace(" ", "");

    Emulsessiona.autECLPS.SendKeys((EffDate_Medicaid.trim().substring(0, 2)), 8, 10);
    Emulsessiona.autECLPS.SendKeys((EffDate_Medicaid.trim().substring(4, 2)), 8, 13);
    Emulsessiona.autECLPS.SendKeys((EffDate_Medicaid.trim().substring(8, 4)), 8, 16);

    Emulsessiona.autECLPS.SendKeys("IM", 10, 7);
    Emulsessiona.autECLPS.SendKeys(MEDICAID, 10, 30);
    var ST = Emulsessiona.autECLPS.gettext(7, 42, 2)
    apiChka();
    Emulsessiona.autECLPS.SendKeys(MedicaidState, 10, 53);
    //'Emulsessiona.autECLPS.SendKeys "[pf6]"
    Emulsessiona.autECLPS.SendKeys("[pf6]");

    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();

    if (Emulsessiona.autECLPS.gettext(24, 2, 1) != " ") {
        if (Emulsessiona.autECLPS.gettext(24, 2, 70).trim().indexOf("PROVIDER") >= 0) {

            var Err = (Emulsessiona.autECLPS.gettext(24, 2, 70)).trim();
            MacroOutput = MacroOutput + "\n" + "MEDICAID IAM SCREEN - " + Err;
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            apiChka();
            return;
        }
        else {
            var Err = (Emulsessiona.autECLPS.gettext(24, 2, 70)).trim();
            MacroOutput = MacroOutput + "\n" + "MEDICAID IAM SCREEN - " + Err ;
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            apiChka();
            return;
        }

    }


    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M", 21, 15);
    Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();

}

function Contact_Informationadd() {
    if (ContactData) {
        if (CNTC_TYPE != "") {
            if (CNTC_TYPE.trim().toUpperCase() != "NA") {
                if (CNTC_TYPE.trim().toUpperCase() != "N/A") {

                    PHONE_EXTN = PHONE_EXTN.replace(" ", ""); PHONE_EXTN = PHONE_EXTN.replace(" ", "")

                    Emulsessiona.autECLPS.SendKeys("[PF11]");
                    apiChka();
                    apiChka();

                    //'incase single address and single entry for Elec Comm screen
                    if (CNTC_TYPE.indexOf("|") < 0) {
                        if (Emulsessiona.autECLPS.gettext(10, 4, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys(CNTC_TYPE.trim(), 10, 4);
                            Emulsessiona.autECLPS.SendKeys(NAME.trim(), 10, 9);
                            Emulsessiona.autECLPS.SendKeys(COMM_TYPE.trim(), 10, 51);
                            Emulsessiona.autECLPS.SendKeys(PHONE_EXTN.trim(), 10, 56);
                            if ((ExtnNDBContact.trim()) != "") {
                                Emulsessiona.autECLPS.SendKeys((ExtnNDBContact.trim()), 10, 69);
                            }
                            Emulsessiona.autECLPS.SendKeys("A", 10, 78);
                        }
                        else if (Emulsessiona.autECLPS.gettext(11, 4, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys((CNTC_TYPE.trim()), 11, 4);
                            Emulsessiona.autECLPS.SendKeys((NAME.trim()), 11, 9);
                            Emulsessiona.autECLPS.SendKeys((COMM_TYPE.trim()), 11, 51);
                            Emulsessiona.autECLPS.SendKeys((PHONE_EXTN.trim()), 11, 56);
                            if (ExtnNDBContact.trim() != "") {
                                Emulsessiona.autECLPS.SendKeys((ExtnNDBContact.trim()), 11, 69);
                            }
                            Emulsessiona.autECLPS.SendKeys("A", 11, 78);
                        }
                        else if (Emulsessiona.autECLPS.gettext(12, 4, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys((CNTC_TYPE.trim()), 12, 4);
                            Emulsessiona.autECLPS.SendKeys((NAME.trim()), 12, 9);
                            Emulsessiona.autECLPS.SendKeys((COMM_TYPE.trim()), 12, 51);
                            Emulsessiona.autECLPS.SendKeys((PHONE_EXTN.trim()), 12, 56);
                            if ((ExtnNDBContact.trim()) != "") {
                                Emulsessiona.autECLPS.SendKeys((ExtnNDBContact.trim()), 12, 69);
                            }
                            Emulsessiona.autECLPS.SendKeys("A", 12, 78);
                        }
                        else if (Emulsessiona.autECLPS.gettext(13, 4, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys((CNTC_TYPE.trim()), 13, 4);
                            Emulsessiona.autECLPS.SendKeys((NAME.trim()), 13, 9);
                            Emulsessiona.autECLPS.SendKeys((COMM_TYPE.trim()), 13, 51);
                            Emulsessiona.autECLPS.SendKeys((PHONE_EXTN.trim()), 13, 56);
                            if ((ExtnNDBContact.trim()) != "") {
                                Emulsessiona.autECLPS.SendKeys((ExtnNDBContact.trim()), 13, 69);
                            }
                            Emulsessiona.autECLPS.SendKeys("A", 13, 78);
                        }
                        else if (Emulsessiona.autECLPS.gettext(14, 4, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys((CNTC_TYPE.trim()), 14, 4);
                            Emulsessiona.autECLPS.SendKeys((NAME.trim()), 14, 9);
                            Emulsessiona.autECLPS.SendKeys((COMM_TYPE.trim()), 14, 51);
                            Emulsessiona.autECLPS.SendKeys((PHONE_EXTN.trim()), 14, 56);
                            if ((ExtnNDBContact.trim()) != "") {
                                Emulsessiona.autECLPS.SendKeys((ExtnNDBContact.trim()), 14, 69);
                            }
                            Emulsessiona.autECLPS.SendKeys("A", 14, 78);
                        }
                        else if (Emulsessiona.autECLPS.gettext(15, 4, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys((CNTC_TYPE.trim()), 15, 4);
                            Emulsessiona.autECLPS.SendKeys((NAME.trim()), 15, 9);
                            Emulsessiona.autECLPS.SendKeys((COMM_TYPE.trim()), 15, 51);
                            Emulsessiona.autECLPS.SendKeys((PHONE_EXTN.trim()), 15, 56);
                            if ((ExtnNDBContact.trim()) != "") {
                                Emulsessiona.autECLPS.SendKeys((ExtnNDBContact.trim()), 15, 69);
                            }
                            Emulsessiona.autECLPS.SendKeys("A", 15, 78);
                        }
                        else if (Emulsessiona.autECLPS.gettext(16, 4, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys((CNTC_TYPE.trim()), 16, 4);
                            Emulsessiona.autECLPS.SendKeys((NAME.trim()), 16, 9);
                            Emulsessiona.autECLPS.SendKeys((COMM_TYPE.trim()), 16, 51);
                            Emulsessiona.autECLPS.SendKeys((PHONE_EXTN.trim()), 16, 56);
                            if ((ExtnNDBContact.trim()) != "") {
                                Emulsessiona.autECLPS.SendKeys((ExtnNDBContact.trim()), 16, 69);
                            }
                            Emulsessiona.autECLPS.SendKeys("A", 16, 78);
                        }
                        else if (Emulsessiona.autECLPS.gettext(17, 4, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys((CNTC_TYPE.trim()), 17, 4);
                            Emulsessiona.autECLPS.SendKeys((NAME.trim()), 17, 9);
                            Emulsessiona.autECLPS.SendKeys((COMM_TYPE.trim()), 17, 51);
                            Emulsessiona.autECLPS.SendKeys((PHONE_EXTN.trim()), 17, 56);
                            if ((ExtnNDBContact.trim()) != "") {
                                Emulsessiona.autECLPS.SendKeys((ExtnNDBContact.trim()), 17, 69);
                            }
                            Emulsessiona.autECLPS.SendKeys("A", 17, 78);

                        }

                    }
                    var SameValueCNTC_TYPE = {};
                    var SameValueNAME = {};
                    var SameValueCOMM_TYPE = {};
                    var SameValuePHONE_EXTN = {};
                    var SameValueExtnNDBContact = {};
                    //'incase single address but multiple entries for Elec Comm Screen
                    if (CNTC_TYPE.indexOf(",") > 0) {
                        SameValueCNTC_TYPE = CNTC_TYPE.split(",");
                        SameValueNAME = NAME.split(",");
                        SameValueCOMM_TYPE = COMM_TYPE.split(",");
                        SameValuePHONE_EXTN = PHONE_EXTN.split(",");
                        SameValueExtnNDBContact = ExtnNDBContact.split(",");

                        if (PHONE_EXTN.indexOf(",") == 0) {
                            if (MacroOutput = "") {
                                MacroOutput = "Contact information not completely available. Macro skipped this piece and moved to other section. ";
                                Emulsessiona.autECLPS.SendKeys([pf5]);
                                apiChka();
                                return;
                            }
                            else {
                                MacroOutput = MacroOutput + "Contact information not completely available. Macro skipped this piece and moved to other section. ";
                                Emulsessiona.autECLPS.SendKeys([pf5]);
                                apiChka();
                                return;
                            }
                        }

                        for (var x in SameValueCNTC_TYPE) {
                            if (Emulsessiona.autECLPS.gettext(10, 4, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValueCNTC_TYPE[x].trim()), 10, 4);
                                Emulsessiona.autECLPS.SendKeys((SameValueNAME[x].trim()), 10, 9);
                                Emulsessiona.autECLPS.SendKeys((SameValueCOMM_TYPE[x].trim()), 10, 51);
                                Emulsessiona.autECLPS.SendKeys((SameValuePHONE_EXTN[x].trim()), 10, 56);
                                if (ExtnNDBContact != "") {
                                    if ((SameValueExtnNDBContact[x].trim()) != "") {
                                        Emulsessiona.autECLPS.SendKeys((SameValueExtnNDBContact[x].trim()), 10, 69);
                                    }
                                }
                                Emulsessiona.autECLPS.SendKeys("A", 10, 78);
                            }
                            else if (Emulsessiona.autECLPS.gettext(11, 4, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValueCNTC_TYPE[x].trim()), 11, 4);
                                Emulsessiona.autECLPS.SendKeys((SameValueNAME[x].trim()), 11, 9);
                                Emulsessiona.autECLPS.SendKeys((SameValueCOMM_TYPE[x].trim()), 11, 51);
                                Emulsessiona.autECLPS.SendKeys((SameValuePHONE_EXTN[x].trim()), 11, 56);
                                if (ExtnNDBContact != "") {
                                    if ((SameValueExtnNDBContact[x]).trim() != "") {
                                        Emulsessiona.autECLPS.SendKeys((SameValueExtnNDBContact[x].trim()), 11, 69);
                                    }
                                }
                                Emulsessiona.autECLPS.SendKeys("A", 11, 78);
                            }
                            else if (Emulsessiona.autECLPS.gettext(12, 4, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValueCNTC_TYPE[x].trim()), 12, 4);
                                Emulsessiona.autECLPS.SendKeys((SameValueNAME[x].trim()), 12, 9);
                                Emulsessiona.autECLPS.SendKeys((SameValueCOMM_TYPE[x].trim()), 12, 51);
                                Emulsessiona.autECLPS.SendKeys((SameValuePHONE_EXTN[x].trim()), 12, 56);
                                if (ExtnNDBContact != "") {
                                    if ((SameValueExtnNDBContact[x].trim()) != "") {
                                        Emulsessiona.autECLPS.SendKeys((SameValueExtnNDBContact[x].trim()), 12, 69);
                                    }
                                }
                                Emulsessiona.autECLPS.SendKeys("A", 12, 78);
                            }
                            else if (Emulsessiona.autECLPS.gettext(13, 4, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValueCNTC_TYPE[x].trim()), 13, 4);
                                Emulsessiona.autECLPS.SendKeys((SameValueNAME[x].trim()), 13, 9);
                                Emulsessiona.autECLPS.SendKeys((SameValueCOMM_TYPE[x].trim()), 13, 51);
                                Emulsessiona.autECLPS.SendKeys((SameValuePHONE_EXTN[x].trim()), 13, 56);
                                if (ExtnNDBContact != "") {
                                    if ((SameValueExtnNDBContact[x].trim()) != "") {
                                        Emulsessiona.autECLPS.SendKeys((SameValueExtnNDBContact[x].trim()), 13, 69);
                                    }
                                }
                                Emulsessiona.autECLPS.SendKeys("A", 13, 78);
                            }
                            else if (Emulsessiona.autECLPS.gettext(14, 4, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValueCNTC_TYPE[x].trim()), 14, 4);
                                Emulsessiona.autECLPS.SendKeys((SameValueNAME[x].trim()), 14, 9);
                                Emulsessiona.autECLPS.SendKeys((SameValueCOMM_TYPE[x].trim()), 14, 51);
                                Emulsessiona.autECLPS.SendKeys((SameValuePHONE_EXTN[x].trim()), 14, 56);
                                if (ExtnNDBContact != "") {
                                    if ((SameValueExtnNDBContact[x].trim()) != "") {
                                        Emulsessiona.autECLPS.SendKeys((SameValueExtnNDBContact[x].trim()), 14, 69);
                                    }
                                }
                                Emulsessiona.autECLPS.SendKeys("A", 14, 78);
                            }
                            else if (Emulsessiona.autECLPS.gettext(15, 4, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValueCNTC_TYPE[x].trim()), 15, 4);
                                Emulsessiona.autECLPS.SendKeys((SameValueNAME[x].trim()), 15, 9);
                                Emulsessiona.autECLPS.SendKeys((SameValueCOMM_TYPE[x].trim()), 15, 51);
                                Emulsessiona.autECLPS.SendKeys((SameValuePHONE_EXTN[x].trim()), 15, 56);
                                if (ExtnNDBContact != "") {
                                    if ((SameValueExtnNDBContact[x].trim()) != "") {
                                        Emulsessiona.autECLPS.SendKeys((SameValueExtnNDBContact[x].trim()), 15, 69);
                                    }
                                }
                                Emulsessiona.autECLPS.SendKeys("A", 15, 78);
                            }
                            else if (Emulsessiona.autECLPS.gettext(16, 4, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValueCNTC_TYPE[x].trim()), 16, 4);
                                Emulsessiona.autECLPS.SendKeys((SameValueNAME[x].trim()), 16, 9);
                                Emulsessiona.autECLPS.SendKeys((SameValueCOMM_TYPE[x].trim()), 16, 51);
                                Emulsessiona.autECLPS.SendKeys((SameValuePHONE_EXTN[x].trim()), 16, 56);
                                if (ExtnNDBContact != "") {
                                    if ((SameValueExtnNDBContact[x].trim()) != "") {
                                        Emulsessiona.autECLPS.SendKeys((SameValueExtnNDBContact[x].trim()), 16, 69);
                                    }
                                }
                                Emulsessiona.autECLPS.SendKeys("A", 16, 78);
                            }
                            else if (Emulsessiona.autECLPS.gettext(17, 4, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValueCNTC_TYPE[x].trim()), 17, 4);
                                Emulsessiona.autECLPS.SendKeys((SameValueNAME[x].trim()), 17, 9);
                                Emulsessiona.autECLPS.SendKeys((SameValueCOMM_TYPE[x].trim()), 17, 51);
                                Emulsessiona.autECLPS.SendKeys((SameValuePHONE_EXTN[x].trim()), 17, 56);
                                if (ExtnNDBContact != "") {
                                    if ((SameValueExtnNDBContact[x].trim()) != "") {
                                        Emulsessiona.autECLPS.SendKeys((SameValueExtnNDBContact[x].trim()), 17, 69);
                                    }
                                }
                                Emulsessiona.autECLPS.SendKeys("A", 17, 78);
                            }
                        }

                        //'}
                    }

                    Emulsessiona.autECLPS.SendKeys("[PF6]");
                    apiChka();
                    apiChka();
                    if (Emulsessiona.autECLPS.gettext(24, 2, 1) != " ") {
                        Err = Emulsessiona.autECLPS.gettext(24, 2, 70).trim();
                        MacroOutput = MacroOutput + "\n" + Err;
                        Emulsessiona.autECLPS.SendKeys("[PF5]");
                        return;
                    }
                    else {
                        MacroOutput = MacroOutput + "\n" + "Contact information screen updated";
                    }

                }
            }
        }
        else
            if ((CNTC_TYPE != "") && (NAME != "") && (COMM_TYPE != "") && (PHONE_EXTN != "")) {
                if (MacroOutput == "") {
                    MacroOutput = "Contact Information not completely available. Macro skipped this piece and moved to other section. ";
                }
                else {
                    MacroOutput = MacroOutput + "Contact Information not completely available. Macro skipped this piece and moved to other section. ";
                    return;
                }
            }
    }
    //'MacroOutput = ""
}

function Electronic_Communicationadd() {

    if (CommData == true) {
        if (COMMUNICATION != "") {
            if ((COMMUNICATION.trim().toUpperCase()) != "NA") {
                if ((COMMUNICATION.trim().toUpperCase()) != "N/A") {
                    //'uncomment below 6 lines
                    Emulsessiona.autECLPS.SendKeys("[PF6]");

                    apiChka();
                    Emulsessiona.autECLPS.SendKeys("[enter]");
                    apiChka();
                    //Emulsessiona.autECLPS.SendKeys("[PF6]");
                    //apiChka();
                    //apiChka();

                    //'incase the 2nd F6 command takes the automation to previous screen - ){ macro needs to do F6 again
                    //if (((Emulsessiona.autECLPS.gettext(1, 3, 10)).trim().indexOf("MPIN:", 1)) >= 0) {
                    //    Emulsessiona.autECLPS.SendKeys("[PF6]");
                    //    apiChka();
                    //    apiChka();
                    //}

                    //'checking whether anything exists on Electronic Communication screen or not
                    if (Emulsessiona.autECLPS.gettext(9, 2, 1).trim() == "_") {
                        p = 2;
                    }
                    if (Emulsessiona.autECLPS.gettext(9, 2, 1).trim() != "_") {
                        if (Emulsessiona.autECLPS.gettext(11, 2, 1).trim() != "_") {
                            p = 6;
                        }
                        else {
                            p = 4;
                        }
                    }
                }

                //'incase single address and single entry for Elec Comm screen
                if (TYPE_Comm.indexOf("|") < 0) {
                    if (TYPE_Comm.indexOf(",") < 0) {
                        if (Emulsessiona.autECLPS.gettext(p + 7, 2, 1).trim() == "_") {
                            Emulsessiona.autECLPS.SendKeys((COMMUNICATION.trim()), p + 7, 2);
                            Emulsessiona.autECLPS.SendKeys((TYPE_Comm.trim()), p + 6, 33);
                            Emulsessiona.autECLPS.SendKeys((PROV_ADDR.trim()), p + 6, 54);
                            Emulsessiona.autECLPS.SendKeys("A", p + 6, 76);
                        }
                        else if (Emulsessiona.autECLPS.gettext(p + 8, 2, 1).trim() == "_") {
                            Emulsessiona.autECLPS.SendKeys((COMMUNICATION.trim()), p + 8, 2);
                            Emulsessiona.autECLPS.SendKeys((TYPE_Comm.trim()), p + 7, 33);
                            Emulsessiona.autECLPS.SendKeys((PROV_ADDR.trim()), p + 7, 54);
                            Emulsessiona.autECLPS.SendKeys("A", p + 7, 76);
                        }
                        else if (Emulsessiona.autECLPS.gettext(p + 9, 2, 1).trim() == "_") {
                            Emulsessiona.autECLPS.SendKeys((COMMUNICATION.trim()), p + 9, 2);
                            Emulsessiona.autECLPS.SendKeys((TYPE_Comm.trim()), p + 8, 33);
                            Emulsessiona.autECLPS.SendKeys((PROV_ADDR.trim()), p + 8, 54);
                            Emulsessiona.autECLPS.SendKeys("A", p + 8, 76);
                        }
                        else if (Emulsessiona.autECLPS.gettext(p + 10, 2, 1).trim() == "_") {
                            Emulsessiona.autECLPS.SendKeys((COMMUNICATION.trim()), p + 10, 2);
                            Emulsessiona.autECLPS.SendKeys((TYPE_Comm.trim()), p + 9, 33);
                            Emulsessiona.autECLPS.SendKeys((PROV_ADDR.trim()), p + 9, 54);
                            Emulsessiona.autECLPS.SendKeys("A", p + 9, 76);
                        }
                        else if (Emulsessiona.autECLPS.gettext(p + 11, 2, 1).trim() == "_") {
                            Emulsessiona.autECLPS.SendKeys((COMMUNICATION.trim()), p + 11, 2);
                            Emulsessiona.autECLPS.SendKeys((TYPE_Comm.trim()), p + 10, 33);
                            Emulsessiona.autECLPS.SendKeys((PROV_ADDR.trim()), p + 10, 54);
                            Emulsessiona.autECLPS.SendKeys("A", p + 10, 76);
                        }
                        else if (Emulsessiona.autECLPS.gettext(p + 12, 2, 1).trim() == "_") {
                            Emulsessiona.autECLPS.SendKeys((COMMUNICATION.trim()), p + 12, 2);
                            Emulsessiona.autECLPS.SendKeys((TYPE_Comm.trim()), p + 12, 33);
                            Emulsessiona.autECLPS.SendKeys((PROV_ADDR.trim()), p + 12, 54);
                            Emulsessiona.autECLPS.SendKeys("A", p + 12, 76);
                        }

                    }

                }

                //'incase single address but multiple entries for Elec Comm Screen
                var SameValCOMM = {};
                var SameValTYPE_Comm = {};
                var SameValPROV_ADDR = {};
                if (TYPE_Comm.indexOf(",") >= 0) {
                    if (TYPE_Comm.indexOf(",") >= 0) {
                        SameValCOMM = COMMUNICATION.split(",");
                        SameValTYPE_Comm = TYPE_Comm.split(",");
                        SameValPROV_ADDR = PROV_ADDR.split(",");
                        //'SameValACTCODEComm = split(ACT_CODE_Comm, "|")
                        //'p = 2
                        for (var commL in SameValTYPE_Comm) {
                            if (Emulsessiona.autECLPS.gettext(p + 7, 2, 1).trim() == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValCOMM(commL).trim()), p + 7, 2);
                                Emulsessiona.autECLPS.SendKeys((SameValTYPE_Comm(commL).trim()), p + 6, 33);
                                Emulsessiona.autECLPS.SendKeys((SameValPROV_ADDR(commL).trim()), p + 6, 54);
                                Emulsessiona.autECLPS.SendKeys("A", p + 6, 76);

                            }
                            p = p + 2;
                        }
                    }
                }
                var ValCOMM = {};
                var ValTYPE_Comm = {};
                var ValPROV_ADDR = {};
                //'incase multiple address entry and single/multiple entry for language
                if (TYPE_Comm.indexOf(",") >= 0) {
                    ValCOMM = COMMUNICATION.split(",");
                    ValTYPE_Comm = TYPE_Comm.split(",");
                    ValPROV_ADDR = PROV_ADDR.split(",");
                    //'ValACTCODEComm = split(ACT_CODE_Comm, "|")
                    if (ValCOMM(cnt2) != "NA") {
                        //'p = 2

                        if (ValTYPE_Comm(cnt2).indexOf(",") >= 0) {
                            SameValCOMM = ValCOMM(cnt2).split(",");
                            SameValTYPE_Comm = ValTYPE_Comm(cnt2).split(",");
                            if (ValPROV_ADDR(cnt2).indexOf(",") >= 0) {
                                SameValPROV_ADDR = ValPROV_ADDR(cnt2).split(",");
                            }
                            else {
                                SameValPROV_ADDR = ValPROV_ADDR(cnt2);
                            }
                        }
                        for (var commL in SameValCOMM) {
                            if (Emulsessiona.autECLPS.gettext(p + 7, 2, 1).trim() == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValCOMM(commL).trim()), p + 7, 2);
                                Emulsessiona.autECLPS.SendKeys((SameValTYPE_Comm(commL).trim()), p + 6, 33);
                                Emulsessiona.autECLPS.SendKeys((SameValPROV_ADDR(commL).trim()), p + 6, 54);
                                Emulsessiona.autECLPS.SendKeys("A", p + 6, 76);
                            }

                            p = p + 2;
                        }
                    }
                    else if (Emulsessiona.autECLPS.gettext(p + 7, 2, 1).trim() == "_") {

                        Emulsessiona.autECLPS.SendKeys((ValCOMM(cnt2).trim()), p + 7, 2);
                        Emulsessiona.autECLPS.SendKeys((ValTYPE_Comm(cnt2).trim()), p + 6, 33);
                        Emulsessiona.autECLPS.SendKeys((ValPROV_ADDR(cnt2).trim()), p + 6, 54);
                        Emulsessiona.autECLPS.SendKeys("A", p + 6, 76);
                        p = p + 2;
                    }
                }
            }

            Emulsessiona.autECLPS.SendKeys("[PF6]");
            apiChka();
            apiChka();

            //'Error handling for Duplicate Data exists in Electronic Communication Screen
            if (Emulsessiona.autECLPS.gettext(24, 2, 60).trim().indexOf("DUPLICATE COMM") >= 0) {
                if (MacroOutput == "") {
                    MacroOutput = Emulsessiona.autECLPS.gettext(24, 2, 60).trim();
                }
                else {
                    MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.gettext(24, 2, 60).trim();
                }
                Emulsessiona.autECLPS.SendKeys("[PF5]");
                apiChka();
                apiChka();
            }
        }
    }

    else {
        if ((COMMUNICATION != "") && (TYPE_Comm != "") && (PROV_ADDR != "") && (ACT_CODE_Comm != "")) {
            if (MacroOutput == "") {
                MacroOutput = "Electronic Communication Data not completely available. Macro skipped this piece and moved to other section. ";
            }
            else {
                MacroOutput = MacroOutput + "\n" + "Electronic Communication Data not completely available. Macro skipped this piece and moved to other section. ";
            }
            return;
        }
    }
}

function LANGUAGE_SCREENadd() {

    if (LangData == true) {
        if (LANG_CODE != "") {
            if (LANG_CODE != "NA") {
                if (LANG_CODE != "N/A") {
                    Emulsessiona.autECLPS.SendKeys("[PF5]");
                    apiChka();
                    apiChka();

                    //'incase single address and single entry for language screen
                    if (LANG_CODE.indexOf("|") <= 0) {
                        //if (LANG_CODE.indexOf(",") <= 0) {
                        if (Emulsessiona.autECLPS.gettext(9, 11, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys(LANG_CODE.trim(), 9, 11);
                            Emulsessiona.autECLPS.SendKeys(SPOKEN_BY.trim(), 9, 46);                            
                            Emulsessiona.autECLPS.SendKeys(WrittenBy.trim(), 9, 59);
                            //'Emulsessiona.autECLPS.SendKeys ACT_CD_Lang, 9, 75
                            Emulsessiona.autECLPS.SendKeys("A", 9, 75);
                        } else if (Emulsessiona.autECLPS.gettext(10, 11, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys(LANG_CODE.trim(), 10, 11);
                            Emulsessiona.autECLPS.SendKeys(SPOKEN_BY.trim(), 10, 46);
                            Emulsessiona.autECLPS.SendKeys(WrittenBy.trim(), 10, 59);
                            //'Emulsessiona.autECLPS.SendKeys ACT_CD_Lang, 10, 75
                            Emulsessiona.autECLPS.SendKeys("A", 10, 75);
                        } else if (Emulsessiona.autECLPS.gettext(11, 11, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys(LANG_CODE.trim(), 11, 11);
                            Emulsessiona.autECLPS.SendKeys(SPOKEN_BY.trim(), 11, 46);
                            Emulsessiona.autECLPS.SendKeys(WrittenBy.trim(), 11, 59);
                            //'Emulsessiona.autECLPS.SendKeys ACT_CD_Lang, 11, 75
                            Emulsessiona.autECLPS.SendKeys("A", 11, 75);
                        } else if (Emulsessiona.autECLPS.gettext(12, 11, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys(LANG_CODE.trim(), 12, 11);
                            Emulsessiona.autECLPS.SendKeys(SPOKEN_BY.trim(), 12, 46);
                            Emulsessiona.autECLPS.SendKeys(WrittenBy.trim(), 12, 59);
                            //'Emulsessiona.autECLPS.SendKeys ACT_CD_Lang, 12, 75
                            Emulsessiona.autECLPS.SendKeys("A", 12, 75);
                        } else if (Emulsessiona.autECLPS.gettext(13, 11, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys(LANG_CODE.trim(), 13, 11);
                            Emulsessiona.autECLPS.SendKeys(SPOKEN_BY.trim(), 13, 46);
                            Emulsessiona.autECLPS.SendKeys(WrittenBy.trim(), 13, 59);
                            //'Emulsessiona.autECLPS.SendKeys ACT_CD_Lang, 13, 75
                            Emulsessiona.autECLPS.SendKeys("A", 13, 75);
                        } else if (Emulsessiona.autECLPS.gettext(14, 11, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys(LANG_CODE.trim(), 14, 11);
                            Emulsessiona.autECLPS.SendKeys(SPOKEN_BY.trim(), 14, 46);
                            Emulsessiona.autECLPS.SendKeys(WrittenBy.trim(), 14, 59);
                            //'Emulsessiona.autECLPS.SendKeys ACT_CD_Lang, 13, 75
                            Emulsessiona.autECLPS.SendKeys("A", 14, 75);
                        } else if (Emulsessiona.autECLPS.gettext(15, 11, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys(LANG_CODE.trim(), 15, 11);
                            Emulsessiona.autECLPS.SendKeys(SPOKEN_BY.trim(), 15, 46);
                            Emulsessiona.autECLPS.SendKeys(WrittenBy.trim(), 15, 59);
                            //'Emulsessiona.autECLPS.SendKeys ACT_CD_Lang, 13, 75
                            Emulsessiona.autECLPS.SendKeys("A", 15, 75);
                        } else if (Emulsessiona.autECLPS.gettext(16, 11, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys(LANG_CODE.trim(), 16, 11);
                            Emulsessiona.autECLPS.SendKeys(SPOKEN_BY.trim(), 16, 46);
                            Emulsessiona.autECLPS.SendKeys(WrittenBy.trim(), 16, 59);
                            //'Emulsessiona.autECLPS.SendKeys ACT_CD_Lang, 13, 75
                            Emulsessiona.autECLPS.SendKeys("A", 16, 75);
                        } else if (Emulsessiona.autECLPS.gettext(17, 11, 1) == "_") {
                            Emulsessiona.autECLPS.SendKeys(LANG_CODE.trim(), 17, 11);
                            Emulsessiona.autECLPS.SendKeys(SPOKEN_BY.trim(), 17, 46);
                            Emulsessiona.autECLPS.SendKeys(WrittenBy.trim(), 17, 59);
                            //'Emulsessiona.autECLPS.SendKeys ACT_CD_Lang, 13, 75
                            Emulsessiona.autECLPS.SendKeys("A", 17, 75);
                        }



                        //}
                    }
                    var SameValuesLANG_CODE = {};
                    var SameValuesSPOKEN_BY = {};
                    //'incase single address but multiple entries for language screen
                    if (LANG_CODE.indexOf(",") >= 0) {
                        // 'if (InStr(LANG_CODE, ",") > 0 ) {
                        SameValuesLANG_CODE = LANG_CODE.split(",");
                        SameValuesSPOKEN_BY = SPOKEN_BY.split(",");
                        SameValuesWrittenBy = WrittenBy.split(",");
                        for (var x in SameValuesLANG_CODE) {
                            if (Emulsessiona.autECLPS.gettext(9, 11, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValuesLANG_CODE[x].trim()), 9, 11);
                                Emulsessiona.autECLPS.SendKeys((SameValuesSPOKEN_BY[x].trim()), 9, 46);
                                Emulsessiona.autECLPS.SendKeys((SameValuesWrittenBy[x].trim()), 9, 59);
                                Emulsessiona.autECLPS.SendKeys("A", 9, 75);
                            } else if (Emulsessiona.autECLPS.gettext(10, 11, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValuesLANG_CODE[x].trim()), 10, 11);
                                Emulsessiona.autECLPS.SendKeys((SameValuesSPOKEN_BY[x].trim()), 10, 46);
                                Emulsessiona.autECLPS.SendKeys((SameValuesWrittenBy[x].trim()), 10, 59);
                                Emulsessiona.autECLPS.SendKeys("A", 10, 75);
                            } else if (Emulsessiona.autECLPS.gettext(11, 11, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValuesLANG_CODE[x].trim()), 11, 11);
                                Emulsessiona.autECLPS.SendKeys((SameValuesSPOKEN_BY[x].trim()), 11, 46);
                                Emulsessiona.autECLPS.SendKeys((SameValuesWrittenBy[x].trim()), 11, 59);
                                Emulsessiona.autECLPS.SendKeys("A", 11, 75);
                            } else if (Emulsessiona.autECLPS.gettext(12, 11, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValuesLANG_CODE[x].trim()), 12, 11);
                                Emulsessiona.autECLPS.SendKeys((SameValuesSPOKEN_BY[x].trim()), 12, 46);
                                Emulsessiona.autECLPS.SendKeys((SameValuesWrittenBy[x].trim()), 12, 59);
                                Emulsessiona.autECLPS.SendKeys("A", 12, 75);
                            } else if (Emulsessiona.autECLPS.gettext(13, 11, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValuesLANG_CODE[x].trim()), 13, 11);
                                Emulsessiona.autECLPS.SendKeys((SameValuesSPOKEN_BY[x].trim()), 13, 46);
                                Emulsessiona.autECLPS.SendKeys((SameValuesWrittenBy[x].trim()), 13, 59);
                                Emulsessiona.autECLPS.SendKeys("A", 13, 75);
                            } else if (Emulsessiona.autECLPS.gettext(14, 11, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValuesLANG_CODE[x].trim()), 14, 11);
                                Emulsessiona.autECLPS.SendKeys((SameValuesSPOKEN_BY[x].trim()), 14, 46);
                                Emulsessiona.autECLPS.SendKeys((SameValuesWrittenBy[x].trim()), 14, 59);
                                Emulsessiona.autECLPS.SendKeys("A", 14, 75);
                            } else if (Emulsessiona.autECLPS.gettext(15, 11, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValuesLANG_CODE[x].trim()), 15, 11);
                                Emulsessiona.autECLPS.SendKeys((SameValuesSPOKEN_BY[x].trim()), 15, 46);
                                Emulsessiona.autECLPS.SendKeys((SameValuesWrittenBy[x].trim()), 15, 59);
                                Emulsessiona.autECLPS.SendKeys("A", 15, 75);
                            } else if (Emulsessiona.autECLPS.gettext(16, 11, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValuesLANG_CODE[x].trim()), 16, 11);
                                Emulsessiona.autECLPS.SendKeys((SameValuesSPOKEN_BY[x].trim()), 16, 46);
                                Emulsessiona.autECLPS.SendKeys((SameValuesWrittenBy[x].trim()), 16, 59);
                                Emulsessiona.autECLPS.SendKeys("A", 16, 75);
                            } else if (Emulsessiona.autECLPS.gettext(17, 11, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValuesLANG_CODE[x].trim()), 17, 11);
                                Emulsessiona.autECLPS.SendKeys((SameValuesSPOKEN_BY[x].trim()), 17, 46);
                                Emulsessiona.autECLPS.SendKeys((SameValuesWrittenBy[x].trim()), 17, 59);
                                Emulsessiona.autECLPS.SendKeys("A", 16, 75);
                            } else if (Emulsessiona.autECLPS.gettext(18, 11, 1) == "_") {
                                Emulsessiona.autECLPS.SendKeys((SameValuesLANG_CODE[x].trim()), 18, 11);
                                Emulsessiona.autECLPS.SendKeys((SameValuesSPOKEN_BY[x].trim()), 18, 46);
                                Emulsessiona.autECLPS.SendKeys((SameValuesWrittenBy[x].trim()), 18, 59);
                                Emulsessiona.autECLPS.SendKeys("A", 18, 75);
                            }

                        }
                        //'}
                    }
                    Emulsessiona.autECLPS.SendKeys("[PF6]");
                    apiChka();
                    apiChka();
                    if (Emulsessiona.autECLPS.gettext(24, 2, 1) != " ") {
                        Err = Emulsessiona.autECLPS.gettext(24, 2, 70).trim();
                        MacroOutput = MacroOutput + "\n" + Err;
                        Emulsessiona.autECLPS.SendKeys("[PF5]");
                        return;
                    }
                    else {
                        MacroOutput = MacroOutput + "\n" + "Language screen updated";
                    }

                }
            }
        }
        else
            if ((LANG_CODE != "") && (SPOKEN_BY != "") && (ACT_CD_Lang != "")) {
                if (MacroOutput == "") {
                    MacroOutput = "Language Data not completely available. Macro skipped this piece and moved to other section. ";
                }
                else {
                    MacroOutput = MacroOutput + "\n" + "Language Data not completely available. Macro skipped this piece and moved to other section. "
                }
                return;
            }
    }

}


function IDC_CREDENTIAL_CATEGORY(){

    IDC_CREDENTIAL_CATEGORY = false;
    if (addAddress != true) {
        return;
    }



   
    if(CURRENT_CREDENTIAL_TYPE != "" ){
        if(CURRENT_CREDENTIAL_TYPE != "N/A" ){
            if(CURRENT_CREDENTIAL_TYPE != "NA" ){

                Emulsessiona.autECLPS.SendKeys("[pf3]");
                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("D", 21, 15);
                Emulsessiona.autECLPS.SendKeys("C", 21, 23);
                Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
                apiChka();
                Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
           
                //'by default selection 1
                Emulsessiona.autECLPS.SendKeys("1", 19, 13);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
           
                //'checking whether any existing information exist in AREA: CREDENTIALS-CATEGORY:DELEGATED ENTITIES NAME (T) Screen or not
                //'below if(is for when there is no existing information
                if(Emulsessiona.autECLPS.GetText(12, 5, 10).trim() == "" ){
            
                    Emulsessiona.autECLPS.SendKeys("a", 21, 8);
                    Emulsessiona.autECLPS.SendKeys("[enter]");
                    apiChka();
                    apiChka();

                    if (CURRENT_CYCLE_DATE != "") {
                        CURRENT_CYCLE_DATE = CURRENT_CYCLE_DATE.split(" ");
                        Emulsessiona.autECLPS.SendKeys(CURRENT_CYCLE_DATE[0], 8, 27);
                        Emulsessiona.autECLPS.SendKeys(CURRENT_CYCLE_DATE[1], 8, 30);
                        Emulsessiona.autECLPS.SendKeys(CURRENT_CYCLE_DATE[2], 8, 33);
                        apiChka();

                    }
                    
                    Emulsessiona.autECLPS.SendKeys(CURRENT_CREDENTIAL_TYPE, 9, 27);
                
                    Emulsessiona.autECLPS.SendKeys("i", 21, 8);
                
                    Emulsessiona.autECLPS.SendKeys("[enter]");
                    apiChka();
                
                    //'additional Enter if(below Error message is prompted
                    if(Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("COMPLETE THE DELEGATED ENTITIES") >= 0 ){
                        Emulsessiona.autECLPS.SendKeys("[enter]");
                        apiChka();
                        apiChka();
                    }
                
                
                    IDC_CREDENTIAL_CATEGORY = true;
                
                }
            
                //'checking whether any existing information exist in AREA: CREDENTIALS-CATEGORY:DELEGATED ENTITIES NAME (T) Screen or not
                //'below if(will be used when there exists any information on this screen
                if(Emulsessiona.autECLPS.GetText(9, 26, 10).trim() != "" ){
                    if(Emulsessiona.autECLPS.GetText(9, 26, 10).trim().indexOf("DEL") >= 0 ){
                        MacroOutput = MacroOutput + "\n" + "IDC credential screen has been updated";
                    }
                }
            }
        }
    }
    
}

function ITC_CREDENTIAL_CATEGORY() {

    ITC_CREDENTIAL_CATEGORY = false;

    if (addAddress != true) {
        return;
    }


    if (CURRENT_DEL_DT != "") {
        if (CURRENT_DEL_DT.trim().toUpperCase() != "N/A") {
            if (CURRENT_DEL_DT.toUpperCase() != "NA") {
                Emulsessiona.autECLPS.SendKeys("[PF3]");

                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("T", 21, 15);
                Emulsessiona.autECLPS.SendKeys("C", 21, 23);
                Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
                apiChka();
                Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();

                //'by default selection 1
                Emulsessiona.autECLPS.SendKeys("1", 19, 13);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();

                //'checking whether any existing information exist in AREA: CREDENTIALS-CATEGORY:DELEGATED ENTITIES NAME (T) Screen or not
                //'below if(is for when there is no existing information
                if (Emulsessiona.autECLPS.GetText(9, 6, 40).trim() == "") {

                    Emulsessiona.autECLPS.SendKeys("a", 21, 8);
                    Emulsessiona.autECLPS.SendKeys("[enter]");
                    apiChka();
                    apiChka();

                    Emulsessiona.autECLPS.SendKeys(DELEGATED_ENTITY_CODE, 9, 7);
                    ORIG_DEL_DT = ORIG_DEL_DT.split(" "); 
                    Emulsessiona.autECLPS.SendKeys(ORIG_DEL_DT[0], 10, 7);
                    Emulsessiona.autECLPS.SendKeys(ORIG_DEL_DT[1], 10, 10);
                    Emulsessiona.autECLPS.SendKeys(ORIG_DEL_DT[2], 10, 13);

                    CURRENT_DEL_DT = CURRENT_DEL_DT.split(" "); 
                    Emulsessiona.autECLPS.SendKeys(CURRENT_DEL_DT[0], 10, 28);
                    Emulsessiona.autECLPS.SendKeys(CURRENT_DEL_DT[1], 10, 31);
                    Emulsessiona.autECLPS.SendKeys(CURRENT_DEL_DT[2], 10, 34);

                    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 9, 69);
                    
                    Emulsessiona.autECLPS.SendKeys("I", 21, 8);

                    Emulsessiona.autECLPS.SendKeys("[enter]");
                    apiChka();
                    apiChka();


                    //'Error handling for provider not delegated
                    if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("PROVIDER NOT DELEGATED") >= 0) {
                        MacroOutput = MacroOutput + "\n" + "Mpin - " + MPIN + " " + Emulsessiona.autECLPS.GetText(24, 2, 40);
                        Emulsessiona.autECLPS.SendKeys("[pf4]");
                        apiChka();
                    } else {
                        //MacroOutput = MacroOutput + "\n" + "Mpin - " + MPIN + " " + Emulsessiona.autECLPS.GetText(24, 2, 40);
                        MacroOutput = MacroOutput + "\n" + "Mpin - " + MPIN + " " + "ITC credential screen has been updated ";
                        Emulsessiona.autECLPS.SendKeys("[pf4]");
                        apiChka();
                    }
                    
                    ITC_CREDENTIAL_CATEGORY = true;
                    return;
                }

                //'checking whether any existing information exist in AREA: CREDENTIALS-CATEGORY:DELEGATED ENTITIES NAME (T) Screen or not
                //'below if(will be used when there exists any information on this screen
                if (Emulsessiona.autECLPS.GetText(9, 6, 40).trim() != "") {

                    //cnt = 0;
                    //For cnt = 9 To 17 Step 2
                    for (cnt = 9; cnt <= 17; cnt += 2) {
                        if (Emulsessiona.autECLPS.GetText(cnt, 69, 9).trim() == TAX_ID_Tax.trim()) {
                            Emulsessiona.autECLPS.SendKeys("C", 21, 8);
                            Emulsessiona.autECLPS.SendKeys("[enter]");
                            apiChka();
                           
                            CURRENT_DEL_DT = CURRENT_DEL_DT.split(" "); 
                            Emulsessiona.autECLPS.SendKeys(CURRENT_DEL_DT[0], cnt + 1, 28);
                            Emulsessiona.autECLPS.SendKeys(CURRENT_DEL_DT[1], cnt + 1, 31);
                            Emulsessiona.autECLPS.SendKeys(CURRENT_DEL_DT[2], cnt + 1, 34);

                            //Emulsessiona.autECLPS.SendKeys(TAX_ID_ITC, cnt, 69);

                            Emulsessiona.autECLPS.SendKeys("I", 21, 8);

                            Emulsessiona.autECLPS.SendKeys("[enter]");
                            apiChka();
                            apiChka();

                            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim() == "") {
                                //MacroOutput = MacroOutput + "\n" + "Mpin - " + MPIN + " " + Emulsessiona.autECLPS.GetText(24, 2, 40);
                                MacroOutput = MacroOutput + "\n" + "Mpin - " + MPIN + " " + "ITC credential screen has been updated "
                                Emulsessiona.autECLPS.SendKeys("[pf4]");
                                apiChka();
                            } else {
                                MacroOutput = MacroOutput + "\n" + "Mpin - " + MPIN + " " + Emulsessiona.autECLPS.GetText(24, 2, 70);
                                Emulsessiona.autECLPS.SendKeys("[pf4]");
                                apiChka();
                            } 
                            
                            ITC_CREDENTIAL_CATEGORY = true;
                            return;

                        }
                    }

                }

                if (ITC_CREDENTIAL_CATEGORY == false) {

                    Emulsessiona.autECLPS.SendKeys("a", 21, 8);
                    Emulsessiona.autECLPS.SendKeys("[enter]");
                    apiChka();
                    apiChka();

                    Emulsessiona.autECLPS.SendKeys(DELEGATED_ENTITY_CODE, 9, 7);
                    ORIG_DEL_DT = ORIG_DEL_DT.split(" "); 
                    Emulsessiona.autECLPS.SendKeys(ORIG_DEL_DT[0], 10, 7);
                    Emulsessiona.autECLPS.SendKeys(ORIG_DEL_DT[1], 10, 10);
                    Emulsessiona.autECLPS.SendKeys(ORIG_DEL_DT[2], 10, 13);

                    CURRENT_DEL_DT = CURRENT_DEL_DT.split(" "); 
                    Emulsessiona.autECLPS.SendKeys(CURRENT_DEL_DT[0], 10, 28);
                    Emulsessiona.autECLPS.SendKeys(CURRENT_DEL_DT[1], 10, 31);
                    Emulsessiona.autECLPS.SendKeys(CURRENT_DEL_DT[2], 10, 34);

                    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 9, 69);

                    Emulsessiona.autECLPS.SendKeys("I", 21, 8);

                    Emulsessiona.autECLPS.SendKeys("[enter]");
                    apiChka();
                    apiChka();


                    //'Error handling for provider not delegated
                    if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("PROVIDER NOT DELEGATED") >= 0) {
                        MacroOutput = MacroOutput + "\n" + "Mpin - " + MPIN + " " + Emulsessiona.autECLPS.GetText(24, 2, 40);
                        Emulsessiona.autECLPS.SendKeys("[ph4]");
                        apiChka();
                    } else {
                        MacroOutput = MacroOutput + "\n" + "Mpin - " + MPIN + " " + "ITC credential screen has been updated";
                        Emulsessiona.autECLPS.SendKeys("[pf4]");
                        apiChka();
                    }
                    
                    ITC_CREDENTIAL_CATEGORY = true;
                    return;
                    
                }
                
            }
        }
    }    
}

function emulatordisplayadd(SessNameNDBa) {
    var SessNameNDB = SessNameNDBa;
    var autECLWinObj = new ActiveXObject("PCOMM.autECLWinMetrics")
    var ConnList = new ActiveXObject("PCOMM.autECLConnList")


    ConnList.Refresh;
    var iNumEmulators = ConnList.Count;
    for (i = 1; i <= iNumEmulators; i++) {
        if (ConnList(i).name == SessNameNDBa.toUpperCase()) {
            StopMacro = true;
            autECLWinObj.SetConnectionByHandle(ConnList(i).Handle)
        }

    }

    if (StopMacro == false) {

        alert("Emulator not found \nPlease sign on to respective emulator first ")

    }
    
    if (autECLWinObj.Active) {
        autECLWinObj.Active = false;
    }

    else {
        autECLWinObj.Active = true;
    }


}

function Connection_SettingAddNDB() {

    var autECLConnList = new ActiveXObject("PCOMM.autECLConnList");

    autECLConnList.Refresh;
    iNumEmulators = autECLConnList.Count;

    for (i = 1; i <= iNumEmulators; i++) {
        if (autECLConnList(i).name == SessNameNDBa.toUpperCase()) {
            StopMacro = true;
            return;
        }

    }

    if (StopMacro == false) {
        alert("Emulator not found \nPlease sign on to respective emulator first ")
    }

}

function Data_Enablementadd() {

    DivData = false;
    LOBData = false;
    CommData = false;
    LangData = false;
    ContactData = false;
    EnrollData = false;

    if (Div != "") {
        DivData = true;
    }

    if (PROV_NBR1 != "" && PROV_NBR1 != "NULL") {

    } else {
        if (DivData) {

        }
    }

    if (EFF_IUZ != "") {
        if (DivData) {

        }
    }

    if (CRED_DESIGN != "") {
        if (DivData) {

        }

    }

    if (RX_PRIV != "") {
        if (DivData) {

        }

    }

    if (RX_PRIV == "") {
        if (DivData) {
            DivData = false;
        }

    }

    if (CRED_DESIGN == "") {
        if (DivData) {
            DivData = false;
        }

    }

    if (EFF_IUZ == "") {
        if (DivData) {
            DivData = false;
        }

    }

    if (PROV_NBR1 == "") {
        if (DivData) {
            DivData = false;
        }

    }

    if (Div == "") {
        if (DivData) {
            DivData = false;
        }

    }
    // Data Enablement for LOB Screen

    if (LOB != "") {
        LOBData = true;

    }

    if (AGREEMENT_ID_BSAR != "") {
        if (LOBData) {

        }

    }

    if (EFF_DATE_BSAR != "") {
        if (LOBData) {

        }

    }

    if (PCP_BSAR != "") {
        if (LOBData) {

        }

    }

    if (PCP_BSAR == "") {
        if (LOBData) {
            LOBData = false;
        }


    }

    if (EFF_DATE_BSAR == "") {
        if (LOBData) {
            LOBData = false;
        }

    }

    if (AGREEMENT_ID_BSAR == "") {
        if (LOBData) {
            LOBData = false;
        }

    }

    if (LOB == "") {
        if (LOBData) {
            LOBData = false;
        }

    }


    //Data Enablement for Communication Screen

    if (COMMUNICATION != "") {
        CommData = true;

    }
    if (TYPE_Comm != "") {
        if (CommData) {

        }

    }
    if (PROV_ADDR != "") {
        if (CommData) {

        }

    }

    if (PROV_ADDR == "") {
        if (CommData) {
            CommData = false;
        }
    }

    if (TYPE_Comm == "") {
        if (CommData) {
            CommData = false;
        }
    }

    if (COMMUNICATION == "") {
        if (CommData) {
            CommData = false;
        }

    }
    //++++++++++Data Enablement for Language Screen

    if (LANG_CODE != "") {
        LangData = true;

    }

    if (SPOKEN_BY != "") {
        if (LangData) {

        }

    }

    if (SPOKEN_BY == "") {
        if (LangData) {
            LangData = false;

        }
    }
    if (LANG_CODE == "") {
        if (LangData) {
            LangData = false;

        }

    }
    //+++++++Data Enablement for Contact Screen

    if (CNTC_TYPE != "") {
        ContactData = true;

    }

    if (NAME != "") {
        if (ContactData) {

        }

    }

    if (COMM_TYPE != "") {
        if (ContactData) {

        }

    }

    if (PHONE_EXTN != "") {
        if (ContactData) {

        }

    }

    if (PHONE_EXTN == "") {
        if (ContactData) {
            ContactData = false;
        }

    }

    if (COMM_TYPE == "") {
        if (ContactData) {
            ContactData = false;
        }
    }

    if (NAME == "") {
        if (ContactData) {
            ContactData = false;
        }

    }

    if (CNTC_TYPE == "") {
        if (ContactData) {
            ContactData = false;
        }

    }

    if (ACCPT_PAT != "") {
        EnrollData = true;

    }

    if (ACCPT_GENDER_CD != "") {
        if (EnrollData) {

        }

    }
    if (ACCPT_MIN_AGE != "") {
        if (EnrollData) {

        }
    }
    if (ACCPT_MAX_AGE != "") {
        if (EnrollData) {

        }

    }

    if (ACCPT_EXISTING_PT != "") {
        if (EnrollData) {

        }

    }

    if (ENROLLMENT_LIMITS != "") {
        if (EnrollData) {

        }

    }
    if (ENROLLMENT_LIMITS == "") {
        if (EnrollData) {
            EnrollData = false;

        }

    }

    if (ACCPT_EXISTING_PT == "") {
        if (EnrollData) {
            EnrollData = false;

        }

    }
    if (ACCPT_MIN_AGE == "") {
        if (EnrollData) {
            EnrollData = false;

        }

    }
    if (ACCPT_MAX_AGE == "") {
        if (EnrollData) {
            EnrollData = false;

        }

    }

    if (ACCPT_GENDER_CD == "") {
        if (EnrollData) {
            EnrollData = false;

        }

    }

    if (ACCPT_PAT == "") {
        if (EnrollData) {
            EnrollData = false;

        }

    }
    
}

function Check_Nondel() {

    Check_ITC_IDC_Screen = false;
    var check = false;

    Emulsessiona.autECLPS.SendKeys("[pf3]");
    apiChka();

    Emulsessiona.autECLPS.SendKeys("I");
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");

    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);

    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    if (Emulsessiona.autECLPS.gettext(24, 2, 20).trim().indexOf("NO DATA") >= 0) {
        MacroOutput = MacroOutput + "\n" + "Mpin-" + MPIN + "-NO DATA FOUND FOR THIS SEARCH CRITERIA ";
        return;
    }

    if (Emulsessiona.autECLPS.gettext(6, 2, 70).trim().indexOf("(BIL)") >= 0 ) {
        if (ADDRESS_TYPE == "P") {
            MacroOutput = MacroOutput + "\n" + "Mpin-" + MPIN + "-PLSV address should not loaded under Bill record";
            return;
        }
    }


    Emulsessiona.autECLPS.SendKeys("1", 19, 13);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    Emulsessiona.autECLPS.SendKeys("I",21,8);
    Emulsessiona.autECLPS.SendKeys("T");
    Emulsessiona.autECLPS.SendKeys("C");

    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim() == "NO DATA EXISTS FOR SEARCH CRITERIA"){

        Emulsessiona.autECLPS.SendKeys("D", 21, 15);
        apiChka();
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();


        if (Emulsessiona.autECLPS.GetText(9,27,3).trim() == "DEL" ){
            MacroOutput = MacroOutput + "\n" + "Mpin-" + MPIN + "- is a Delegated Provider ";
            return;

        } else {
            Check_ITC_IDC_Screen = true;
        }
        
    } else if (Emulsessiona.autECLPS.GetText(9, 69, 1).trim() != "") {      

        do {

            for (var i = 9; i < 18; i += 2) {

                if (Emulsessiona.autECLPS.GetText(i, 69, 9).trim() == TAX_ID_Tax) {
                    dateITC = Emulsessiona.autECLPS.GetText(i + 1, 7, 12).trim();
                    if (Emulsessiona.autECLPS.GetText(i + 1, 54, 4).trim() == "9999") {
                        MacroOutput = MacroOutput + "\n" + "Mpin-" + MPIN + "- is a Delegated Provider ";
                        check = true;
                        return;
                        
                    }
                    
                }
                
            }

            Emulsessiona.autECLPS.Sendkeys("[pf8]");
            apiChka();

            
        } while (Emulsessiona.autECLPS.GetText(24, 2, 70).trim() != "NO MORE PAGES TO VIEW");

    } else {
        Check_ITC_IDC_Screen = true;
    }  

    if (check == false) {
        Check_ITC_IDC_Screen = true;
    }
    
}



function Check_del() {

    Check_ITC_IDC_Screen = false;
    var check = false;

    Emulsessiona.autECLPS.SendKeys("[pf3]");
    apiChka();

    Emulsessiona.autECLPS.SendKeys("I");
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");

    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);

    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    if (Emulsessiona.autECLPS.gettext(24, 2, 20).trim().indexOf("NO DATA") >= 0) {
        MacroOutput = MacroOutput + "\n" + "Mpin-" + MPIN + "-NO DATA FOUND FOR THIS SEARCH CRITERIA ";

        return;
    }

    if (Emulsessiona.autECLPS.gettext(6, 2, 70).trim().indexOf("(BIL)") >= 0) {
        if (ADDRESS_TYPE == "P") {
            MacroOutput = MacroOutput + "\n" + "Mpin-" + MPIN + "-PLSV address should not loaded under Bill record";
            return;
        }
    }


    Emulsessiona.autECLPS.SendKeys("1", 19, 13);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("T");
    Emulsessiona.autECLPS.SendKeys("C");

    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim() == "NO DATA EXISTS FOR SEARCH CRITERIA") {

        Emulsessiona.autECLPS.SendKeys("D", 21, 15);
        apiChka();
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();


        if (Emulsessiona.autECLPS.GetText(9, 27, 3).trim() == "DEL") {
            Check_ITC_IDC_Screen = true;
            check = true;
        } else {            
            MacroOutput = MacroOutput + "\n" + "Mpin-" + MPIN + "- is a Non Delegated Provider ";
            return;
        }

    } else if (Emulsessiona.autECLPS.GetText(9, 69, 1).trim() != "") {

        do {

            for (var i = 9; i < 18; i += 2) {

                if (Emulsessiona.autECLPS.GetText(i, 69, 9).trim() == TAX_ID_Tax) {
                    dateITC = Emulsessiona.autECLPS.GetText(i + 1, 7, 12).trim();
                    if (Emulsessiona.autECLPS.GetText(i + 1, 54, 4).trim() == "9999") {                        
                        Check_ITC_IDC_Screen = true;
                        check = true;                        
                        return;
                    }

                }

            }

            Emulsessiona.autECLPS.Sendkeys("[pf8]");
            apiChka();


        } while (Emulsessiona.autECLPS.GetText(24, 2, 70).trim() != "NO MORE PAGES TO VIEW");

    } else {
        Check_ITC_IDC_Screen = false;
    }

    if (Check_ITC_IDC_Screen == false) {
        Check_ITC_IDC_Screen = true;
        check = true;
    }
    
}

function Get_PTI_MPIN() {
    Get_PTI_MPIN = false;

    if (Emulsessiona.autECLPS.GetText(3, 30, 20).trim().indexOf("-- AREA MENU") < 0) {
        Emulsessiona.autECLPS.Sendkeys("[pf2]");

        apiChka();
    }

    Emulsessiona.autECLPS.SendKeys("Z", 21, 22);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    Emulsessiona.autECLPS.SendKeys("I");
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");

    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
    
    if (Emulsessiona.autECLPS.gettext(24, 2, 20).trim().indexOf("NO DATA") >= 0) {
        MacroOutput = MacroOutput + "\n" + "Mpin-" + MPIN + "-NO DATA FOUND FOR THIS SEARCH CRITERIA ";
        return;
    }

    if (Emulsessiona.autECLPS.gettext(7, 38, 4).trim().indexOf("BILL") >= 0) {
        if (Emulsessiona.autECLPS.gettext(10, 38, 4).trim() == "") {
            orphan = true;
        } else if (Emulsessiona.autECLPS.gettext(10, 38, 4).trim() != "") {
            chkActvStatus();
        }
        
    }

    Emulsessiona.autECLPS.SendKeys("[PF4]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("1", 19, 13);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
   
    Emulsessiona.autECLPS.SendKeys("T", 21, 15);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
    if (Emulsessiona.autECLPS.GetText(17,24,1).trim() != ""){
        PITmpin = Emulsessiona.autECLPS.GetText(17, 24, 9).trim();
        Get_PTI_MPIN = true;
    }
    Emulsessiona.autECLPS.SendKeys("[PF3]");
    apiChka();
    
}

var ptiMAID = "";
var PTI_MAID = false;

function Get_PTI_MAID() {
    
    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");
    apiChka();
    Emulsessiona.autECLPS.SendKeys(PITmpin, 21,31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    adrpti = ADR.split("|");
    CITY_pti = CITY_Address.split("|");
    STATE_pti = STATE_Address.split("|");
    ZIP_pti = ZIP_Address.split("|");
    
    for (var x in adrpti) {

        if (ZIP_pti[x].indexOf("-") > 0) {
            ZIP_pti[x] = ZIP_pti[x].replace("-", " ");
        }

        if (ZIP_pti[x].length != 10 ) {
            ZIP_pti[x] = ZIP_pti[x] + " " + "0000";

        }
        
        do {

            for (var pti = 7; pti < 17; pti += 3) {

                if (Emulsessiona.autECLPS.GetText(pti, 5, 33).trim() == adrpti[x]) {
                    if (Emulsessiona.autECLPS.GetText(pti + 1, 5, 30).trim().split(",")[0] == CITY_pti[x]) {
                        if (Emulsessiona.autECLPS.GetText(pti + 1, 5, 30).trim().split(" ")[1] == STATE_pti[x]) {
                            if (Emulsessiona.autECLPS.GetText(pti + 1, 5, 30).trim().split(" ")[2].split("-")[0] == ZIP_pti[x].split(" ")[0]) {
                                ptiMAID = Emulsessiona.autECLPS.GetText(pti + 1, 36, 9).trim();
                                PTI_MAID = true;
                                return;
                            }
                        }
                    }
                }  
            }

            Emulsessiona.autECLPS.Sendkeys("[pf8]");
            apiChka();

        } while (Emulsessiona.autECLPS.GetText(24, 2, 60).trim() != "THIS IS THE LAST PAGE")        
    }    
}

function Get_PTI_MAIDbyMAID(){
    
    Ma_IDc = Ma_ID.split("|");
   
    PTI_MAID = false;

    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");

    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();    
    Emulsessiona.autECLPS.SendKeys("[pf4]");
    apiChka();    
    Emulsessiona.autECLPS.SendKeys("A", 21, 8);
    Emulsessiona.autECLPS.SendKeys("A");
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();  

    Emulsessiona.autECLPS.SendKeys("1",19,13);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();  

    Emulsessiona.autECLPS.SendKeys(Ma_IDc, 6, 71);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka(); 

    if (Emulsessiona.autECLPS.GetText(7, 5, 20).trim() != "") {

        adrpti = Emulsessiona.autECLPS.GetText(7, 5, 33).trim();
        CITY_pti = Emulsessiona.autECLPS.GetText(7, 38, 16).trim();
        STATE_pti = Emulsessiona.autECLPS.GetText(7, 57, 2).trim();
        ZIP_pti = Emulsessiona.autECLPS.GetText(7, 60, 10).trim();

    } else if (Emulsessiona.autECLPS.GetText(24, 2, 54).trim().indexOf("NO MATCH FOUND ON MASTER ADDRESS FOR SEARCH CRITERIA") >= 0) {
        MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 70).trim();
        return;
    }


    Emulsessiona.autECLPS.SendKeys("[pf3]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");
    apiChka();
    Emulsessiona.autECLPS.SendKeys(PITmpin, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
    
    if (ZIP_pti.indexOf("-") > 0) {
        ZIP_pti = ZIP_pti.replace("-", " ");
    }

    if (ZIP_pti.length != 10) {
        ZIP_pti = ZIP_pti + " " + "0000";

    }

    do {

        for (var pti = 7; pti < 17; pti += 3) {

            if (Emulsessiona.autECLPS.GetText(pti, 5, 33).trim() == adrpti) {
                if (Emulsessiona.autECLPS.GetText(pti + 1, 5, 30).trim().split(",")[0] == CITY_pti) {
                    if (Emulsessiona.autECLPS.GetText(pti + 1, 5, 30).trim().split(" ")[1] == STATE_pti) {
                        if (Emulsessiona.autECLPS.GetText(pti + 1, 5, 30).trim().split(" ")[2].split("-")[0] == ZIP_pti.split(" ")[0]) {
                            ptiMAID = Emulsessiona.autECLPS.GetText(pti + 1, 36, 9).trim();
                            PTI_MAID = true;
                            return;
                        }
                    }
                }
            }
        }

        Emulsessiona.autECLPS.Sendkeys("[pf8]");
        apiChka();

    } while (Emulsessiona.autECLPS.GetText(24, 2, 60).trim() != "THIS IS THE LAST PAGE")
       
}

function Adr_Serch_And_Add() {

    Adr_Serch_And_Add_1 = false;

    if (ADR == "") {
        Adr_Serch_With_Maid();
        Adr_Serch_And_Add_1 = true;
        return;
    }

    

    piped = ADR.split(",");
    ADRc = ADR.split(",");
    ZIP_Addressc = ZIP_Address.split(",");
    STATE_Addressc = STATE_Address.split(",");
    CITY_Addressc = CITY_Address.split(",");
    TELEPHONE_EXTNc = TELEPHONE_EXTN.split(",");
    TELEPHONE_EXTN_FAXc = TELEPHONE_EXTN_FAX.split(",");

    //'===============================Address Macthing Screen=========================================
    //For x = 0 To UBound(piped)
    for (var x in piped) {
        //'x = 0
        Main_SCREEN();
        apiChka();


        if (Main_SCREEN == false) {
            return;
        }



        Emulsessiona.autECLPS.SendKeys(ADRc[x], 6, 5);

        //'Error handling for ZIP Code length less than 5
        //if(Len(Trim(Left(ZIP_Addressc[x], 5))) < 5 ){
        if (ZIP_Addressc[x].slice(0, 5).trim().length < 5) {
            ZIP_Addressc[x] = "0" + ZIP_Addressc[x];
        }
        else if (ZIP_Addressc[x].slice(0, 5).trim().length < 4) {

            ZIP_Addressc[x] = "00" + ZIP_Addressc[x].slice(0, 5).trim();
        }
            //ElseIf Len(Trim(Left(ZIP_Addressc[x], 5))) < 3 ){
        else if (ZIP_Addressc[x].slice(0, 5).trim().length < 3) {
            ZIP_Addressc[x] = "000" + ZIP_Addressc.slice(0, 5).trim();
        }
            //ElseIf Len(Trim(Left(ZIP_Addressc[x], 5))) < 2 ){
        else if (ZIP_Addressc[x].slice(0, 5).trim().length < 2) {
            ZIP_Addressc[x] = "0000" + ZIP_Addressc[x].slice(0, 5).trim();
        }


        Emulsessiona.autECLPS.SendKeys(ZIP_Addressc[x].slice(0, 5), 6, 60);
        apiChka();

        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();

        //VerifyUSPS();

        if (Emulsessiona.autECLPS.GetText(24, 2, 54).trim().indexOf("NO MATCH FOUND ON MASTER ADDRESS FOR SEARCH CRITERIA") >= 0) {
            MacroOutput = "NO MATCH FOUND ON MASTER ADDRESS FOR SEARCH CRITERIA in *ADDRESS SELECTION* Screen ."
            return;
        }
        

        if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("MASTER") > 0) {
            VerifyUSPS();
        }

        Adress_Match(x);

        //'====================================(Updating vale on the screen)================

        apiChka();
        if (Emulsessiona.autECLPS.GetText(2, 2, 5).trim() != "TAXID") {
            MacroOutput = MacroOutput + "ADDRESS ADD Screen not found. Macro stopped. ";
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            return;
        }

        //'if(ADDRESS_TYPE.split("|")[x].toUpperCase()) = "B" Or ADDRESS_TYPE.split("|")[x].toUpperCase()) = "C" ){
        if (ADDRESS_TYPE.split(",")[x].toUpperCase() == "B" || ADDRESS_TYPE.split("|")[x].toUpperCase() == "C") {
            if (DBA_NAME.split("|")[x] != "NA" && DBA_NAME.split("|")[x] != "") {
                Emulsessiona.autECLPS.SendKeys(DBA_NAME.split("|")[x], 12, 12);
            }
        }

        AddMA_ID_new = Emulsessiona.autECLPS.GetText(3, 58, 9).trim();

        //if(ADDRESS_TYPE.split("|")[x].toUpperCase()) != "NA" ){

        Emulsessiona.autECLPS.SendKeys(ADDRESS_TYPE.split("|")[x], 11, 13);
        Emulsessiona.autECLPS.SendKeys(PS1.split("|")[x], 11, 52);

        EFF_DATE_Address = EFF_DATE_Address.replace(" ", ""); EFF_DATE_Address = EFF_DATE_Address.replace(" ", "");

        Emulsessiona.autECLPS.SendKeys(EFF_DATE_Address.slice(0, 2), 14, 7);
        Emulsessiona.autECLPS.SendKeys(EFF_DATE_Address.substring(4, 2), 14, 10);
        Emulsessiona.autECLPS.SendKeys(EFF_DATE_Address.substring(8, 4), 14, 13);

        for (var M in TELEPHONE_EXTNc) {

            TELEPHONE_EXTNc[M] = TELEPHONE_EXTNc[M].replace(" ", ""); TELEPHONE_EXTNc[M] = TELEPHONE_EXTNc[M].replace(" ", "");


            if (Emulsessiona.autECLPS.GetText(17, 2, 1).trim() == "") {

                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(0, 3), 17, 2);
                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(6, 3), 17, 6);
                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(10, 6), 17, 10);
                if (Extn.split("|")[M] != "") {
                    Emulsessiona.autECLPS.SendKeys(Extn.split("|")[M], 17, 16);
                }
                Emulsessiona.autECLPS.SendKeys(PS2.split("|")[M], 17, 22);
                Emulsessiona.autECLPS.SendKeys(ADDR_TYPE.split("|")[M], 17, 25);
                continue;
            }
            if (Emulsessiona.autECLPS.GetText(17, 38, 1).trim() == "") {

                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(0, 3), 17, 38);
                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(6, 3), 17, 42);
                Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTNc[M].substring(10, 6), 17, 46);
                if (Extn.split("|")[M] != "") {
                    Emulsessiona.autECLPS.SendKeys(Extn.split("|")[M], 17, 52);
                }
                Emulsessiona.autECLPS.SendKeys(PS2.split("|")[M], 17, 58);
                Emulsessiona.autECLPS.SendKeys(ADDR_TYPE.split("|")[M], 17, 61);
                continue;
            }

        }

        if (TELEPHONE_EXTN_FAX != "") {

            for (var N in TELEPHONE_EXTN_FAXc) {

                TELEPHONE_EXTN_FAXc[N] = TELEPHONE_EXTN_FAXc[N].replace(" ", ""); TELEPHONE_EXTN_FAXc[N] = TELEPHONE_EXTN_FAXc[N].replace(" ", "");

                if (Emulsessiona.autECLPS.GetText(17, 38, 1).trim() == "") {

                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(0, 3), 17, 38);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(6, 3), 17, 42);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(10, 6), 17, 46);
                    Emulsessiona.autECLPS.SendKeys("S", 17, 58);
                    Emulsessiona.autECLPS.SendKeys("F", 17, 61);
                    continue;
                }
                if (Emulsessiona.autECLPS.GetText(18, 2, 1).trim() == "") {

                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(0, 3), 18, 2);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(6, 3), 18, 6);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(10, 3), 18, 10);
                    Emulsessiona.autECLPS.SendKeys("S", 18, 22);
                    Emulsessiona.autECLPS.SendKeys("F", 18, 25);
                    continue;
                }

                if (Emulsessiona.autECLPS.GetText(18, 38, 1).trim() == "") {

                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(0, 3), 18, 38);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(6, 3), 18, 42);
                    Emulsessiona.autECLPS.SendKeys(TELEPHONE_EXTN_FAXc[N].substring(10, 6), 18, 46);
                    Emulsessiona.autECLPS.SendKeys("S", 18, 58);
                    Emulsessiona.autECLPS.SendKeys("F", 18, 61);
                    continue;
                }
            }
        }

        //(ADDRESS_TYPE.split("|")[x].toUpperCase())

        if ((CORRESPONDANCE.split("|")[x].toUpperCase()) != "NA") {
            Emulsessiona.autECLPS.SendKeys(CORRESPONDANCE.split("|")[x], 11, 80)
        }

        //'   if(UCase(Trim(PCP_BSAR)) = "P" ){
        //'    apiChka();
        //'    Call InfoGrab_CLN
        //'    apiChka();
        //'   }

        //'===========================I in function for the update======
        if (ADR.indexOf("|") > 0) {
            //Emulsessiona.autECLPS.SendKeys("I", 21, 8);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();

            
            //'***************NORMALIZED USPS MASTER ADDR ALERDY EXISTS******************
            apiChka();
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("NORMALIZED USPS MASTER ADDR")>=0) {
               
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();               
                //'Emulsessiona.autECLPS.SendKeys ( "[PF4]");
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                //return; //'remove
            }
            apiChka();
            //'***************if(we have any Invalid TAX ID******************
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("INACTIVE TAXID")>=0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return; //'remove
            }
            apiChka();
            //'Effective Date is greater than or equal to TAXID Original Effective Date
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("EFF DATE MUST BE >= THE TAXID")>0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return;//'remove
            }

            //'Address not found in Code1 - as in the address input provided is incorrect
            apiChka();
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("ADDR NOT FOUND IN CODE1")>=0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return;//'remove
            }

            //'ENTER OVERRIDE = Y for ORIG ADDR
            apiChka();
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("ENTER OVERRIDE = Y FOR ORIG ADDR:") > 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[pf4]");
                apiChka();
                return;
            }

            //'Error handling for Invalid Value - Phone Type Values
            apiChka();
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("INVALID VALUE - PHONE TYPE") > 0) {
                Emulsessiona.autECLPS.SendKeys("PLSV", 17, 25);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }

            //'Address already loaded
            apiChka();
            if (Emulsessiona.autECLPS.GetText(24, 2, 20).trim().toUpperCase().indexOf("ADDRESS")>=0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return; //'remove
            }

            //'STREET NOT IN ZIP, CANNOT BE VERIFIED
            apiChka();
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("STREET NOT IN ZIP")>=0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return; //'remove
            }

            //ZIP CODE NOT FOUND IN CODE1 MASTER FILE
            apiChka();
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("ZIP CODE NOT FOUND IN CODE1 MASTER FILE") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return;//'remove
            }


            //'additional enter for error message DO YOU WANT TO ADD PHYSICIAN//'S ADDRESS
            apiChka();
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("DO YOU WANT TO ADD")>=0) {
                //'Emulsessiona.autECLPS.SendKeys ( "[PF4]" );
                Emulsessiona.autECLPS.SendKeys("[Enter]");
                apiChka();
                apiChka();
            }
            apiChka();
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("FQHC") >= 0) {
                Emulsessiona.autECLPS.SendKeys("N", 24, 71);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("[Enter]");
                apiChka();
                apiChka();
            }
            
            //'additional enter for error message REMEMBER
            apiChka();
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("REMEMBER")>=0) {
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }

            //'additional enter for error message GROUP RECORD WAS RE-ACTIVATED PER CANCEL DATE, ONLY
            apiChka();
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("GROUP RECORD WAS RE-ACTIVATED")>=0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }

            //'additional enter for error message DO YOU WANT TO ADD PHYSICIAN//'S ADDRESS
            apiChka();
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("DO YOU WANT TO ADD")>=0) {
                //'Emulsessiona.autECLPS.SendKeys ( "[PF4]" );
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }

            //'additional enter for error message REMEMBER
            apiChka();
            if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("REMEMBER")>=0) {
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }

            if (Emulsessiona.autECLPS.GetText(24, 2, 20).trim().toUpperCase().indexOf("INVALID KEY") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return;//'remove
            }

            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("VALUES ARE") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return; //'remove
            }

            if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("MUST ADD ONE PRIMARY PHONE NUMBER") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return; //'remove
            }

            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("INVALID VALUE") >= 0) {
                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();
                return; //'remove
            }
            //if((Emulsessiona.autECLPS.GetText(2, 2, 15))) Like "*FUNCTIONS*" && x != UBound(piped) ){
            //if((Emulsessiona.autECLPS.GetText(2, 2, 15))) Like "*FUNCTIONS*" && x != UBound(piped) ){

            //******
            //if (Emulsessiona.autECLPS.GetText(2, 2, 15).indexOf("FUNCTIONS") >=0  && x != piped.length) {
            //    //if(ADDRESS_TYPE.split("|")[x].toUpperCase()) = "P" ){
            //    if (ADDRESS_TYPE.split("|")[x] = "P") {
            //        //'Emulsessiona.autECLPS.SendKeys ( "[PF4]" );
            //        //'apiChka();
            //        Emulsessiona.autECLPS.SendKeys("A", 21, 8);
            //        Emulsessiona.autECLPS.SendKeys("A", 21, 15);
            //        Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
            //        Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
            //        //'Emulsessiona.autECLPS.SendKeys ( Ma_ID, 21, 47
            //        if (ADDRESS_TYPE.toUpperCase().indexOf("B") >= 0) {
            //            Emulsessiona.autECLPS.SendKeys(NewMA_ID, 21, 47);
            //        } else {
            //            Emulsessiona.autECLPS.SendKeys(Ma_ID, 21, 47);
            //        }
            //        Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
            //        apiChka();
            //        Emulsessiona.autECLPS.SendKeys("[enter]");
            //        apiChka();
            //    }
            //}
            //*********
            apiChka();
            if (Emulsessiona.autECLPS.GetText(2, 2, 15).trim().toUpperCase().indexOf("FUNCTIONS") >= 0) {
                Adr_Serch_And_Add_1 = true;
                addAddress = true;
                MacroOutput = MacroOutput + "\n" +"Address has been Loaded";
                apiChka();
                
                //'Application.Wait (Now + TimeValue("00:00:01"))
                //Exit For
                //break
            }



            //'NewMA_ID = ""
            //'NewSelection = ""
            //'adding additional function to pull the selection if(the Address type added is Bill || Combo
            //if (NewMA_ID = "") {
            //    if ((ADDRESS_TYPE.split("|")[x].toUpperCase() == "B" || ADDRESS_TYPE.split("|")[x].toUpperCase() == "C")) {
            //        apiChka();
            //        GetNewB_CAdd_Selection(x);
            //        apiChka();
            //        Emulsessiona.autECLPS.SendKeys("[pf4]");
            //        apiChka();
            //        //'Debug.Print NewMA_ID
            //        //'NewMA_ID = "000209325"
            //        Emulsessiona.autECLPS.SendKeys("A", 21, 8);
            //        Emulsessiona.autECLPS.SendKeys("A", 21, 15);
            //        Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
            //        Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
            //        Emulsessiona.autECLPS.SendKeys(NewMA_ID, 21, 47);
            //        Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
            //        apiChka();
            //        Emulsessiona.autECLPS.SendKeys("[enter]");
            //        apiChka();
            //    }
            //}

            if (NewMA_ID != "" && NewSelection == "") {
                Emulsessiona.autECLPS.SendKeys("A", 21, 8);
                Emulsessiona.autECLPS.SendKeys("A", 21, 15);
                Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
                Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
                //'Emulsessiona.autECLPS.SendKeys ( NewMA_ID, 21, 47
                Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }
            
            apiChka();
            Emulsessiona.autECLPS.SendKeys("1", 19, 13);
            //'Emulsessiona.autECLPS.SendKeys ( NewSelection, 19, 13
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
           
        }

        //'if(last address is getting added - ){ last enter on address screen
        if (ADR.indexOf("|") <= 0) {
            //Emulsessiona.autECLPS.SendKeys("I", 21, 8);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'NORMALIZED USPS MASTER ADDR ALERDY EXISTS
        apiChka();
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("NORMALIZED USPS MASTER ADDR")>=0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            //'Emulsessiona.autECLPS.SendKeys ( "[PF4]"
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            //return; //'remove
        }

        //'Invalid TAX ID
        apiChka();
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("INACTIVE TAXID")>=0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return;//'remove
        }
        apiChka();
        //'Effective Date is greater than or equal to TAXID Original Effective Date
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("EFF DATE MUST BE >= THE TAXID")>=0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return;//'remove
        }

        //'Address not found in Code1 - as in the address input provided is incorrect
        apiChka();
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("ADDR NOT FOUND IN CODE1")>=0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return;//'remove
        }

        //'STREET NOT IN ZIP, CANNOT BE VERIFIED
        apiChka();
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("STREET NOT IN ZIP")>=0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return;//'remove
        }

        //ZIP CODE NOT FOUND IN CODE1 MASTER FILE
        apiChka();
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().toUpperCase().indexOf("ZIP CODE NOT FOUND IN CODE1 MASTER FILE") >= 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return;//'remove
        }
        
        //'ENTER OVERRIDE = Y for ORIG ADDR
        apiChka();
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("ENTER OVERRIDE = Y FOR ORIG ADDR:") >= 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            apiChka();
            return;
        }

        //'Error handling for Invalid Value - Phone Type Values
        apiChka();
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("INVALID VALUE - PHONE TYPE") >= 0) {
            Emulsessiona.autECLPS.SendKeys("PLSV", 17, 25);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'Address already loaded
        apiChka();
        if (Emulsessiona.autECLPS.GetText(24, 2, 20).trim().toUpperCase().indexOf("ADDRESS")>=0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return;//'remove
        }
        //'additional enter for error message DO YOU WANT TO ADD PHYSICIAN//'S ADDRESS
        apiChka();
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("DO YOU WANT TO ADD")>=0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        apiChka();
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("FQHC") >= 0) {
            Emulsessiona.autECLPS.SendKeys("N", 24, 71);
            apiChka();
            Emulsessiona.autECLPS.SendKeys("[Enter]");
            apiChka();
            apiChka();
        }


        //'additional enter for error message REMEMBER
        apiChka();
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("REMEMBER")>=0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'additional enter for error message GROUP RECORD WAS RE-ACTIVATED PER CANCEL DATE, ONLY
        apiChka();
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("GROUP RECORD WAS RE-ACTIVATED")>=0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'additional enter for error message DO YOU WANT TO ADD PHYSICIAN//'S ADDRESS
        apiChka();
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("DO YOU WANT TO ADD")>=0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        //'additional enter for error message REMEMBER
        apiChka();
        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().toUpperCase().indexOf("REMEMBER")>0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            apiChka();
        }

        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("VALUES ARE") >= 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return; //'remove
        }

        if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("MUST ADD ONE PRIMARY PHONE NUMBER") >= 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return; //'remove
        }

        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("INVALID VALUE") >= 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return; //'remove
        }

        if (Emulsessiona.autECLPS.GetText(24, 2, 20).trim().toUpperCase().indexOf("INVALID KEY") >= 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 65).trim();
            Emulsessiona.autECLPS.SendKeys("[PF4]");
            apiChka();
            return;//'remove
        }

        apiChka();
        if (Emulsessiona.autECLPS.GetText(2, 2, 15).trim().toUpperCase().indexOf("FUNCTIONS")>= 0 ) {
            Adr_Serch_And_Add_1 = true;
            addAddress = true;
            MacroOutput = MacroOutput + "\n" + "Address has been Loaded";
            apiChka();
            apiChka();
            //'Application.Wait (Now + TimeValue("00:00:01"))
            //Exit For
            //break
        }
        
        apiChka();
        apiChka();
        

    }
    //'adding additional function to pull the selection if(the Address type added is Bill || Combo
    //if (NewMA_ID = "") {
    //    if ((ADDRESS_TYPE.split("|")[x].toUpperCase()) == "B" || (ADDRESS_TYPE.split("|")[x].toUpperCase()) == "C") {
    //        GetNewB_CAdd_Selection(x);
    //        apiChka();
    //        apiChka();
    //        //'Application.Wait (Now + TimeValue("00:00:01"))
    //    }
    //}

    apiChka();
    if (Emulsessiona.autECLPS.GetText(4, 13, 5).trim().toUpperCase().indexOf("NAME")>=0) {
        //'Emulsessiona.autECLPS.SendKeys ( "[PF2]"
        Adr_Serch_And_Add_1 = true;
        apiChka();
        
        //'Application.Wait (Now + TimeValue("00:00:01"))
        return;
    }
}

function Cosmos_Demographics() {

    apiChka();
    DivS = Div.split("|");

    do {

        for (cnt = 8; cnt < 18; cnt++) {

            if (Emulsessiona.autECLPS.GetText(cnt, 7, 4).trim() == BAID) {

                selectionCode = Emulsessiona.autECLPS.GetText(cnt, 2, 3).trim();
                //billA_id = Emulsessiona.autECLPS.GetText(cnt, 7, 5).trim();

                apiChka(); //inserting a short delay

                if (DivData == true) {
                    UHCID_Creation();
                    return;
                } else {
                    if (MacroOutput == "") {
                        MacroOutput = "UHCID Data not completely available. Macro skipped UHCID Creation. ";
                        return;
                    } else {
                        MacroOutput = MacroOutput + "\n" + "UHCID Data not completely available. Macro skipped UHCID Creation. ";
                        return;

                    }
                }
                apiChka(); //inserting a short delay
                selectionCode = "";
                //billA_id = "";
            }
        }
        //+++++++page forward in case of New BillA-ID is not found on UHCID Selection Screen+++++++            
        Emulsessiona.autECLPS.SendKeys("[PF8]");

        apiChka();

        if (Emulsessiona.autECLPS.GetText(1, 70, 3).trim() == Emulsessiona.autECLPS.GetText(1, 77, 3).trim() && Emulsessiona.autECLPS.GetText(1, 70, 3).trim() != "1") {

            for (cnt = 8; cnt < 18; cnt++) {

                if (Emulsessiona.autECLPS.GetText(cnt, 7, 4).trim() == BAID) {

                    selectionCode = Emulsessiona.autECLPS.GetText(cnt, 2, 3).trim();
                    //billA_id = Emulsessiona.autECLPS.GetText(cnt, 7, 5).trim();

                    apiChka(); //inserting a short delay

                    if (DivData == true) {
                        UHCID_Creation();
                        return;
                    } else {
                        if (MacroOutput == "") {
                            MacroOutput = "UHCID Data not completely available. Macro skipped UHCID Creation. ";
                            return;
                        } else {
                            MacroOutput = MacroOutput + "\n" + "UHCID Data not completely available. Macro skipped UHCID Creation. ";
                            return;

                        }
                    }
                    apiChka(); //inserting a short delay
                    selectionCode = "";
                    //billA_id = "";
                }
            }
        }

    } while (Emulsessiona.autECLPS.GetText(24, 1, 60).indexOf("LAST PAGE") <= 0);

}

function UHCID_Creation() {

    UHCID_Creation = false;
    apiChka();

    DivS = Div.split(",");

    Emulsessiona.autECLPS.SendKeys(selectionCode, 18, 13);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
    selectionCode = "";

    for (var x in DivS) {
        
        if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("SELECTED ADDRESS HAS NO UHCID") >= 0) {

            Emulsessiona.autECLPS.SendKeys("[pf4]");
            apiChka();
            Emulsessiona.autECLPS.SendKeys("I", 21, 8);
            Emulsessiona.autECLPS.SendKeys("M");
            Emulsessiona.autECLPS.SendKeys("Z");
            Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
            apiChka();
            Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();

            Emulsessiona.autECLPS.SendKeys("A", 21, 8);
            Emulsessiona.autECLPS.SendKeys("U", 21, 15);
            Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
            Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
            apiChka();
            Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            Emulsessiona.autECLPS.SendKeys("1", 19, 13);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            CosmosExp = 1;

        }

        if (x == 0) {

            Emulsessiona.autECLPS.SendKeys(DivS[x], 3, 7);
            Emulsessiona.autECLPS.SendKeys(PROV_NBR1, 3, 21);
            if (paid != "") {
                Emulsessiona.autECLPS.SendKeys(paid, 7, 75);
            }


            EFF_IUZ = EFF_IUZ.replace(" ", ""); EFF_IUZ = EFF_IUZ.replace(" ", "");

            Emulsessiona.autECLPS.SendKeys(EFF_IUZ.slice(0, 2), 3, 40);
            Emulsessiona.autECLPS.SendKeys(EFF_IUZ.substring(4, 2), 3, 43);
            Emulsessiona.autECLPS.SendKeys(EFF_IUZ.substring(8, 4), 3, 46);

            Emulsessiona.autECLPS.SendKeys(CLN, 5, 7);
            Emulsessiona.autECLPS.SendKeys("Y", 7, 59);
            Emulsessiona.autECLPS.SendKeys("MI", 8, 7);
            Emulsessiona.autECLPS.SendKeys(CRED_DESIGN, 8, 22);
            Emulsessiona.autECLPS.SendKeys("N", 15, 13);
            Emulsessiona.autECLPS.SendKeys(UR_IND, 15, 60);
            Emulsessiona.autECLPS.SendKeys(RX_PRIV, 16, 11);
            Emulsessiona.autECLPS.SendKeys(RX_NBR, 3, 21);

            Emulsessiona.autECLPS.SendKeys("I", 21, 8);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();

            if (Emulsessiona.autECLPS.GetText(24, 2, 20).trim().indexOf("RX NBR") > 0) {
                Emulsessiona.autECLPS.SendKeys("[erase eof]", 16, 21);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("[erase eof]", 16, 26);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }

            if (Emulsessiona.autECLPS.gettext(24, 2, 70).trim().indexOf("DEA ON FILE, RX PRIV MUST BE P,B OR X") >= 0) {

                if (Emulsessiona.autECLPS.gettext(16, 39, 5).trim() != "") {
                    Emulsessiona.autECLPS.SendKeys("B", 16, 11);
                } else {
                    Emulsessiona.autECLPS.SendKeys("M", 16, 11);
                }

                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }
            
            //“ADD COSMOS PANELS – IF APPLICABLE”
            if (Emulsessiona.autECLPS.GetText(24, 2, 20).trim().indexOf("COSMOS") > 0) {
                MacroOutput = MacroOutput + "\n" + DivS[x] + "- DIV is loaded in UHCID screen ";
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();                
            } 
             else {
                Err = Emulsessiona.autECLPS.gettext(24, 2, 70).trim();
                MacroOutput = MacroOutput + "\n" + Err;
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                return;                    
            }
                
            
                
        } else {

            apiChka();

            if (CosmosExp1 == 1) {

                apiChka();
                Emulsessiona.autECLPS.SendKeys(DivS[x], 3, 7);
                Emulsessiona.autECLPS.SendKeys(PROV_NBR1, 3, 21);
                if (paid != "") {
                    Emulsessiona.autECLPS.SendKeys(paid, 7, 75);
                }
                
                EFF_IUZ = EFF_IUZ.replace(" ", ""); EFF_IUZ = EFF_IUZ.replace(" ", "");

                Emulsessiona.autECLPS.SendKeys(EFF_IUZ.slice(0, 2), 3, 40);
                Emulsessiona.autECLPS.SendKeys(EFF_IUZ.substring(4, 2), 3, 43);
                Emulsessiona.autECLPS.SendKeys(EFF_IUZ.substring(8, 4), 3, 46);

                Emulsessiona.autECLPS.SendKeys(CLN, 5, 7);
                Emulsessiona.autECLPS.SendKeys("Y", 7, 59);
                Emulsessiona.autECLPS.SendKeys("MI", 8, 7);
                Emulsessiona.autECLPS.SendKeys(CRED_DESIGN, 8, 22);
                Emulsessiona.autECLPS.SendKeys("N", 15, 13);
                Emulsessiona.autECLPS.SendKeys(UR_IND, 15, 60);
                Emulsessiona.autECLPS.SendKeys(RX_PRIV, 16, 11);
                Emulsessiona.autECLPS.SendKeys(RX_NBR, 3, 21);

                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();

            } else {

                loop();
                Emulsessiona.autECLPS.SendKeys(selectionCode, 18, 13);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                selectionCode = "";

                Emulsessiona.autECLPS.SendKeys("R", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();

                Emulsessiona.autECLPS.SendKeys(DivS[x], 3, 7);
               
                apiChka();
                Emulsessiona.autECLPS.SendKeys("[erase eof]", 3, 26);
                apiChka();
                apiChka();
                
            }

            Emulsessiona.autECLPS.SendKeys("I", 21, 8);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();

            if (Emulsessiona.autECLPS.GetText(2, 38, 30).trim() == "UHCID SELECTION") {
                MacroOutput = MacroOutput + "\n" + DivS[x] + "- DIV is loaded in UHCID screen ";
                apiChka();
                continue;
            }
            
            if (Emulsessiona.autECLPS.GetText(24, 2, 20).trim().indexOf("RX NBR") > 0) {
                Emulsessiona.autECLPS.SendKeys("[erase eof]", 16, 21);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("[erase eof]", 16, 26);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }

            if (Emulsessiona.autECLPS.GetText(2, 38, 30).trim() == "UHCID SELECTION") {
                MacroOutput = MacroOutput + "\n" + DivS[x] + "- DIV is loaded in UHCID screen ";
                apiChka();
                continue;
            }
            
            //Additional Add Message
            if (Emulsessiona.autECLPS.gettext(24, 2, 70).trim().indexOf("DEA ON FILE, RX PRIV MUST BE P,B OR X") >= 0) {

                if (Emulsessiona.autECLPS.gettext(16, 39, 5).trim() != "") {
                    Emulsessiona.autECLPS.SendKeys("B", 16, 11);
                } else {
                    Emulsessiona.autECLPS.SendKeys("M", 16, 11);
                }

                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                apiChka();
            }

            if (Emulsessiona.autECLPS.GetText(2, 38, 30).trim() == "UHCID SELECTION") {
                MacroOutput = MacroOutput + "\n" + DivS[x] + "- DIV is loaded in UHCID screen ";
                apiChka();
                continue;
            }
            
            //“ADD COSMOS PANELS – IF APPLICABLE”
            if (Emulsessiona.autECLPS.GetText(24, 2, 20).trim().indexOf("COSMOS") > 0 ) {
                MacroOutput = MacroOutput + "\n" + DivS[x] + "- DIV is loaded in UHCID screen ";
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }
            else {
                Err = Emulsessiona.autECLPS.gettext(24, 2, 70).trim();
                MacroOutput = MacroOutput + "\n" + Err;
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                return;
            }
         
            //Error handling for invalid date in cosmos screen or not valid for PLSV, MUST Exp Timeline, Add to Bill
            if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("INVALID COSMOS EXPIRATION CODE") >= 0 || Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("NOT VALID FOR PLSV") >= 0) {

                Emulsessiona.autECLPS.SendKeys("[PF5]");
                apiChka();
                Emulsessiona.autECLPS.SendKeys("[PF4]");
                apiChka();

                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("M");
                Emulsessiona.autECLPS.SendKeys("Z");
                Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
                apiChka();
                Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();

                Emulsessiona.autECLPS.SendKeys("A", 21, 8);
                Emulsessiona.autECLPS.SendKeys("U", 21, 15);
                Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
                Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
                apiChka();
                Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                Emulsessiona.autECLPS.SendKeys("1", 19, 13);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                CosmosExp1 = 1;

            }

            //Error handling - for already added BILL PLSV SEQ Existence under Prov Num:
            if (Emulsessiona.autECLPS.GetText(24, 2, 30).trim().indexOf("BILL, PLSV SEQ EXIST") >= 0) {

                Emulsessiona.autECLPS.Sendkeys("[pf5]");
                apiChka();
            }

            if (Emulsessiona.autECLPS.GetText(24, 2, 3).trim() == "ADD") {

                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }
        }
    }

    UHCID_Creation = true;
}

var BSARid_Screen;
var ScreenOk1 = false;
var ScreenOk2 = false;

function GroupBSAR() {

    apiChka();
    //'taking the MPIN from Session A where GROUP BSAR DOES NOT EXIST, ADD BSAR FOR MPIN INSTANCE AP occurs
    //GroupMPIN = Trim(Mid(Trim(Emulsessiona.autECLPS.GetText(24, 2, 60)), InStr(Trim(Emulsessiona.autECLPS.GetText(24, 2, 60)), "MPIN ") + 4, 8));
    apiChka();
    //below code will function on Session B od UNET NDB
    if (Emulsessiona.autECLPS.GetText(3, 37, 20).trim().indexOf("AREA MENU") > 0) {
        Emulsessiona.autECLPS.SendKeys("Z", 21, 22);
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();

    }

    apiChka();
    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");
    Emulsessiona.autECLPS.SendKeys(GroupMPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    Emulsessiona.autECLPS.SendKeys("[pf4]")
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[pf4]")
    //doing Func: a Cate: 7 and Area: z to go to Business Segment Address Selection Screen

    Emulsessiona.autECLPS.SendKeys("A", 21, 8);
    Emulsessiona.autECLPS.SendKeys("7");
    Emulsessiona.autECLPS.SendKeys("Z");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
    //add code here with the selection for billing address which was loaded thru this automation
    Emulsessiona.autECLPS.SendKeys("1");
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    //'Error handling for BUSINESS SEGMENT ADDRESS SELECTION SCREEN - AMR_
    //'Screen where it asks for bringing all address records over
    if (Emulsessiona.autECLPS.GetText(24, 2, 40).trim().indexOf("DO YOU WANT TO BRING ALL") > 0) {
        apiChka();
        Emulsessiona.autECLPS.SendKeys("Y", 19, 59);
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();

        for (var i = 0; i < 11; i++) {
            Emulsessiona.autECLPS.SendKeys(INSTANCE, 18, 3);
            apiChka();
            Emulsessiona.autECLPS.SendKeys("I", 21, 8);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            //'Additional Check point which will gauge whether FOR Loop should be exited or not
            if (Emulsessiona.autECLPS.GetText(4, 2, 40).trim().indexOf("NAME/BILL TO PLSV") > 0) {
                apiChka();
                return;
            }

        }

    }

}

var LOBInfo_Screen = false;
var ScreenLOBok = false;

function LOBInfo_Screen() {

    if (Emulsessiona.autECLPS.GetText(1, 55, 20).trim().indexOf("ADR SEQ(BSAR):") > 0) {
        ScreenLOBok = true;

    } else {
        MacroOutput = MacroOutput + "\n" + "BSAR4 Screen not found for LOB load. Macro stopped.";
        return;
    }

    LOBs = LOB.split("|");
    AgrmntIDs = AGREEMENT_ID_BSAR.split("|");
    PCPAgrmntIDs = PCP_AGREEMENT_NROW_ID_BSAR.split("|");
    IPAIDs = IPA_ID.split("|");

    for (var cnt in LOBs) {

        Emulsessiona.autECLPS.SendKeys(LOBs[cnt], 8, 2) //'entering the LOB value

        if (IPA_ID != "") {
            if (IPAIDs[cnt] != "" && IPAIDs[cnt] != "NA") {
                Emulsessiona.autECLPS.SendKeys(IPAIDs[cnt], 9, 9);
            }
        }

        Emulsessiona.autECLPS.SendKeys(AgrmntIDs[cnt], 10, 17);

        EFF_DATE_BSAR = EFF_DATE_BSAR.replace(" ", ""); EFF_DATE_BSAR = EFF_DATE_BSAR.replace(" ", "");

        Emulsessiona.autECLPS.SendKeys(EFF_DATE_BSAR.slice(0, 2), 12, 12);
        Emulsessiona.autECLPS.SendKeys(EFF_DATE_BSAR.substring(4, 2), 12, 15);
        Emulsessiona.autECLPS.SendKeys(EFF_DATE_BSAR.substring(8, 4), 12, 18);

        Emulsessiona.autECLPS.SendKeys(PCP_BSAR, 17, 7); //'entering PCP Field

        //in case of PCP indicator as P - we need to fill in Enrollment Screen as well which will be F6 Screen

        if (PCP_BSAR.toUpperCase == "P") {
            apiChka();
            Emulsessiona.autECLPS.SendKeys("[pf9]");
            apiChka();
            Emulsessiona.autECLPS.SendKeys("S", 5, 2);
            apiChka();
            Emulsessiona.autECLPS.SendKeys("[pf9]");
            apiChka();

            Enrollment_Screen();
            apiChka();

            if (Emulsessiona.autECLPS.GetText(17, 7, 1).trim() == "P") {
                Emulsessiona.autECLPS.SendKeys(PCPAgrmntIDs[cnt], 11, 23);//entering the PCP Agreement ID value

            }
            apiChka();

        }

        Emulsessiona.autECLPS.SendKeys("[pf9]");
        apiChka();

        //F9 KEY NOT AVAILABLE FOR THIS ORG TYPE

        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("F9 KEY NOT AVAILABLE") > 0) {
            apiChka();
            MacroOutput = MacroOutput + "\n" + "LOBs not added due to Error message F9 key not available for this Org Type. "
            Emulsessiona.autECLPS.SendKeys("[pf3]");
            apiChka();
            return;
        }

        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("INSTANCE AP DOES NOT EXIST FOR THIS LOB") > 0) {
            apiChka();
        }

        Emulsessiona.autECLPS.SendKeys("S", 5, 2);
        apiChka();

        Emulsessiona.autECLPS.SendKeys("[pf9]");
        apiChka();

        //changing the Directory indicator to Y before hitting enter and moving to Next available LOB

        Emulsessiona.autECLPS.SendKeys("Y", 13, 70);
        apiChka();
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();

        if (Emulsessiona.autECLPS.GetText(8, 2, 3) == LOBs(cnt)) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
        }

        //Duplicate Contract Exists

        if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("DUPLICATE") > 0) {
            apiChka();

        }

        BSAR4Screen_NewAddressOnly();

        if (cnt < LOBs) {
            Emulsessiona.autECLPS.SendKeys("[pf10]");
            apiChka();
        }

    }

    LOBInfo_Screen = true;

}

function Enrollment_Screen() {

    Emulsessiona.autECLPS.SendKeys("[pf6]");
    apiChka();

    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("DUPLICATE") >= 0) {
        //alert("DUPLICATE LOB" )
        MacroOutput = MacroOutput + "\n" + LOBs[cnt] + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim() + " in BSAR4 screen";
        Emulsessiona.autECLPS.SendKeys("[pf3]");
        apiChka();
        return;
    }
    
    Emulsessiona.autECLPS.SendKeys(ACCPT_PAT, 15, 20);
    Emulsessiona.autECLPS.SendKeys(ACCPT_GENDER_CD, 15, 54);
    Emulsessiona.autECLPS.SendKeys(ACCPT_MIN_AGE, 16, 25);
    Emulsessiona.autECLPS.SendKeys(ACCPT_MAX_AGE, 16, 52);
    Emulsessiona.autECLPS.SendKeys(ACCPT_EXISTING_PT, 17, 29);
    Emulsessiona.autECLPS.SendKeys(ENROLLMENT_LIMITS, 17, 55);

    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    //Error handling for Enrollment Rules passed editing
    if (Emulsessiona.autECLPS.GetText(24, 1, 70).trim().indexOf("ENROLLMENT RULES PASSED EDITS") < 0) {
        MacroOutput = MacroOutput + "\n" + "Enrollment Rules window error - " + Emulsessiona.autECLPS.GetText(24, 1, 70).trim();
        return;
    }

    Emulsessiona.autECLPS.SendKeys("[pf6]");
    apiChka();

}

function BSAR4Screen_NewAddressOnly() {

    apiChka();

    if (Emulsessiona.autECLPS.GetText(4, 5, 30).trim().indexOf("NAME/BILL TO PLSV") >= 0) {

        MacroOutput = MacroOutput + "\n" + "Bus Seg Selection Screen not opened in time. Macro has stopped. ";
        return;
    }

    Scrn4_B = parseInt(Emulsessiona.autECLPS.GetText(1, 69, 4).trim());
    Scrn4_E = parseInt(Emulsessiona.autECLPS.GetText(1, 77, 4).trim());
    Scrn4_Loop = Scrn4_E - Scrn4_B;

    for (var Loop4 in Scrn4_Loop) {

        do {

            for (var cnt4L = 7; cnt4L < 15; cnt4L += 7) {

                if (Emulsessiona.autECLPS.GetText(cnt4L, 2, 1).trim() == "S" && Emulsessiona.autECLPS.GetText(cnt4L, 5, 5).trim() != "") {

                    ID1 = Emulsessiona.autECLPS.GetText(cnt4L + 1, 38, 9);
                    ID2 = Emulsessiona.autECLPS.GetText(cnt4L + 1, 38, 9);

                    if (AddMA_ID_new + "|".indexOf(ID1) == 0 && AddMA_ID_new + "|".indexOf(ID2) == 0) {
                        apiChka();
                        Emulsessiona.autECLPS.Sendkeys(" ", cnt4L, 2);
                        apiChka();

                    }

                }

            }

            Emulsessiona.autECLPS.Sendkeys("[pf8]");
            apiChka();
        } while (Emulsessiona.autECLPS.GetText(24, 2, 20).trim().indexOf("NO MORE PAGES") < 0);

    }

}

function Clear_Hours() {

    Emulsession.autECLPS.SendKeys("[home]");
    apiChka();

    var pc = Emulsession.autECLPS.cursorposcol;
    var pr = Emulsession.autECLPS.cursorposrow;




    if (pc == 45 && pr == 4) {
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");

    }

    pc = Emulsession.autECLPS.cursorposcol;
    pr = Emulsession.autECLPS.cursorposrow;
    apiChka();

    if (pc == 45 && pr == 5) {
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");

    }

    pc = Emulsession.autECLPS.cursorposcol;
    pr = Emulsession.autECLPS.cursorposrow;
    apiChka();

    if (pc == 14 && pr == 6) {

        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");


    }

    pc = Emulsession.autECLPS.cursorposcol;
    pr = Emulsession.autECLPS.cursorposrow;
    apiChka();

    if (pc == 13 && pr == 7) {

        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");


    }

    pc = Emulsession.autECLPS.cursorposcol;
    pr = Emulsession.autECLPS.cursorposrow;
    apiChka();

    if (pc == 45 && pr == 8) {


        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");


    }

    pc = Emulsession.autECLPS.cursorposcol;
    pr = Emulsession.autECLPS.cursorposrow;
    apiChka();

    if (pc == 12 && pr == 9) {


        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");

    }
    pc = Emulsession.autECLPS.cursorposcol;
    pr = Emulsession.autECLPS.cursorposrow;
    apiChka();

    if (pc == 45 && pr == 10) {


        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");
        Emulsession.autECLPS.SendKeys("[erase eof]");
        Emulsession.autECLPS.SendKeys("[TAB]");


    }

}


function GetBillingMABAID() {
    var GetBillingMABAID = "";
    if (BA_ID_DB == "") {

        do {

            for (ctr = 7; ctr <= 17; ctr += 3) {
                if (Emulsessiona.autECLPS.GetText(ctr + 1, 36, 9).trim() == AddMA_ID_new) {
                    return Emulsessiona.autECLPS.GetText(ctr + 1, 36, 14).trim();
                }                
            }

            Emulsessiona.autECLPS.Sendkeys("[pf8]");
            apiChka();
        } while (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("THIS IS THE LAST PAGE") < 0);
        
    } else {

        do {
            for (ctr = 7; ctr <= 17; ctr += 3) {
                if (Emulsessiona.autECLPS.GetText(ctr, 38, 1).trim() == "B" || Emulsessiona.autECLPS.GetText(ctr, 38, 1).trim() == "C") {
                    if (Emulsessiona.autECLPS.GetText(ctr + 1, 36, 9).trim() == BA_ID_DB) {
                        return Emulsessiona.autECLPS.GetText(ctr + 1, 36, 14).trim();
                    }
                }
            }
            Emulsessiona.autECLPS.Sendkeys("[pf8]");
            apiChka();
        } while (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("THIS IS THE LAST PAGE") < 0); 

    }
    
}

var addcheck;
function Check_Address_LoadedOrNot() {
    addcheck = false;

    Emulsessiona.autECLPS.SendKeys("[pf3]");
    apiChka();

    Emulsessiona.autECLPS.SendKeys("I", 21,8);
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(Ma_ID, 21, 47);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();

    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
    apiChka();
    
    if (Emulsessiona.autECLPS.gettext(24, 2, 20).trim().indexOf("NO DATA") >= 0) {        
        addcheck = false;
        
    } else if (Emulsessiona.autECLPS.gettext(7, 5, 20).trim() != "") {
        addcheck = true;
        var TYP = Emulsessiona.autECLPS.gettext(7, 38, 11).trim().split("-")[0];
        apiChka();

        Emulsessiona.autECLPS.SendKeys("1",19,13);
        apiChka();
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();

        Emulsessiona.autECLPS.SendKeys("A", 21, 15);
        apiChka();
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();
        
        if (Emulsessiona.autECLPS.gettext(14, 41, 2).trim() != "") {
           
            MacroOutput = "Address is already loaded as - " + TYP + " - Not active";
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            apiChka();
            
        } else {
            
            MacroOutput = "Address is already loaded as - " + TYP + " - Active";
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            apiChka();
        }
        
    }
    
}

function getPrimaryPLSV() {

    Emulsessiona.autECLPS.Sendkeys("[pf4]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();


    do {
        for (ctr = 7; ctr <= 17; ctr += 3) {
            if (Emulsessiona.autECLPS.GetText(ctr, 38, 4).trim() == "PLSV") {
                if (Emulsessiona.autECLPS.GetText(ctr, 38, 11).trim().split("-")[1] == "P") {
                    paid = Emulsessiona.autECLPS.GetText(ctr + 1, 48, 2).trim();
                    return;
                }                
            }
        }
        Emulsessiona.autECLPS.Sendkeys("[pf8]");
        apiChka();
    } while (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("THIS IS THE LAST PAGE") < 0);    
}

function  BSAR_UPDATION() {
    
    if (addAddress != true) {
        return;
    }

    if (ADDRESS_TYPE == "CRED") {
        return;
    } else if (ADDRESS_TYPE == "MAIL") {
        return;
    }
    
    apiChka();
    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");

    Emulsessiona.autECLPS.SendKeys("[erase eof]", 21, 31);
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();    
    Emulsessiona.autECLPS.SendKeys("[erase eof]", 23, 37);
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();

    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    Emulsessiona.autECLPS.Sendkeys("1", 19, 13);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();


    Emulsessiona.autECLPS.Sendkeys("I", 21, 8);
    Emulsessiona.autECLPS.Sendkeys("T", 21, 15);
    Emulsessiona.autECLPS.Sendkeys("[enter]");
    apiChka();
    
    apiChka();
    CorpName = Emulsessiona.autECLPS.GetText(15, 36, 40);
    PTiName = Emulsessiona.autECLPS.GetText(17, 43, 30);

    Emulsessiona.autECLPS.Sendkeys("7", 21, 15);
    Emulsessiona.autECLPS.Sendkeys("[enter]");
    apiChka();

    if (CHECK_NAME_BSAR == "" && Emulsessiona.autECLPS.GetText(7, 6, 5).trim() == "") {
        Emulsessiona.autECLPS.Sendkeys("[pf4]");
        apiChka();
        return;
    }
    
    Emulsessiona.autECLPS.Sendkeys("A", 21, 8);
    Emulsessiona.autECLPS.Sendkeys("[enter]");
    apiChka();


    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("RECORDS OVER?") > 0) {
        Emulsessiona.autECLPS.Sendkeys("Y");
        apiChka();
        Emulsessiona.autECLPS.Sendkeys("[enter]");
        apiChka();
        
        Emulsessiona.autECLPS.SendKeys("[erase eof]", 6, 40);
        Emulsessiona.autECLPS.SendKeys(CorpName, 6, 40);
        Emulsessiona.autECLPS.SendKeys(GROUP_NAME, 10, 40);
        apiChka();

        Emulsessiona.autECLPS.SendKeys("AP", 18, 3);

        BSAR7MAID_Array.push(Emulsessiona.autECLPS.GetText(10, 14, 12).trim());

        Emulsessiona.autECLPS.SendKeys("I", 21, 8);
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();

        if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("ADDRESS RELATIONSHIP ALREADY EXISTS FOR") >= 0) {
            BSAR7MAID_Array.splice(BSAR7MAID_Array.length - 1);
        }
        
        //Check for NEW CHK NM WILL APPLY TO ALL ADDR string after doing Fun: I enter
        if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("NEW CHK NM WILL APPLY TO ALL ADDR") >= 0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
        }
        
        if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("UPDATES SUCCESSFUL") >= 0) {
            do {
                Emulsessiona.autECLPS.SendKeys("AP", 18, 3);
                Emulsessiona.autECLPS.SendKeys(GROUP_NAME, 10, 40);
                apiChka();
                BSAR7MAID_Array.push(Emulsessiona.autECLPS.GetText(10, 14, 12).trim());
                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
                if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("NEW CHK NM WILL APPLY TO ALL ADDR RELAT") >= 0) {
                    Emulsessiona.autECLPS.SendKeys("[enter]");
                    apiChka();
                }

            } while (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("UPDATES SUCCESSFUL") >= 0)

        }

        if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim() != "") {
            
            if (CorpName.indexOf(Emulsessiona.autECLPS.GetText(24, 2, 70).trim()) >= 0) {
                do {
                    Emulsessiona.autECLPS.SendKeys("AP", 18, 3);
                    Emulsessiona.autECLPS.SendKeys(GROUP_NAME, 10, 40);
                    apiChka();
                    BSAR7MAID_Array.push(Emulsessiona.autECLPS.GetText(10, 14, 12).trim());
                    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                    Emulsessiona.autECLPS.SendKeys("[enter]");
                    apiChka();

                    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("NEW CHK NM WILL APPLY TO ALL ADDR RELAT") >= 0) {
                        Emulsessiona.autECLPS.SendKeys("[enter]");
                        apiChka();
                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim() == "") {
                        break;
                    }

                } while (CorpName.indexOf(Emulsessiona.autECLPS.GetText(24, 2, 70).trim()) >= 0 || Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("UPDATES SUCCESSFUL") >= 0);

            }
        }

        if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("PHY ADDED, GROUP BSAR ALREADY EXISTS") >= 0) {
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();

            if (Emulsessiona.autECLPS.GetText(4, 3, 5).trim().indexOf("NAME:") >= 0 && Emulsessiona.autECLPS.GetText(24, 2, 70).trim() == "") {

                do {
                    Emulsessiona.autECLPS.SendKeys("AP", 18, 3);
                    Emulsessiona.autECLPS.SendKeys(GROUP_NAME, 10, 40);
                    apiChka();
                    BSAR7MAID_Array.push(Emulsessiona.autECLPS.GetText(10, 14, 12).trim());
                    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                    Emulsessiona.autECLPS.SendKeys("[enter]");
                    apiChka();

                    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("NEW CHK NM WILL APPLY TO ALL ADDR RELAT") >= 0) {
                        Emulsessiona.autECLPS.SendKeys("[enter]");
                        apiChka();
                    }
                    
                    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim() == "") {
                        break;
                    }

                } while (Emulsessiona.autECLPS.GetText(4, 3, 5).trim().indexOf("NAME:") >= 0 && Emulsessiona.autECLPS.GetText(24, 2, 70).trim() == "");
            }            
        }
        
        if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("ADD SAID ADDRESS TO GROUP") > 0) {        

            if (Emulsessiona.autECLPS.GetText(10,15,9).trim() == AddMA_ID_new   ) {

                MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 70).trim();
                Emulsessiona.autECLPS.SendKeys("[pf4]");
                return;
            } else {

                do {
                    if (Emulsessiona.autECLPS.GetText(10, 15, 9).trim() != AddMA_ID_new) {
                        
                        Emulsessiona.autECLPS.SendKeys("[pf6]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(4, 2, 40).trim().indexOf("NAME/BILL TO PLSV") > 0) {
                            break;
                        }

                        Emulsessiona.autECLPS.SendKeys("AP", 18, 3);
                        Emulsessiona.autECLPS.SendKeys(GROUP_NAME, 10, 40);
                        apiChka();
                        BSAR7MAID_Array.push(Emulsessiona.autECLPS.GetText(10, 14, 12).trim());
                        Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                        Emulsessiona.autECLPS.SendKeys("[enter]");
                        apiChka();

                        if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("NEW CHK NM WILL APPLY TO ALL ADDR RELAT") >= 0) {
                            Emulsessiona.autECLPS.SendKeys("[enter]");
                            apiChka();
                        }
                        
                    } else {
                        MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 70).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf4]");
                        return;
                    }
                    
                } while (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("ADD SAID ADDRESS TO GROUP") >= 0 || Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("UPDATES SUCCESSFUL") >= 0);
                
            }            
        }

        if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("ADDRESS RELATIONSHIP ALREADY EXISTS FOR") >= 0) {

            do {
                Emulsessiona.autECLPS.SendKeys("[pf6]");
                apiChka();
                Emulsessiona.autECLPS.SendKeys("AP", 18, 3);
                Emulsessiona.autECLPS.SendKeys(GROUP_NAME, 10, 40);
                apiChka();
                BSAR7MAID_Array.push(Emulsessiona.autECLPS.GetText(10, 14, 12).trim());
                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();

                if (Emulsessiona.autECLPS.GetText(4, 3, 5).trim().indexOf("NAME:") >= 0) {
                    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim() != "UPDATES SUCCESSFUL") {
                        BSAR7MAID_Array.splice(BSAR7MAID_Array.length - 1);
                    }
                }
                
                if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("NEW CHK NM WILL APPLY TO ALL ADDR RELAT") >= 0){
                    Emulsessiona.autECLPS.SendKeys("[enter]");
                    apiChka();
                }
                
            } while (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("ADDRESS RELATIONSHIP ALREADY EXISTS FOR") >= 0 || Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("UPDATES SUCCESSFUL") >= 0);
        }

        //Error handling for GROUP BSAR DOES NOT EXIST

        if (Emulsessiona.autECLPS.GetText(24, 2, 60).trim().indexOf("GROUP BSAR DOES NOT EXIST") >= 0) {
            apiChka();
            GroupMPIN = "";
            GroupBSAR();
            apiChka();
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
        }

        //Error handling for GROUP MPIN XXXXXXX, MUST ADD INSTANCE AP
        if (Emulsessiona.autECLPS.GetText(24, 2, 60).trim().indexOf("FOR GROUP MPIN") >= 0) {
            apiChka();
            GroupMPIN = "";
        }
       
        //Error handling for Contract Already exists for this MPIN/TIN
        if (Emulsessiona.autECLPS.GetText(19, 3, 35).trim().indexOf("CONTRACT EXISTS FOR THIS MPIN") > 0 && Emulsessiona.autECLPS.GetText(19, 57, 14).trim().indexOf("ADD CONTR") > 0) {
            if (Emulsessiona.autECLPS.GetText(18, 3, 2).trim().indexOf("AP") > 0) {
                if (Emulsessiona.autECLPS.GetText(24, 2, 20).trim().indexOf("UPDATES SUCCESS") > 0) {
                    if (Emulsessiona.autECLPS.GetText(19, 57, 20).trim().indexOf("Y/N:") > 0) {
                        if (Emulsessiona.autECLPS.GetText(24, 2, 20).trim() == "" || Emulsessiona.autECLPS.GetText(24, 2, 20).trim() != "") {
                            Emulsessiona.autECLPS.SendKeys("N", 19, 76);
                            apiChka();
                            Emulsessiona.autECLPS.SendKeys("[enter]");
                            apiChka();
                        }
                    }
                }
            }
        }
        //PHY BSAR NOT ADDED, ADD BAID ADDRESS TO GROUP
        if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("PHY BSAR NOT ADDED, ADD BAID ADDRESS TO GROUP") >= 0) {
            apiChka();
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 70).trim();
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            apiChka();
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            apiChka();
            return;
        }
        
        if (Emulsessiona.autECLPS.GetText(4, 2, 40).trim().indexOf("NAME/BILL TO PLSV") > 0) {
            apiChka();
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            apiChka();
            Emulsessiona.autECLPS.SendKeys("[pf4]");
            apiChka();      
            MacroOutput = MacroOutput + "\n" + "BSAR 7 screen has been updated";
        }        
    }
    
    if (LOB != "") {

        Emulsessiona.autECLPS.SendKeys("[pf3]");
        apiChka();   
        Emulsessiona.autECLPS.Sendkeys("A", 21, 8);
        Emulsessiona.autECLPS.Sendkeys("4");
        Emulsessiona.autECLPS.Sendkeys("Z");

        Emulsessiona.autECLPS.SendKeys("[erase eof]", 21, 31);
        Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
        apiChka();
        Emulsessiona.autECLPS.SendKeys("[erase eof]", 23, 37);
        Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
        apiChka();
        
        Emulsessiona.autECLPS.Sendkeys("[enter]");
        apiChka();
        Emulsessiona.autECLPS.Sendkeys("1",19,13);
        Emulsessiona.autECLPS.Sendkeys("[enter]");
        apiChka();
        
        bsar4Loop()
        
        Emulsessiona.autECLPS.SendKeys(slcode, 19, 13);
        apiChka();
        Emulsessiona.autECLPS.Sendkeys("[enter]");
        apiChka();
        apiChka();
        slcode = "";
        
        if (Emulsessiona.autECLPS.GetText(7, 2, 3).trim() != "LOB") {
            apiChka();
            //MacroOutput = MacroOutput + "\n" + "LOB screen not found in BSAR 4";
            Emulsessiona.autECLPS.Sendkeys("[pf4]");
            return;
        } else {

            LOBs = LOB.split(",");
            AgrmntIDs = AGREEMENT_ID_BSAR.split(",");
            PCPAgrmntIDs = PCP_AGREEMENT_NROW_ID_BSAR.split(",");
            IPAIDs = IPA_ID.split(",");

            for (var cnt in LOBs) {

                if (Emulsessiona.autECLPS.GetText(7, 2, 3).trim() != "LOB") {

                    bsar4Loop()
                    Emulsessiona.autECLPS.SendKeys(slcode, 19, 13);
                    apiChka();
                    Emulsessiona.autECLPS.Sendkeys("[enter]");
                    apiChka();
                    apiChka();
                    slcode = "";
                }

                Emulsessiona.autECLPS.SendKeys(LOBs[cnt], 8, 2) //'entering the LOB value

                if (IPA_ID != "") {
                    if (IPAIDs[cnt] != "" && IPAIDs[cnt] != "NA") {
                        Emulsessiona.autECLPS.SendKeys(IPAIDs[cnt], 9, 9);
                    }
                }

                Emulsessiona.autECLPS.SendKeys('[erase eof]', 10, 17)
                apiChka();
                Emulsessiona.autECLPS.SendKeys(AgrmntIDs[cnt], 10, 17);
                apiChka();

                if (Emulsessiona.autECLPS.GetText(11, 23, 10).trim() != "") {
                    Emulsessiona.autECLPS.SendKeys(PCPAgrmntIDs[cnt], 11, 23);//entering the PCP Agreement ID value
                    apiChka();
                }
                
                EFF_DATE_BSAR = EFF_DATE_BSAR.replace(" ", ""); EFF_DATE_BSAR = EFF_DATE_BSAR.replace(" ", "");

                Emulsessiona.autECLPS.SendKeys(EFF_DATE_BSAR.slice(0, 2), 12, 12);
                Emulsessiona.autECLPS.SendKeys(EFF_DATE_BSAR.substring(4, 2), 12, 15);
                Emulsessiona.autECLPS.SendKeys(EFF_DATE_BSAR.substring(8, 4), 12, 18);
                apiChka();
                Emulsessiona.autECLPS.SendKeys(PCP_BSAR, 17, 7); //'entering PCP Field
                apiChka();


                //in case of PCP indicator as P - we need to fill in Enrollment Screen as well which will be F6 Screen
                if (PCP_BSAR.toUpperCase() == "P") {
                    apiChka();

                    Emulsessiona.autECLPS.SendKeys("[enter]");
                    apiChka();

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("USE PF9") > 0) {
                        Emulsessiona.autECLPS.SendKeys("[pf9]");
                        apiChka();

                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("NO SPECIALTIES FOUND FOR THIS PROVIDER") >= 0) {
                        MacroOutput = MacroOutput + "\n" + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf10]");
                        apiChka();
                        Emulsessiona.autECLPS.SendKeys("[pf4]");
                        apiChka();
                        return;
                    }
                    
                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("DUPLICATE") >= 0) {
                        //alert("DUPLICATE LOB" )
                        MacroOutput = MacroOutput + "\n" + LOBs[cnt] + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();    

                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }

                    }
                    
                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("LINE OF BUSINESS INVALID") >= 0) {
                        //alert("DUPLICATE LOB" )
                        MacroOutput = MacroOutput + "\n" + LOBs[cnt] + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("AGREEMENT ID IS NOT VALID FOR  LOB TYPE") >= 0) {
                        //alert("DUPLICATE LOB" )
                        MacroOutput = MacroOutput + "\n" + LOBs[cnt] + "-" + Emulsessiona.autECLPS.GetText(24, 2, 70).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("F9 KEY NOT AVAILABLE") >= 0) {
                        apiChka();
                        MacroOutput = MacroOutput + "\n" + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("INSTANCE AP DOES NOT EXIST FOR THIS LOB") >= 0) {
                        MacroOutput = MacroOutput + "\n" + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("INVALID AGREEMENT ID") >= 0) {
                        MacroOutput = MacroOutput + "\n" + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("AGREEMENT ID IS REQUIRED") >= 0) {
                        MacroOutput = MacroOutput + "\n" + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }




                    if (Emulsessiona.autECLPS.GetText(4, 2, 3).trim() == "SEL") {
                        FacilityCD = FacilityCode.split(",");
                        var ctr = 0;

                        for (var z in FacilityCD) {
                            
                            if (FacilityCD[z].slice(0, 3).trim().length < 2) {
                                FacilityCD[z] = "00" + FacilityCD[z];
                            }
                            else if (FacilityCD[z].slice(0, 3).trim().length < 3) {
                                FacilityCD[z] = "0" + FacilityCD[z];
                            }
                            
                            do {

                                for (var i = 5; i < 16; i += 5) {
                                    
                                    if (Emulsessiona.autECLPS.GetText(i, 19, 3).trim() == FacilityCD[z]) {

                                        Emulsessiona.autECLPS.SendKeys("S", i, 2);
                                        apiChka();
                                        //Emulsessiona.autECLPS.SendKeys("[pf9]");
                                        apiChka();
                                        chkfecode = true;
                                        //if (Emulsessiona.autECLPS.GetText(7, 2, 3).trim() == "LOB") {
                                        //    MacroOutput = MacroOutput + "\n" + LOBs[cnt] + " - LOB has been updated";
                                        //}
                                        break;
                                    }
                                }

                                if (chkfecode == true) {
                                    break;
                                }

                                Emulsessiona.autECLPS.SendKeys("[pf8]");
                                apiChka();

                            } while (Emulsessiona.autECLPS.GetText(24, 2, 60).trim().indexOf("LAST PAGE") < 0);
                        }

                        Emulsessiona.autECLPS.SendKeys("[pf9]");
                    }

                    if (Emulsessiona.autECLPS.GetText(4, 2, 40).trim().indexOf("NAME/BILL TO PLSV") < 0) {
                        Emulsessiona.autECLPS.SendKeys("[enter]");
                        apiChka();
                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("USE F6") >= 0) {

                        Enrollment_Screen();
                        apiChka();
                    }
                    
                    if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                        pf3page()
                        continue;
                    }
                    
                    if (Emulsessiona.autECLPS.GetText(17, 7, 1).trim() == "P") {
                        Emulsessiona.autECLPS.SendKeys(PCPAgrmntIDs[cnt], 11, 23);//entering the PCP Agreement ID value
                        apiChka();
                    }          

                    if (Emulsessiona.autECLPS.GetText(7, 2, 3).trim() == "LOB") {

                        Emulsessiona.autECLPS.SendKeys("Y", 13, 70);
                        apiChka();
                        Emulsessiona.autECLPS.SendKeys("[enter]");
                        apiChka();
                    }

                    if (Emulsessiona.autECLPS.GetText(8, 2, 3) == LOBs[cnt]) {
                        Emulsessiona.autECLPS.SendKeys("[enter]");
                        apiChka();
                    }
                    
                    if (cnt < LOBs.length - 1) {
                        if (Emulsessiona.autECLPS.GetText(4, 2, 40).trim().indexOf("NAME/BILL TO PLSV") >= 0) {
                            apiChka();
                            MacroOutput = MacroOutput + "\n" + LOBs[cnt] + " - LOB has been updated";
                            apiChka();
                        }
                        Emulsessiona.autECLPS.SendKeys("[pf10]");
                        apiChka();
                    }

                    if (cnt == LOBs.length - 1) {
                        apiChka();
                        MacroOutput = MacroOutput + "\n" + LOBs[cnt] + " - LOB has been updated";
                        Emulsessiona.autECLPS.SendKeys("[pf11]");
                        apiChka();
                    }
                    
                }
                
                if (PCP_BSAR.toUpperCase() == "S") {
                    //enter
                    //A MINIMUM OF ONE SPECIALTY IS REQUIRED, USE PF9
                    Emulsessiona.autECLPS.SendKeys("[enter]");
                    apiChka();

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("USE PF9") > 0) {
                        Emulsessiona.autECLPS.SendKeys("[pf9]");
                        apiChka();

                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("NO SPECIALTIES FOUND FOR THIS PROVIDER") >= 0) {
                        MacroOutput = MacroOutput + "\n" + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf10]");
                        apiChka();
                        Emulsessiona.autECLPS.SendKeys("[pf4]");
                        apiChka();
                        return;
                    }
                    
                    //F9 KEY NOT AVAILABLE FOR THIS ORG TYPE
                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("LINE OF BUSINESS INVALID") >= 0) {
                        //alert("DUPLICATE LOB" )
                        MacroOutput = MacroOutput + "\n" + LOBs[cnt] + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("AGREEMENT ID IS NOT VALID FOR  LOB TYPE") >= 0) {
                        //alert("DUPLICATE LOB" )
                        MacroOutput = MacroOutput + "\n" + LOBs[cnt] + "-" + Emulsessiona.autECLPS.GetText(24, 2, 70).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("DUPLICATE") >= 0) {
                        //alert("DUPLICATE LOB" )
                        MacroOutput = MacroOutput + "\n" + LOBs[cnt] + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("F9 KEY NOT AVAILABLE") >= 0) {
                        apiChka();
                        MacroOutput = MacroOutput + "\n" + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("INSTANCE AP DOES NOT EXIST FOR THIS LOB") >= 0) {
                        MacroOutput = MacroOutput + "\n" + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("INVALID AGREEMENT ID") >= 0) {
                        MacroOutput = MacroOutput + "\n" + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("AGREEMENT ID IS REQUIRED") >= 0) {
                        MacroOutput = MacroOutput + "\n" + "-" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }


                    if (Emulsessiona.autECLPS.GetText(4, 2, 3).trim() == "SEL") {
                        FacilityCD = FacilityCode.split(",");
                        var ctr = 0;

                        for (var z in FacilityCD) {

                            if (FacilityCD[z].slice(0, 3).trim().length < 2) {
                                FacilityCD[z] = "00" + FacilityCD[z];
                            }
                            else if (FacilityCD[z].slice(0, 3).trim().length < 3) {
                                FacilityCD[z] = "0" + FacilityCD[z];
                            }

                            do {

                                for (var i = 5; i < 16; i += 5) {

                                    if (Emulsessiona.autECLPS.GetText(i, 19, 3).trim() == FacilityCD[z]) {

                                        Emulsessiona.autECLPS.SendKeys("S", i, 2);
                                        apiChka();
                                        //Emulsessiona.autECLPS.SendKeys("[pf9]");
                                        apiChka();
                                        chkfecode = true;
                                        //if (Emulsessiona.autECLPS.GetText(7, 2, 3).trim() == "LOB") {
                                        //    MacroOutput = MacroOutput + "\n" + LOBs[cnt] + " - LOB has been updated";
                                        //}
                                        break;
                                    }
                                }

                                if (chkfecode == true) {
                                    break;
                                }

                                Emulsessiona.autECLPS.SendKeys("[pf8]");
                                apiChka();

                            } while (Emulsessiona.autECLPS.GetText(24, 2, 60).trim().indexOf("LAST PAGE") < 0);
                        }

                        Emulsessiona.autECLPS.SendKeys("[pf9]");
                    }
                    
                    //error
                    //AGREEMENT ID IS NOT VALID FOR  LOB TYPE

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("INACTIVE SPEC CANNOT BE SELECTED") >= 0) {
                        MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }


                    //changing the Directory indicator to Y before hitting enter and moving to Next available LOB

                    if (Emulsessiona.autECLPS.GetText(7, 2, 3).trim() == "LOB") {

                        Emulsessiona.autECLPS.SendKeys("Y", 13, 70);
                        apiChka();
                        Emulsessiona.autECLPS.SendKeys("[enter]");
                        apiChka();
                    }

                    if (Emulsessiona.autECLPS.GetText(8, 2, 3) == LOBs[cnt]) {
                        Emulsessiona.autECLPS.SendKeys("[enter]");
                        apiChka();
                    }

                    //Duplicate Contract Exists

                    if (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("DUPLICATE") >= 0) {
                        MacroOutput = MacroOutput + "\n" + LOBs[cnt] + Emulsessiona.autECLPS.GetText(24, 2, 50).trim();
                        Emulsessiona.autECLPS.SendKeys("[pf3]");
                        apiChka();
                        if (Emulsessiona.autECLPS.GetText(2, 4, 20).trim().indexOf("FUNCTIONS") >= 0) {
                            pf3page()
                            continue;
                        }
                    }

                    //BSAR4Screen_NewAddressOnly();

                    if (cnt < LOBs.length - 1) {                        
                        MacroOutput = MacroOutput + "\n" + LOBs[cnt] + " - LOB has been updated";                                                
                        Emulsessiona.autECLPS.SendKeys("[pf10]");
                        apiChka();
                    }

                    if (cnt == LOBs.length - 1) {
                        MacroOutput = MacroOutput + "\n" + LOBs[cnt] + " - LOB has been updated"; 
                        Emulsessiona.autECLPS.SendKeys("[pf11]");
                        apiChka();
                    }
                }
            }
        } 
        
    }    

    if (PCP_IND == "P" && CapCode != "" && BSAR7MAID_Array != "") {
        Capcode_Updation()
    }
    
}

function loop() {

    do {
        for (cnt = 8; cnt < 18; cnt++) {

            if (Emulsessiona.autECLPS.GetText(cnt, 7, 4).trim() == BAID) {
                selectionCode = Emulsessiona.autECLPS.GetText(cnt, 2, 3).trim();                
                apiChka(); //inserting a short delay 
                return;
            }
        }
           
        Emulsessiona.autECLPS.SendKeys("[PF8]");
        apiChka();

        if (Emulsessiona.autECLPS.GetText(1, 70, 3).trim() == Emulsessiona.autECLPS.GetText(1, 77, 3).trim() && Emulsessiona.autECLPS.GetText(1, 70, 3).trim() != "1") {

            for (cnt = 8; cnt < 18; cnt++) {

                if (Emulsessiona.autECLPS.GetText(cnt, 7, 4).trim() == BAID) {
                    selectionCode = Emulsessiona.autECLPS.GetText(cnt, 2, 3).trim();
                    apiChka(); //inserting a short delay 
                    return;
                }
            }

        }

    } while (Emulsessiona.autECLPS.GetText(24, 1, 60).indexOf("LAST PAGE") <= 0)

}
var TYP;
var update;
function Check_Address_asMAILCRED() {
    addcheck = false;
    update = false;

    if (Emulsessiona.autECLPS.GetText(3, 30, 20).trim().indexOf("-- AREA MENU") < 0) {
        Emulsessiona.autECLPS.Sendkeys("[pf2]");
        apiChka();
    }

    Emulsessiona.autECLPS.SendKeys("Z", 21, 22);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    Emulsessiona.autECLPS.SendKeys("I");
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(Ma_ID, 21, 47);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();

    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
    apiChka();

    if (Emulsessiona.autECLPS.gettext(24, 2, 20).trim().indexOf("NO DATA") >= 0) {
        addcheck = true;
    } else if (Emulsessiona.autECLPS.gettext(7, 5, 20).trim() != "") {
        TYP = Emulsessiona.autECLPS.gettext(7, 38, 11).trim().split("-")[0];
        Update_corresAS_S();

    }
    
}

function Update_corresAS_S() {
    
    Emulsessiona.autECLPS.sendkeys("1");
    Emulsessiona.autECLPS.sendkeys("[enter]");
    apiChka();

    Emulsessiona.autECLPS.sendkeys("A", 21, 15);
    Emulsessiona.autECLPS.sendkeys("[enter]");
    apiChka();
    Emulsessiona.autECLPS.sendkeys("C", 21, 8);
    Emulsessiona.autECLPS.sendkeys("[enter]");
    apiChka();

    Emulsessiona.autECLPS.sendkeys("P", 11, 80);
    apiChka();

    Emulsessiona.autECLPS.sendkeys("I", 21, 8);
    Emulsessiona.autECLPS.sendkeys("[enter]");
    apiChka();
    update = true;

    MacroOutput = MacroOutput + "\n" + "ADDRESS IS ALREADY LOADED AS - " + TYP + " AND CORRESPONDENCE TYPE IS UPDATED AS 'P'";
    
}

function IHA_CREDENTIAL_CATEGORY() {

    if (addAddress != true) {
        return;
    }

    
    if (HOSPITAL_MPIN != "") {

        Emulsessiona.autECLPS.SendKeys("[pf3]");
        apiChka();
        Emulsessiona.autECLPS.SendKeys("I", 21,8);
        Emulsessiona.autECLPS.SendKeys("H");
        Emulsessiona.autECLPS.SendKeys("A");
        apiChka();
        Emulsessiona.autECLPS.SendKeys(MPIN, 21,31);
        apiChka();
        Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
        apiChka();
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();

        Emulsessiona.autECLPS.SendKeys("1", 19, 13);
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();

        Emulsessiona.autECLPS.SendKeys("A", 21, 8);
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();

        if (Emulsessiona.autECLPS.gettext(2, 22, 40).trim().indexOf("AFFILIATIONS") >= 0) {

            Emulsessiona.autECLPS.SendKeys(HOSPITAL_MPIN, 19, 30);
            Emulsessiona.autECLPS.SendKeys(PS_Hospital, 19, 45);
            Emulsessiona.autECLPS.SendKeys(AP, 19, 51);
            Emulsessiona.autECLPS.SendKeys(DIR, 19, 60);
            Emulsessiona.autECLPS.SendKeys("I", 21, 8);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            
        }

        if (Emulsessiona.autECLPS.gettext(24, 2, 70).trim().indexOf("NO AFFILIATIONS FOUND FOR THIS MPIN NUMBER") >= 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.gettext(24, 2, 70).trim() + " in IHA screen."
            Emulsessiona.autECLPS.SendKeys("[pf4]");
        } else if (Emulsessiona.autECLPS.gettext(24, 2, 70).trim().indexOf("INVALID MPIN") >= 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.gettext(24, 2, 70).trim() + " in IHA screen."
            Emulsessiona.autECLPS.SendKeys("[pf4]"); 

        } else {
            MacroOutput = MacroOutput + "\n" + "IHA credential screen has been updated"
            Emulsessiona.autECLPS.SendKeys("[pf4]");
        }
        
    }
    
}

function IFC_CREDENTIAL_CATEGORY() {

    if (addAddress != true) {
        return;
    }

    
    if (FEDERAL_DEA_NUMBER != "") {

        Emulsessiona.autECLPS.SendKeys("[pf3]");
        apiChka();
        Emulsessiona.autECLPS.SendKeys("I", 21, 8);
        Emulsessiona.autECLPS.SendKeys("F");
        Emulsessiona.autECLPS.SendKeys("C");
        apiChka();
        Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
        apiChka();

        Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
        apiChka();
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();

        Emulsessiona.autECLPS.SendKeys("1");
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();

        if (EXPIRATION_DATE_IFC != "") {
            EXPIRATION_DATE_IFC = EXPIRATION_DATE_IFC.split(" ");        
        }
        if (EFF_DATE_IFC != "") {
            EFF_DATE_IFC = EFF_DATE_IFC.split(" "); 
        }
        if (EXP_DATE_IFC != "") {
            EXP_DATE_IFC = EXP_DATE_IFC.split(" "); 
        }
        
        if (Emulsessiona.autECLPS.gettext(2, 22, 40).trim().indexOf("CREDENTIALS-") >= 0) {

            Emulsessiona.autECLPS.SendKeys("A", 21, 8);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();

            if (FEDERAL_DEA_NUMBER != "") {
                Emulsessiona.autECLPS.SendKeys(FEDERAL_DEA_NUMBER, 5, 23);
                apiChka();
            }

            if (EXPIRATION_DATE_IFC != "") {                
                Emulsessiona.autECLPS.SendKeys(EXPIRATION_DATE_IFC[0], 5, 54);
                Emulsessiona.autECLPS.SendKeys(EXPIRATION_DATE_IFC[1], 5, 57);
                Emulsessiona.autECLPS.SendKeys(EXPIRATION_DATE_IFC[2], 5, 60);
                apiChka();
            }

            if (CERT_NUMBER_IFC != "" && ST != "") {
                Emulsessiona.autECLPS.SendKeys(ST, 9, 7);
            }

            if (CERT_NUMBER_IFC != "") {
                Emulsessiona.autECLPS.SendKeys(CERT_NUMBER_IFC, 9, 25);
                apiChka();
            }
            
            if (License != "" && ST != "") {
                Emulsessiona.autECLPS.SendKeys(ST, 15, 3);
            }


            if (License != "") {
                Emulsessiona.autECLPS.SendKeys(License, 15, 8);
                apiChka();
            }
           

            if (EFF_DATE_IFC != "") {
                Emulsessiona.autECLPS.SendKeys(EFF_DATE_IFC[0], 15, 39);
                Emulsessiona.autECLPS.SendKeys(EFF_DATE_IFC[1], 15, 42);
                Emulsessiona.autECLPS.SendKeys(EFF_DATE_IFC[2], 15, 45);
                apiChka();
            }
            
            if (EXP_DATE_IFC != "") {
                Emulsessiona.autECLPS.SendKeys(EXP_DATE_IFC[0], 15, 53);
                Emulsessiona.autECLPS.SendKeys(EXP_DATE_IFC[1], 15, 56);
                Emulsessiona.autECLPS.SendKeys(EXP_DATE_IFC[2], 15, 59);
                apiChka();
            }
            
            Emulsessiona.autECLPS.SendKeys("I",21,8);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();
            
        }

        if (Emulsessiona.autECLPS.gettext(24, 2, 70).trim() != "") {
            Err = Emulsessiona.autECLPS.gettext(24, 2, 70).trim();
            MacroOutput = MacroOutput + "\n" + Err + " in IFC screen."
        } else {
            MacroOutput = MacroOutput + "\n" + " IFC credential screen has been updated";
        }        
    }    
}


function chkdate() {
    check = false;
    if (dateITC != "") {

        dateITC = dateITC.replace(" ", "/"); dateITC = dateITC.replace(" ", "/");
        EFF = EFF_DATE_Address.replace(" ", "/"); EFF = EFF.replace(" ", "/");

        var d1 = new Date(dateITC);
        var d2 = new Date(EFF);
        
        //var d1 = new Date("08/10/1984");
        //var d2 = new Date("08/10/1983");
       
        if (d1 > d2) {
            MacroOutput = MacroOutput + "\n" + "Address can not be loaded prior ORIG DEL DT"
            Emulsessiona.autECLPS.SendKeys("pf3");
            check = true;
            return;
        }
        
    }
    
}

function UpdatePAID() {

    apiChka();
    apiChka();

    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    //AddBillA_ID_new

    var MABAID1 = GetBillingMABAID_();

    MAID1 = MABAID1.split("-")[0];
    BAID1 = MABAID1.split("-")[1];

    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("U", 21, 15);
    Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
    Emulsessiona.autECLPS.SendKeys("[erase eof]", 21, 31);
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[erase eof]", 23, 37);
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("1", 19, 13);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();


    if (Emulsessiona.autECLPS.GetText(6, 2, 3) == "SEL") {
        
        COSMOS_()
        
    }
    
}

function COSMOS_() {

    do {

        for (cnt = 8; cnt < 18; cnt++) {

            if (Emulsessiona.autECLPS.GetText(cnt, 7, 4).trim() == BAID1) {
              
                selectionCode = Emulsessiona.autECLPS.GetText(cnt, 2, 3).trim();
                //billA_id = Emulsessiona.autECLPS.GetText(cnt, 7, 5).trim();

                apiChka(); //inserting a short delay

                uhcid_Updation_paid();


                apiChka(); //inserting a short delay
                selectionCode = "";
                Emulsessiona.autECLPS.SendKeys("[pf3]");
                apiChka();
                return;
            }
        }
        //+++++++page forward in case of New BillA-ID is not found on UHCID Selection Screen+++++++            
        Emulsessiona.autECLPS.SendKeys("[PF8]");

        apiChka();

        if (Emulsessiona.autECLPS.GetText(1, 70, 3).trim() == Emulsessiona.autECLPS.GetText(1, 77, 3).trim() && Emulsessiona.autECLPS.GetText(1, 70, 3).trim() != "1") {

            for (cnt = 8; cnt < 18; cnt++) {

                if (Emulsessiona.autECLPS.GetText(cnt, 7, 4).trim() == BAID1 && Emulsessiona.autECLPS.GetText(cnt, 19, 3).trim() != "" ) {

                    selectionCode = Emulsessiona.autECLPS.GetText(cnt, 2, 3).trim();

                    uhcid_Updation_paid();

                    apiChka(); //inserting a short delay
                    selectionCode = "";

                    Emulsessiona.autECLPS.SendKeys("[pf3]");
                    apiChka();
                    
                    return;
                }
            }
        }

    } while (Emulsessiona.autECLPS.GetText(24, 1, 60).indexOf("LAST PAGE") <= 0);
    
}


function GetBillingMABAID_() {

    var GetBillingMABAID_ = "";
    if (BA_ID_DB == "") {

        do {

            for (ctr = 7; ctr <= 17; ctr += 3) {
                if (Emulsessiona.autECLPS.GetText(ctr, 38, 1).trim() == "B" || Emulsessiona.autECLPS.GetText(ctr, 38, 2).trim() == "CO") {
                    return Emulsessiona.autECLPS.GetText(ctr + 1, 36, 14).trim();
                }
            }

            Emulsessiona.autECLPS.Sendkeys("[pf8]");
            apiChka();
        } while (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("THIS IS THE LAST PAGE") < 0);

    } else {

        do {
            for (ctr = 7; ctr <= 17; ctr += 3) {
                if (Emulsessiona.autECLPS.GetText(ctr, 38, 1).trim() == "B" || Emulsessiona.autECLPS.GetText(ctr, 38, 2).trim() == "CO") {
                    if (Emulsessiona.autECLPS.GetText(ctr + 1, 36, 9).trim() == BA_ID_DB) {
                        return Emulsessiona.autECLPS.GetText(ctr + 1, 36, 14).trim();
                    }
                }
            }
            Emulsessiona.autECLPS.Sendkeys("[pf8]");
            apiChka();
        } while (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("THIS IS THE LAST PAGE") < 0);

    }
    
}

var loopuhcID = "";

function uhcid_Updation_paid() {
    loopuhcID = false;

    apiChka();

    Emulsessiona.autECLPS.SendKeys("[erase eof]", 18, 13);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(selectionCode, 18, 13);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("SELECTED ADDRESS") >= 0) {            
        MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 70).trim();
        return;
    }

    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("THE SELECTION NUMBER IS NOT VALID") >= 0) {
        return;
    }
    
    replaceZero();

    if (Emulsessiona.autECLPS.GetText(2, 35, 40).trim().indexOf("COSMOS DEMOGRAPHICS") >= 0 && Emulsessiona.autECLPS.GetText(3, 6, 5).trim() != "" ) {//to check voided UHC ID DIV

        if (bd == Emulsessiona.autECLPS.GetText(2, 8, 5).trim()) {// TO CHECK DIV SELECTION CODE

            chkDiv();

            if (DivScreen == true) {
                Emulsessiona.autECLPS.SendKeys("[pf5]");
                apiChka();

                loop_UHCID();

                if (loopuhcID == true) {
                    if (MacroOutput.indexOf("UHCID Divs has been updated") < 0) {
                        MacroOutput = MacroOutput + "\n" + "UHCID Divs has been updated ";
                        return;
                    }
                }

            }

            if (Emulsessiona.autECLPS.GetText(24, 73, 6).trim() != "CHANGE") {
                Emulsessiona.autECLPS.Sendkeys("C", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }
            
            Emulsessiona.autECLPS.Sendkeys(AddBillA_ID_new, 7, 75);
            apiChka();
            Emulsessiona.autECLPS.SendKeys("I", 21, 8);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();

            if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("INVALID") >= 0) {
                Emulsessiona.autECLPS.SendKeys("[erase eof]", 8, 66);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }
            if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("INVALID") >= 0) {
                Emulsessiona.autECLPS.SendKeys("[erase eof]", 8, 70);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }
            if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("INVALID") >= 0) {
                Emulsessiona.autECLPS.SendKeys("[erase eof]", 8, 74);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }
            if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("INVALID") >= 0) {
                Emulsessiona.autECLPS.SendKeys("[erase eof]", 8, 78);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }



            if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim() == "") {
                Emulsessiona.autECLPS.SendKeys("[pf5]");
                apiChka();
            
            } else {
                MacroOutput = MacroOutput + "\n" + "DIV - " + Emulsessiona.autECLPS.GetText(3, 7, 3).trim() + " " + Emulsessiona.autECLPS.GetText(24, 2, 70).trim();
                Emulsessiona.autECLPS.SendKeys("[pf5]");
                apiChka();
            }
            
        } else {
            return;
        }
    }

    if (Emulsessiona.autECLPS.GetText(2, 34, 40).trim().indexOf("COSMOS DEMOGRAPHICS") >= 0) {
        Emulsessiona.autECLPS.SendKeys("[pf5]");
        apiChka();
    }


    loop_UHCID();



    if (loopuhcID == true) {
        if (MacroOutput.indexOf("UHCID Divs has been updated") < 0) {
            MacroOutput = MacroOutput + "\n" + "UHCID Divs has been updated ";
            return;
        }
        
    }

}

function loop_UHCID() {

    do {
        for (cnt = 8; cnt < 18; cnt++) {

            if (Emulsessiona.autECLPS.GetText(cnt, 7, 4).trim() == BAID1) {
                Number(selectionCode);
                //parseInt(selectionCode);
                selectionCode++; 
                
                
                if (selectionCode > 10){
                    Emulsessiona.autECLPS.SendKeys("[PF8]");
                    apiChka();
                    pf8++;
                    selectionCode = 1;
                }
 
                uhcid_Updation_paid_();
                apiChka(); //inserting a short delay 
                loopuhcID = true;
                return;
            }
        }

        Emulsessiona.autECLPS.SendKeys("[PF8]");
        apiChka();
        
        if (Emulsessiona.autECLPS.GetText(1, 70, 3).trim() == Emulsessiona.autECLPS.GetText(1, 77, 3).trim() && Emulsessiona.autECLPS.GetText(1, 70, 3).trim() != "1") {

            for (cnt = 8; cnt < 18; cnt++) {

                if (Emulsessiona.autECLPS.GetText(cnt, 7, 4).trim() == BAID1) {
                    Number(selectionCode);
                    //parseInt(selectionCode);
                    selectionCode++;

                    if (selectionCode > 10) {
                        Emulsessiona.autECLPS.SendKeys("[PF8]");
                        apiChka();
                        pf8++;

                        selectionCode = 1;
                    }
                    
                    uhcid_Updation_paid_();
                    apiChka(); //inserting a short delay 
                    loopuhcID = true;
                    return;
                }
            }

        }

    } while (Emulsessiona.autECLPS.GetText(24, 1, 60).indexOf("LAST PAGE") <= 0)
    
}

function uhcid_Updation_paid_() {

    apiChka();

    if (pf8 >= 1) {
        for (var i = 1; i <= pf8; i++) {

            Emulsessiona.autECLPS.SendKeys("[pf8]");
            apiChka();

        }        
    } 


    Emulsessiona.autECLPS.SendKeys("[erase eof]", 18, 13);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(selectionCode, 18, 13);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("SELECTED ADDRESS HAS NO UHCID DATA") >= 0) {        
        MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.GetText(24, 2, 70).trim();
        return;
    }

    

    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("THE SELECTION NUMBER IS NOT VALID") >= 0) {        
        return;
    }


    replaceZero();

    if (Emulsessiona.autECLPS.GetText(2, 35, 40).trim().indexOf("COSMOS DEMOGRAPHICS") >= 0 && Emulsessiona.autECLPS.GetText(3, 6, 5).trim() != "" ) {//to check voided UHC ID DIV

        if ( bd == Emulsessiona.autECLPS.GetText(2, 8, 5).trim()) {

            chkDiv();

            if (DivScreen == true) {
                Emulsessiona.autECLPS.SendKeys("[pf5]");
                apiChka();

                loop_UHCID();

                if (loopuhcID == true) {
                    if (MacroOutput.indexOf("UHCID Divs has been updated") < 0) {
                        MacroOutput = MacroOutput + "\n" + "UHCID Divs has been updated ";
                        return;
                    }
                }
            }

            if (Emulsessiona.autECLPS.GetText(24, 73, 6).trim() != "CHANGE") {
                Emulsessiona.autECLPS.Sendkeys("C", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }

            Emulsessiona.autECLPS.Sendkeys(AddBillA_ID_new, 7, 75);
            apiChka();
            Emulsessiona.autECLPS.SendKeys("I", 21, 8);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();

            if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("INVALID") >= 0) {
                Emulsessiona.autECLPS.SendKeys("[erase eof]", 8, 66);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }
            if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("INVALID") >= 0) {
                Emulsessiona.autECLPS.SendKeys("[erase eof]", 8, 70);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }
            if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("INVALID") >= 0) {
                Emulsessiona.autECLPS.SendKeys("[erase eof]", 8, 74);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }
            if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("INVALID") >= 0) {
                Emulsessiona.autECLPS.SendKeys("[erase eof]", 8, 78);
                apiChka();
                Emulsessiona.autECLPS.SendKeys("I", 21, 8);
                Emulsessiona.autECLPS.SendKeys("[enter]");
                apiChka();
            }
            
            if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim() == "") {
                Emulsessiona.autECLPS.SendKeys("[pf5]");
                apiChka();
            } 
            else {
                MacroOutput = MacroOutput + "\n" + "DIV - " + Emulsessiona.autECLPS.GetText(3, 7, 3).trim() + " " + Emulsessiona.autECLPS.GetText(24, 2, 70).trim();
                Emulsessiona.autECLPS.SendKeys("[pf5]");
                apiChka();
            }
            
        } else {
            loopuhcID = true;
            if (MacroOutput.indexOf("UHCID Divs has been updated") < 0) {
                MacroOutput = MacroOutput + "\n" + "UHCID Divs has been updated ";
                return;
            }
        }

    }

    if (Emulsessiona.autECLPS.GetText(2, 34, 40).trim().indexOf("COSMOS DEMOGRAPHICS") >= 0) {
        Emulsessiona.autECLPS.SendKeys("[pf5]");
        apiChka();
    }

    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("SELECTED ADDRESS NOT ACTIVE & HAS NO UHCID DATA") >= 0) {
        loopuhcID = true;
        if (MacroOutput.indexOf("UHCID Divs has been updated") < 0) {
            MacroOutput = MacroOutput + "\n" + "UHCID Divs has been updated ";
            return;
        }
    }
    
    loop_UHCID();

}

function replaceZero() {

    bd = BAID1;
    
    if (bd.indexOf("000") >= 0 ) {
        bd = bd.replace("000", "");
    }
    if (bd.indexOf("0") >= 0) {
        bd = bd.replace("0", "");
    }
    if (bd.indexOf("0") >= 0) {
        bd = bd.replace("0", "");
    }
    
}

function chkDiv() {

    DivScreen = false;

    screenDiv = Emulsessiona.autECLPS.GetText(3, 7, 3).trim();
    
    if (screenDiv == "UBE") {
        DivScreen = true;
        MacroOutput = MacroOutput + "\n" + "DIV - " + screenDiv + " is shared provider UHC id div";
        return;
    } else if (screenDiv == "UBM") {
        MacroOutput = MacroOutput + "\n" + "DIV - " + screenDiv + " is shared provider UHC id div";
        DivScreen = true;
        return;
    } else if (screenDiv == "UBS") {
        MacroOutput = MacroOutput + "\n" + "DIV - " + screenDiv + " is shared provider UHC id div";
        DivScreen = true;
        return;    
    } else if (screenDiv == "UBW") {
        MacroOutput = MacroOutput + "\n" + "DIV - " + screenDiv + " is shared provider UHC id div";
        DivScreen = true;
        return;
    } else if (screenDiv == "UBX") {
        MacroOutput = MacroOutput + "\n" + "DIV - " + screenDiv + " is shared provider UHC id div";
        DivScreen = true;
        return;
    } else if (screenDiv == "UBY") {
        MacroOutput = MacroOutput + "\n" + "DIV - " + screenDiv + " is shared provider UHC id div";
        DivScreen = true;
        return;
    } else if (screenDiv == "UBZ") {
        MacroOutput = MacroOutput + "\n" + "DIV - " + screenDiv + " is shared provider UHC id div";
        DivScreen = true;
        return;
    } else if (screenDiv == "UCT") {
        MacroOutput = MacroOutput + "\n" + "DIV - " + screenDiv + " is shared provider UHC id div";
        DivScreen = true;
        return;
    } else if (screenDiv == "UCV") {
        MacroOutput = MacroOutput + "\n" + "DIV - " + screenDiv + " is shared provider UHC id div";
        DivScreen = true;
        return;
    } else if (screenDiv == "PIC") {
        MacroOutput = MacroOutput + "\n" + "DIV - " + screenDiv + " is shared provider UHC id div";
        DivScreen = true;
        return;
    } else if (screenDiv == "MSP") {
        MacroOutput = MacroOutput + "\n" + "DIV - " + screenDiv + " is shared provider UHC id div, check medica contracts line";
        DivScreen = true;
        return;
    } else if (screenDiv == "MTK") {
        MacroOutput = MacroOutput + "\n" + "DIV - " + screenDiv + " is shared provider UHC id div, check medica contracts line";
        DivScreen = true;
        return;
    } 
    
}

function chAddrtyp() {

    if (ADDRESS_TYPE == "PLSV") {
        ADDRESS_TYPE = "P";
    } else if (ADDRESS_TYPE == "COMB") {
        ADDRESS_TYPE = "C";
    } else if (ADDRESS_TYPE == "BILL") {
        ADDRESS_TYPE = "B";
    }
    
}

function Check_Address() {

    addcheck = false;

    Emulsessiona.autECLPS.SendKeys("[pf3]");
    apiChka();

    Emulsessiona.autECLPS.SendKeys("I");
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();

    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
    apiChka();

    if (Emulsessiona.autECLPS.gettext(24, 2, 20).trim().indexOf("NO DATA") >= 0) {
        addcheck = true;
    } else if (Emulsessiona.autECLPS.gettext(24, 2, 20).trim() != "") {

        adrpti = ADR.split("|");
        CITY_pti = CITY_Address.split("|");
        STATE_pti = STATE_Address.split("|");
        ZIP_pti = ZIP_Address.split("|");


        //osasco

        if (ADR != "") {

            for (x in adrpti) {

                if (ZIP_pti[x].indexOf("-") > 0) {
                    ZIP_pti[x] = ZIP_pti[x].replace("-", " ");
                }
                if (ZIP_pti[x].length != 10) {
                    ZIP_pti[x] = ZIP_pti[x] + " " + "0000";

                }
                
                do {
                    for (var cnt = 7; cnt < 17; cnt += 3) {

                        if (Emulsessiona.autECLPS.GetText(cnt, 5, 33).trim() == adrpti[x]) {
                            if (Emulsessiona.autECLPS.GetText(cnt + 1, 5, 30).trim().split(",")[0] == CITY_pti[x]) {
                                if (Emulsessiona.autECLPS.GetText(cnt + 1, 5, 30).trim().split(",")[1].trim().split(" ")[0] == STATE_pti[x]) {
                                    if (Emulsessiona.autECLPS.GetText(cnt + 1, 5, 30).trim().split(",")[1].trim().split(" ")[1].split("-")[0] == ZIP_pti[x].split(" ")[0]) {
                                        
                                        addcheck = true;
                                        var TYP1 = Emulsessiona.autECLPS.gettext(cnt, 38, 11).trim().split("-")[0];
                                        apiChka();

                                        var slcd = Emulsessiona.autECLPS.gettext(cnt, 1, 2).trim();
                                        
                                        Emulsessiona.autECLPS.SendKeys(slcd, 19, 13);
                                        apiChka();
                                        Emulsessiona.autECLPS.SendKeys("[enter]");
                                        apiChka();

                                        Emulsessiona.autECLPS.SendKeys("A",21,15);
                                        apiChka();

                                        Emulsessiona.autECLPS.SendKeys("[enter]");
                                        apiChka();
                                        
                                        if (Emulsessiona.autECLPS.gettext(14, 41, 2).trim() != "") {

                                            MacroOutput = "Address is already loaded as - " + TYP1 + " - Not active";
                                            Emulsessiona.autECLPS.SendKeys("[pf4]");
                                            apiChka();

                                        } else {

                                            MacroOutput = "Address is already loaded as - " + TYP1 + " - Active";
                                            Emulsessiona.autECLPS.SendKeys("[pf4]");
                                            apiChka();
                                        }
                                        
                                        adrpti = "";
                                        CITY_pti = "";
                                        STATE_pti = "";
                                        ZIP_pti = "";
                                        return;
                                    }
                                }
                            }
                        }

                    }

                    Emulsessiona.autECLPS.Sendkeys("[pf8]");
                    apiChka();

                } while (Emulsessiona.autECLPS.GetText(24, 2, 60).trim() != "THIS IS THE LAST PAGE");

            }

        }

    }
    
}

function chkITC() {


    Check_ITC = false;
    var check = false;

    if (Emulsessiona.autECLPS.GetText(3, 30, 20).trim().indexOf("-- AREA MENU") < 0) {
        Emulsessiona.autECLPS.Sendkeys("[pf2]");
        apiChka();
    }

    Emulsessiona.autECLPS.SendKeys("Z", 21, 22);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    Emulsessiona.autECLPS.SendKeys("I");
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");

    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);

    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    if (Emulsessiona.autECLPS.gettext(24, 2, 20).trim().indexOf("NO DATA") >= 0) {
        MacroOutput = MacroOutput + "\n" + "Mpin-" + MPIN + "-NO DATA FOUND FOR THIS SEARCH CRITERIA ";
        return;
    }

    if (Emulsessiona.autECLPS.gettext(6, 2, 70).trim().indexOf("(BIL)") >= 0) {
        if (ADDRESS_TYPE == "P") {
            MacroOutput = MacroOutput + "\n" + "Mpin-" + MPIN + "-PLSV address should not loaded under Bill record";
            return;
        }
    }
    
    Emulsessiona.autECLPS.SendKeys("1", 19, 13);
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("T");
    Emulsessiona.autECLPS.SendKeys("C");

    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim() == "NO DATA EXISTS FOR SEARCH CRITERIA" && DELEGATED_ENTITY_CODE == "" ){

        MacroOutput = MacroOutput + "\n" + "Mpin-" + MPIN + "-ITC credential catagory for delegated not updated";
        Check_ITC = true;
        return;
        
    }

    if (Emulsessiona.autECLPS.GetText(9, 69, 1).trim() != "" && DELEGATED_ENTITY_CODE != "") {

        do {

            for (var i = 9; i < 18; i += 2) {

                if (Emulsessiona.autECLPS.GetText(i, 69, 9).trim() == TAX_ID_Tax) {
                    if (dateITC == "") {
                        dateITC = Emulsessiona.autECLPS.GetText(i + 1, 7, 12).trim();
                    }                    
                    return;               
                }

            }

            Emulsessiona.autECLPS.Sendkeys("[pf8]");
            apiChka();
            
        } while (Emulsessiona.autECLPS.GetText(24, 2, 70).trim() != "NO MORE PAGES TO VIEW");

    }
    
}

function pf3page() {

    Emulsessiona.autECLPS.Sendkeys("A", 21, 8);
    Emulsessiona.autECLPS.Sendkeys("4");
    Emulsessiona.autECLPS.Sendkeys("Z");

    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();

    Emulsessiona.autECLPS.Sendkeys("[enter]");
    apiChka();
    Emulsessiona.autECLPS.Sendkeys("1", 19, 13);
    Emulsessiona.autECLPS.Sendkeys("[enter]");
    apiChka();
    
}

function Capcode_Updation() {
    
    capcodeScreen()
    
    if (Emulsessiona.autECLPS.GetText(7, 6, 10).trim() != "") {

        CapCdEffDate = CapCdEffDate.split(" ");

        for (var u in BSAR7MAID_Array){
            
            do {

                for (var b = 8; b < 18; b += 3) {

                    if (Emulsessiona.autECLPS.GetText(b, 39, 9).trim() == BSAR7MAID_Array[u]) {
                        if (Emulsessiona.autECLPS.GetText(b - 1, 2, 1).trim() == "") {
                            slcode = Emulsessiona.autECLPS.GetText(b - 4, 2, 1).trim();
                            slno = true;
                            break;
                        } else {
                            slcode = Emulsessiona.autECLPS.GetText(b - 1, 2, 1).trim();
                            slno = true;
                            break;
                        }
                    }
                }

                if (slcode != "") {
                    break;
                }
                Emulsessiona.autECLPS.Sendkeys("[pf8]");
                apiChka();
            } while (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("LAST PAGE") < 0);


            Emulsessiona.autECLPS.SendKeys(slcode, 19, 13);
            apiChka();
            Emulsessiona.autECLPS.Sendkeys("[enter]");
            apiChka();
            slcode = "";

            if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("CONTRACT FOUND") >= 0) {
                MacroOutput = MacroOutput + "\n" + "Mpin-" + MPIN + " " + Emulsessiona.autECLPS.GetText(24, 2, 70).trim();
                capcodeScreen();
                continue;
            }


            Emulsessiona.autECLPS.Sendkeys("A", 21, 8);
            Emulsessiona.autECLPS.Sendkeys("[enter]");
            apiChka();

            //Emulsessiona.autECLPS.Sendkeys("1", 19, 13);
            //Emulsessiona.autECLPS.Sendkeys("[enter]");
            //apiChka();

            Emulsessiona.autECLPS.Sendkeys(CapCode, 8, 10);
            apiChka();

            

            Emulsessiona.autECLPS.Sendkeys(CapCdEffDate[0], 8, 32);
            Emulsessiona.autECLPS.Sendkeys("01", 8, 35);
            Emulsessiona.autECLPS.Sendkeys(CapCdEffDate[2], 8, 38);
            apiChka()

            Emulsessiona.autECLPS.SendKeys("I", 21, 8);
            Emulsessiona.autECLPS.SendKeys("[enter]");
            apiChka();


            if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("RECORD") >= 0) {
                MacroOutput = MacroOutput + "\n" + "MAID-" + BSAR7MAID_Array[u] + " " + "Cap code has been updated";
                capcodeScreen();
                continue;
            } else {
                MacroOutput = MacroOutput + "\n" + "MAID-" + BSAR7MAID_Array[u] + " " + Emulsessiona.autECLPS.GetText(24, 2, 70);
                capcodeScreen();
                continue;
            }
            
        }

    }
    
}

function bsar4Loop() {

    if (Emulsessiona.autECLPS.GetText(4, 2, 50).trim().indexOf("NAME/BILL") > 0) {

        do {

            for (var b = 8; b < 18; b += 3) {

                if (Emulsessiona.autECLPS.GetText(b, 39, 9).trim() == AddMA_ID_new) {
                    if (Emulsessiona.autECLPS.GetText(b - 1, 2, 1).trim() == "") {
                        slcode = Emulsessiona.autECLPS.GetText(b - 4, 2, 1).trim();
                        slno = true;
                        break;
                    } else {
                        slcode = Emulsessiona.autECLPS.GetText(b - 1, 2, 1).trim();
                        slno = true;
                        break;
                    }
                }
            }

            if (slcode != "") {
                break;
            }
            Emulsessiona.autECLPS.Sendkeys("[pf8]");
            apiChka();
        } while (Emulsessiona.autECLPS.GetText(24, 2, 50).trim().indexOf("LAST PAGE") < 0);
    }


}

function capcodeScreen() {

    Emulsessiona.autECLPS.Sendkeys("[pf3]");
    Emulsessiona.autECLPS.Sendkeys("I", 21, 8);
    apiChka();
    Emulsessiona.autECLPS.Sendkeys("#");
    apiChka();
    Emulsessiona.autECLPS.Sendkeys("Z");
    apiChka();
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();

    Emulsessiona.autECLPS.Sendkeys("[enter]");
    apiChka();
    Emulsessiona.autECLPS.Sendkeys("1", 19, 13);
    Emulsessiona.autECLPS.Sendkeys("[enter]");
    apiChka();
    
}

var state_BSAR = "";
function checkState() {

    if (StateC_new == "AZ") {//YES
        state_BSAR = "YES";
    } else if (StateC_new == "KS") {
        state_BSAR = "YES";
    } else if (StateC_new == "MO") {
        state_BSAR = "YES";
    } else if (StateC_new == "OH") {
        state_BSAR = "YES";
    } else if (StateC_new == "CA") {
        state_BSAR = "YES";
    } else if (StateC_new == "LA") {
        state_BSAR = "YES";
    } else if (StateC_new == "NE") {
        state_BSAR = "YES";
    } else if (StateC_new == "DE") {
        state_BSAR = "YES";
    } else if (StateC_new == "MD") {
        state_BSAR = "YES";
    } else if (StateC_new == "NJ") {
        state_BSAR = "YES";
    } else if (StateC_new == "PA") {
        state_BSAR = "YES";
    } else if (StateC_new == "WI") {
        state_BSAR = "YES";
    } else if (StateC_new == "FL") {
        state_BSAR = "YES";
    } else if (StateC_new == "MA") {
        state_BSAR = "YES";
    } else if (StateC_new == "NM") {
        state_BSAR = "YES";
    } else if (StateC_new == "TN") {
        state_BSAR = "YES";
    } else if (StateC_new == "IA") {
        state_BSAR = "YES";
    } else if (StateC_new == "MS") {
        state_BSAR = "YES";
    } else if (StateC_new == "TX") {
        state_BSAR = "YES";
        
    } else if (StateC_new == "VA") {//NO
        state_BSAR = "NO";
    } else if (StateC_new == "OK") {
        state_BSAR = "NO";
    } else if (StateC_new == "WA") {
        state_BSAR = "NO";
    } else if (StateC_new == "RI") {
        state_BSAR = "NO";
    } else if (StateC_new == "HI") {
        state_BSAR = "NO";
    } else if (StateC_new == "MI") {
        state_BSAR = "NO";
    } else if (StateC_new == "NY") {
        state_BSAR = "NO";
    } else if (StateC_new == "NC") {
        state_BSAR = "NO";
    }
    
}

function GotoLoadPLSV() {

    LoadPLSV = false;

    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M");
    Emulsessiona.autECLPS.SendKeys("Z");
    Emulsessiona.autECLPS.SendKeys("[erase eof]", 21, 31);
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[erase eof]", 23, 37);
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    var MABAID = GetPLSVingMABAID();
    
    if (MABAID != "") {

        MAID = MABAID.split("-")[0];
        BAID = MABAID.split("-")[1];

        //to get primary PLSV PAID number
        //getPrimaryPLSV();

        Emulsessiona.autECLPS.SendKeys("A", 21, 8);
        Emulsessiona.autECLPS.SendKeys("U", 21, 15);
        Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
        Emulsessiona.autECLPS.SendKeys("[erase eof]", 21, 31);
        Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
        apiChka();
        Emulsessiona.autECLPS.SendKeys("[erase eof]", 23, 37);
        Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
        apiChka();
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();
        Emulsessiona.autECLPS.SendKeys("1", 19, 13);
        Emulsessiona.autECLPS.SendKeys("[enter]");
        apiChka();


        if (Emulsessiona.autECLPS.GetText(6, 2, 3) == "SEL") {
            Cosmos_Demographics();
            LoadPLSV = true;
        }
        else {

            if (MacroOutput == "") {
                MacroOutput = "UHCID Screen not found. Macro stopped! ";
            }
            else {
                MacroOutput = MacroOutput + "UHCID Screen not found. Macro stopped! ";
                return;
            }
        }
    }    
}

function GetPLSVingMABAID() {
    var GetPLSVingMABAID = "";

    if (BA_ID_DB == "") {

        do {

            for (ctr = 7; ctr <= 17; ctr += 3) {
                if (Emulsessiona.autECLPS.GetText(ctr + 1, 36, 9).trim() == AddMA_ID_new) {

                    if (Emulsessiona.autECLPS.GetText(ctr - 3, 38, 4).trim() == "BILL") {

                        return Emulsessiona.autECLPS.GetText(ctr - 2, 36, 14).trim();

                    }                    
                }
            }

            Emulsessiona.autECLPS.Sendkeys("[pf8]");
            apiChka();

        } while (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("THIS IS THE LAST PAGE") < 0);

    } else {

        do {
            for (ctr = 7; ctr <= 17; ctr += 3) {
                if (Emulsessiona.autECLPS.GetText(ctr, 38, 1).trim() == "B" || Emulsessiona.autECLPS.GetText(ctr, 38, 1).trim() == "C") {
                    if (Emulsessiona.autECLPS.GetText(ctr + 1, 36, 9).trim() == BA_ID_DB) {
                        return Emulsessiona.autECLPS.GetText(ctr + 1, 36, 14).trim();
                    }
                }
            }
            Emulsessiona.autECLPS.Sendkeys("[pf8]");
            apiChka();
        } while (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("THIS IS THE LAST PAGE") < 0);

    }

}


function check_MPIN_TAX() {

    check_MPIN = false;

    if (Emulsessiona.autECLPS.GetText(3, 30, 20).trim().indexOf("-- AREA MENU") < 0) {
        Emulsessiona.autECLPS.Sendkeys("[pf2]");
        apiChka();
    }

    Emulsessiona.autECLPS.SendKeys("Z", 21, 22);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();
    
    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M", 21, 15);
    Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
    
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("NO DATA") >= 0) {
        MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 70).trim();
        check_MPIN = true;
        return;
    }

    Emulsessiona.autECLPS.SendKeys("[pf3]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M", 21, 15);
    Emulsessiona.autECLPS.SendKeys("Z", 21, 23);


    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();


    if (Emulsessiona.autECLPS.GetText(24, 2, 70).trim().indexOf("NO DATA") >= 0) {
        MacroOutput = Emulsessiona.autECLPS.GetText(24, 2, 70).trim();
        check_MPIN = true;
        return;
    }
    
}

function chkActvStatus() {

    Emulsessiona.autECLPS.SendKeys("2", 19, 13);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    Emulsessiona.autECLPS.SendKeys("A", 21, 15);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[enter]");
    apiChka();

    if (Emulsessiona.autECLPS.gettext(14, 41, 2).trim() != "") {
        orphan = true;
        Emulsessiona.autECLPS.SendKeys("[pf4]");
        apiChka();

    } 
    
}

function Update_DIRIND() {

    if (addAddress != true) {return;}
    
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[pf3]");
    apiChka();
    Emulsessiona.autECLPS.SendKeys("I", 21, 8);
    Emulsessiona.autECLPS.SendKeys("M", 21, 15);
    Emulsessiona.autECLPS.SendKeys("Z", 21, 23);
    Emulsessiona.autECLPS.SendKeys("[erase eof]", 21, 31);
    Emulsessiona.autECLPS.SendKeys(MPIN, 21, 31);
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[erase eof]", 23, 37);   
    Emulsessiona.autECLPS.SendKeys(TAX_ID_Tax, 23, 37);
    apiChka();    
    Emulsessiona.autECLPS.SendKeys(AddMA_ID_new, 21, 47);    
    apiChka();
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();

    if (Emulsessiona.autECLPS.gettext(24, 2, 20).trim().indexOf("NO DATA") >= 0) {
        MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.gettext(24, 2, 60).trim();
        return;
    }

    Emulsessiona.autECLPS.SendKeys("1");
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();

    Emulsessiona.autECLPS.SendKeys("@", 21,15);
    Emulsessiona.autECLPS.SendKeys("[Enter]");
    apiChka();

    if (Emulsessiona.autECLPS.gettext(2, 16, 60).trim().indexOf("(@)") >= 0 && Emulsessiona.autECLPS.gettext(24, 1, 20).trim().indexOf("108 -") < 0) {

        if (Emulsessiona.autECLPS.gettext(24, 73, 7).trim() == "INQUIRY") {
            Emulsessiona.autECLPS.SendKeys("C",21,8);
            Emulsessiona.autECLPS.SendKeys("[Enter]");
            apiChka();
        }

        Emulsessiona.autECLPS.SendKeys(AddMA_ID_new, 7, 38);
        apiChka();
        Emulsessiona.autECLPS.SendKeys("[Enter]");
        apiChka();
        Emulsessiona.autECLPS.SendKeys(DIR_IND, 3, 29);
        apiChka();
        Emulsessiona.autECLPS.SendKeys("[Enter]");
        apiChka();
        Emulsessiona.autECLPS.SendKeys(RSN_CD, 3, 40);
        apiChka();
        Emulsessiona.autECLPS.SendKeys("[Enter]");
        apiChka();

        if (Emulsessiona.autECLPS.gettext(24, 2, 60).trim().indexOf("UPDATED SUCCESSFULLY") < 0) {
            MacroOutput = MacroOutput + "\n" + Emulsessiona.autECLPS.gettext(24, 2, 60).trim();
            return;
        }
    }

}