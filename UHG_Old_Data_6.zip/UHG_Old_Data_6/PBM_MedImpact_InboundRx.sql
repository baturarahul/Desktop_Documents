USE [UMR_PBM_RECON]
GO

/****** Object:  Table [dbo].[PBM_MedImpact_InboundRx]    Script Date: 11/11/2016 1:21:32 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[PBM_MedImpact_InboundRx](
	[Sno] [int] IDENTITY(1,1) NOT NULL,
	[Employers_Group_Number] [varchar](8) NULL,
	[Employees_Social_Security_Number] [varchar](9) NULL,
	[Employees_ID_Card_Number] [varchar](30) NULL,
	[Patient_Sequence_Number] [varchar](2) NULL,
	[Patient_First_Name] [varchar](15) NULL,
	[Patient_Last_Name] [varchar](20) NULL,
	[Patient_Date_of_Birth] [varchar](8) NULL,
	[Service_Date] [varchar](8) NULL,
	[Prescription_Number] [varchar](11) NULL,
	[Claim_Type] [varchar](1) NULL,
	[Pharmacy_IRS_Number] [varchar](9) NULL,
	[Pharmacy_ID] [varchar](10) NULL,
	[Pharmacy_Name] [varchar](20) NULL,
	[Pharmacy_Zipcode] [varchar](5) NULL,
	[Internal_Use_1] [varchar](1) NULL,
	[National_Drug_Code_Number] [varchar](11) NULL,
	[Therapeutic_Class] [varchar](6) NULL,
	[Vendor_Specific_Data] [varchar](14) NULL,
	[Generic_Indicator] [varchar](1) NULL,
	[Compound_Drug_Indicator] [varchar](1) NULL,
	[Formulary_Indicator] [varchar](1) NULL,
	[Refill_Code] [varchar](2) NULL,
	[Dispense_As_Written_Indicator] [varchar](1) NULL,
	[Days_Supply] [varchar](3) NULL,
	[Quantity_Dispensed] [varchar](4) NULL,
	[Drug_Name] [varchar](15) NULL,
	[Ingredient_Cost_Submitted] [varchar](10) NULL,
	[Ingredient_Cost_Allowed] [varchar](10) NULL,
	[Dispensing_Fee] [varchar](8) NULL,
	[Sales_Tax] [varchar](8) NULL,
	[Deductible_Amount] [varchar](10) NULL,
	[Paid_Amount] [varchar](10) NULL,
	[Administrative_Fee] [varchar](8) NULL,
	[Lifetime_Max_Amount] [varchar](10) NULL,
	[Out_of_Pocket_Amount_Deductible_Included] [varchar](10) NULL,
	[POS_Claim_Count] [varchar](1) NULL,
	[Paper_Claim_Count] [varchar](1) NULL,
	[File_Create_Date] [varchar](8) NULL,
	[Internal_Use_2] [varchar](1) NULL,
	[Pharmacy_NPI_Number] [varchar](10) NULL,
	[Internal_Use_3] [varchar](12) NULL,
	[Prescribing_Physician_DEA_Number] [varchar](10) NULL,
	[Out_of_Pocket_Amount_Deductible_Excluded] [varchar](10) NULL,
	[Network_Indicator] [varchar](1) NULL,
	[For_Future_Use] [varchar](146) NULL,
	[FilePath] [varchar](500) NULL,
	[FileName] [varchar](200) NULL,
	[FileDate] [varchar](10) NULL,
	[FileType] [varchar](50) NULL,
	[DateAdded] [datetime] NOT NULL CONSTRAINT [DF__PBM_MedImpact_InboundRx__DateA__145C0A3G]  DEFAULT (getdate()),
PRIMARY KEY CLUSTERED 
(
	[Sno] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 80) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING ON
GO


