INSERT INTO [dbo].[PBM_ProCareOutboundMedicalTrans]
(PersonCode,
Policy,
Class,
Network,
DateofService,
Deductible,
OutofPocket,
FirstName,
MiddleInitial,
LastName,
BirthDate,
Relationship,
MemberID,
ClaimNumber,
BenefitPeriodBeginDate,
RecordType,
Gender,
PlanPayment,
BenefitPeriodEndDate,
AccumType,
EE_FirstName,
EE_LastName,
EE_BirthDate,
EE_Gender,
ProCareClaimNumber,
Filler
)
(
Select B.[INDIV_SEQ_NBR],
B.[GRP_NBR] + '    ' as Policy, 
A.[GRP_STAT_CL_CD], 
'IN    ' as Network, 
replace(Convert(varchar,CONVERT(DATE,A.[SERV_RCVD_DT])),'-','') AS SERV_RCVD_DT,


'             '
as DEDUCTIBLE,



CASE substring(replace(ltrim(rtrim(A.[APPLIED_AMT])),'.',''),1,1)
WHEN '-' THEN 
	CASE LEN(replace(ltrim(rtrim(A.[APPLIED_AMT])),'.',''))
	WHEN 0 THEN '-000000000000'
	WHEN 4 THEN '-' + '000000000' + Replace(replace(ltrim(rtrim(A.[APPLIED_AMT])),'.',''),'-','')
	WHEN 5 THEN '-' + '00000000' + Replace(replace(ltrim(rtrim(A.[APPLIED_AMT])),'.',''),'-','')
	WHEN 6 THEN '-' + '0000000' + Replace(replace(ltrim(rtrim(A.[APPLIED_AMT])),'.',''),'-','')
	WHEN 7 THEN '-' + '000000' + Replace(replace(ltrim(rtrim(A.[APPLIED_AMT])),'.',''),'-','')
	WHEN 8 THEN '-' + '00000' + Replace(replace(ltrim(rtrim(A.[APPLIED_AMT])),'.',''),'-','')
	WHEN 9 THEN '-' + '0000' + Replace(replace(ltrim(rtrim(A.[APPLIED_AMT])),'.',''),'-','')
	WHEN 10 THEN '-' + '000' + Replace(replace(ltrim(rtrim(A.[APPLIED_AMT])),'.',''),'-','')
	WHEN 11 THEN '-' + '00' + Replace(replace(ltrim(rtrim(A.[APPLIED_AMT])),'.',''),'-','')
	WHEN 12 THEN '-0' + Replace(replace(ltrim(rtrim(A.[APPLIED_AMT])),'.',''),'-','')	
	END
ELSE 
	CASE LEN(replace(ltrim(rtrim(A.[APPLIED_AMT])),'.',''))
	WHEN 0 THEN '+000000000000'
	WHEN 3 THEN '+' + '000000000' + replace(ltrim(rtrim(A.[APPLIED_AMT])),'.','')
	WHEN 4 THEN '+' + '00000000' + replace(ltrim(rtrim(A.[APPLIED_AMT])),'.','')
	WHEN 5 THEN '+' + '0000000' + replace(ltrim(rtrim(A.[APPLIED_AMT])),'.','')
	WHEN 6 THEN '+' + '000000' + replace(ltrim(rtrim(A.[APPLIED_AMT])),'.','')
	WHEN 7 THEN '+' + '00000' + replace(ltrim(rtrim(A.[APPLIED_AMT])),'.','')
	WHEN 8 THEN '+' + '0000' + replace(ltrim(rtrim(A.[APPLIED_AMT])),'.','')
	WHEN 9 THEN '+' + '000' + replace(ltrim(rtrim(A.[APPLIED_AMT])),'.','')
	WHEN 10 THEN '+' + '00' + replace(ltrim(rtrim(A.[APPLIED_AMT])),'.','')
	WHEN 11 THEN '+' + '0' + replace(ltrim(rtrim(A.[APPLIED_AMT])),'.','')
	WHEN 12 THEN '+' + replace(ltrim(rtrim(A.[APPLIED_AMT])),'.','')	
	END
END
as OutofPocket,





B.[INDIV_FIRST_NM],
B.[INDIV_MIDL_INTL],
B.[INDIV_LAST_NM],
B.[INDIV_BIRTH_DT],
B.[DPNT_REL_CD],
C.[ASSGN_SUBSCR_NBR],
A.[MCRFM_ROLL_CD],
replace(A.[BNFIT_DT],'-','') as BNFIT_DT,
'2' as RecordType,
' ' as Gender,
'             ' as PlanPayment,
'        ' as BenefitPeriodEndDate,
'          ' as AccumType,
'                         ' as EE_FirstName,
'                                   ' as EE_LastName,
'        ' as EE_BirthDate,
' ' as EE_Gender,
'                    ' as ProCareClaimNumber,
'                                                                                                                                                                                                                      ' as Filler






from [dbo].[BLX0111T] as A inner join [dbo].[COR0023T] as B on A.enrl_cert_nbr = B.empe_cert_nbr
inner JOIN [dbo].BEF0105T as C ON A.enrl_cert_nbr = C.enrl_cert_nbr


where 

ltrim(rtrim(B.GRP_NBR)) = '76412398' and ltrim(rtrim(A.Trans_type_cd))='M' and ltrim(rtrim(A.BNFIT_CD)) = '8R' and ltrim(rtrim(A.updt_dt)) = '2016-12-02'

)