Select '1 'as RecordType,
substring(Convert(varchar,'Procare_Data2Text0000_' + Convert(varchar,Replace(convert(varchar,convert(date,getdate())),'-',''))),1,30) as FileName, 
substring(replace(convert(varchar,convert(date,getdate())),'-',''),1,8) as ProcessDate, 
substring(replace(Convert(varchar,convert(time,getdate())),':',''),1,6) as ProcessTime, 
'                                                                                                        ' as Filler