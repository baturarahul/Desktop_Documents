INSERT INTO [dbo].[PBM_ProCareOutboundMedicalTrans]
(PersonCode,
Policy,
Class,
Network,
DateofService,
Deductible,
FirstName,
MiddleInitial,
LastName,
BirthDate,
Relationship,
MemberID,
ClaimNumber,
BenefitPeriodBeginDate,
RecordType,
Gender,
PlanPayment,
BenefitPeriodEndDate,
AccumType,
EE_FirstName,
EE_LastName,
EE_BirthDate,
EE_Gender,
ProCareClaimNumber,
Filler
)
(
Select A.[INDIV_SEQ_NBR],
A.[POLICY_ID_NUMBER], 
A.[SCHED_CLASS_CODE], 
'IN    ' as Network, 
replace(Convert(varchar,CONVERT(DATE,A.[SERV_RCVD_DT])),'-','') AS SERV_RCVD_DT,
A.[APPLIED_AMT],
B.[INDIV_FIRST_NM],
B.[INDIV_MIDL_INTL],
B.[INDIV_LAST_NM],
B.[INDIV_BIRTH_DT],
B.[DPNT_REL_CD],
C.[ASSGN_SUBSCR_NBR],
A.[MCRFM_ROLL_CD],
replace(A.[BNFIT_DT],'-','') as BNFIT_DT,
'2' as RecordType,
' ' as Gender,
'             ' as PlanPayment,
'        ' as BenefitPeriodEndDate,
'          ' as AccumType,
'                         ' as EE_FirstName,
'                                   ' as EE_LastName,
'        ' as EE_BirthDate,
' ' as EE_Gender,
'                    ' as ProCareClaimNumber,
'                                                                                                                                                                                                                      ' as Filler





from [dbo].[BLX0111T] as A inner join [dbo].[COR0023T] as B on A.enrl_cert_nbr = B.empe_cert_nbr
inner JOIN [dbo].BEF0105T as C ON A.enrl_cert_nbr = C.enrl_cert_nbr


where 

A.policy_id_number='767000412398' and ltrim(rtrim(A.Trans_type_cd))='M' and B.grp_nbr='76412398'
)